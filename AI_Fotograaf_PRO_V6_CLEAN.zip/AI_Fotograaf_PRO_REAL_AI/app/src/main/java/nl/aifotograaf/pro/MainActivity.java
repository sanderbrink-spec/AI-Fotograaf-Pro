package nl.aifotograaf.pro;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.exifinterface.media.ExifInterface;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.google.android.gms.tasks.Tasks;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.FloatBuffer;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static final int BG=Color.rgb(8,10,13), CARD=Color.rgb(18,21,27), CARD2=Color.rgb(24,28,35);
    private static final int TEXT=Color.WHITE, MUTED=Color.rgb(157,164,175), ACCENT=Color.rgb(232,198,125), GREEN=Color.rgb(82,201,139);
    private static final String MODEL_URL="https://huggingface.co/skillsafe-ai/realesrgan-x4plus/resolve/main/model.onnx?download=true";
    private static final String MODEL_SHA256="4851ec156207d271f5328605d0582eeb851e656227da8aca093ced9e60789291";
    private static final long MODEL_MIN_SIZE=60000000L;
    private static final int MAX_WORKING=2400;

    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final ArrayList<Uri> selected=new ArrayList<>();
    private ActivityResultLauncher<Intent> picker;
    private TextView counter,status,modelBadge,resultTitle;
    private ProgressBar progress;
    private Button selectButton,aiButton,saveButton;
    private ImageView beforeView,afterView;
    private LinearLayout resultsList;
    private String mode="AUTOMATISCH";
    private OrtEnvironment ortEnv; private OrtSession ortSession; private FaceDetector faceDetector;
    private Bitmap lastResult; private boolean processing=false;

    @Override protected void onCreate(Bundle state){super.onCreate(state); getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        picker=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),r->{if(r.getResultCode()!=RESULT_OK||r.getData()==null)return;Intent d=r.getData();selected.clear();if(d.getClipData()!=null){int n=Math.min(100,d.getClipData().getItemCount());for(int i=0;i<n;i++)selected.add(d.getClipData().getItemAt(i).getUri());}else if(d.getData()!=null)selected.add(d.getData());counter.setText(selected.size()==1?"1 foto geselecteerd":selected.size()+" foto's geselecteerd");aiButton.setEnabled(!selected.isEmpty()&&ortSession!=null);status.setText(ortSession==null?"Foto's klaar • AI-engine wordt voorbereid":"Klaar voor AI PERFECT");if(!selected.isEmpty())showPreview(selected.get(0));});
        buildUi(); initFaceDetector(); initOrt();
    }

    private void buildUi(){ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(16),dp(18),dp(28));scroll.addView(root,new ScrollView.LayoutParams(-1,-1));
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);TextView title=tv("AI FOTOGRAAF PRO",27,TEXT,true);title.setSingleLine(true);header.addView(title,weightLp(0,dp(48),1));TextView pro=tv("PRO",11,BG,true);pro.setGravity(Gravity.CENTER);pro.setBackground(round(ACCENT,18));header.addView(pro,new LinearLayout.LayoutParams(dp(52),dp(34)));root.addView(header,lpMargin(-1,dp(48),0,0,0,6));
        root.addView(tv("PHOTOS BY LOES  •  ECHTE LOKALE AI",12,MUTED,true),lpMargin(-1,dp(24),0,0,0,8));
        LinearLayout hero=card();hero.addView(tv("Maak van elke foto een PRO-foto",18,TEXT,true),wrap(-1));hero.addView(tv("Kwaliteitsgerichte AI: behoud van echte details, natuurlijke gezichten en originele kleur.",13,MUTED,false),wrap(-1));modelBadge=tv("●  AI-ENGINE WORDT GESTART...",11,MUTED,true);modelBadge.setPadding(0,dp(8),0,0);hero.addView(modelBadge,wrap(-1));root.addView(hero,lpMargin(-1,-2,0,0,0,12));
        counter=tv("Nog geen foto's geselecteerd",13,MUTED,false);root.addView(counter,lpMargin(-1,dp(28),0,0,0,8));
        selectButton=bigButton("＋  FOTO'S KIEZEN  •  MAX. 100",CARD2,TEXT);root.addView(selectButton,lpMargin(-1,dp(54),0,0,0,14));selectButton.setOnClickListener(v->openPicker());
        root.addView(tv("BEWERKPROFIEL",11,MUTED,true),lpMargin(-1,dp(22),0,0,0,7));HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout modes=new LinearLayout(this);modes.setOrientation(LinearLayout.HORIZONTAL);for(String m:new String[]{"AUTOMATISCH","PORTRET","LANDSCHAP","LOW LIGHT"}){Button b=smallButton(m,m.equals(mode));LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(dp(126),dp(42));mp.setMargins(0,0,dp(8),0);modes.addView(b,mp);b.setOnClickListener(v->{mode=((Button)v).getText().toString();refreshModes(modes);});}hs.addView(modes,new HorizontalScrollView.LayoutParams(-2,dp(42)));root.addView(hs,lpMargin(-1,dp(42),0,0,0,14));
        LinearLayout preview=card();preview.addView(tv("VOOR / NA",11,MUTED,true),wrap(-1));LinearLayout cmp=new LinearLayout(this);cmp.setOrientation(LinearLayout.HORIZONTAL);cmp.setPadding(0,dp(8),0,0);LinearLayout bp=previewPane("ORIGINEEL",true),ap=previewPane("AI PERFECT",false);cmp.addView(bp,weightLp(0,dp(194),1));cmp.addView(new View(this),new LinearLayout.LayoutParams(dp(8),1));cmp.addView(ap,weightLp(0,dp(194),1));preview.addView(cmp,wrap(-1));root.addView(preview,lpMargin(-1,-2,0,0,0,12));
        aiButton=bigButton("✦  AI PERFECT  •  VERBETER FOTO'S",ACCENT,BG);aiButton.setEnabled(false);root.addView(aiButton,lpMargin(-1,dp(58),0,0,0,8));aiButton.setOnClickListener(v->processAll());
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);progress.setProgress(0);root.addView(progress,lpMargin(-1,dp(8),0,0,0,4));status=tv("AI-engine voorbereiden...",12,MUTED,false);root.addView(status,lpMargin(-1,dp(30),0,0,0,12));
        LinearLayout tools=card();tools.addView(tv("PRO-FUNCTIES",11,MUTED,true),wrap(-1));for(String f:new String[]{"AI-detailherstel met kwaliteitscontrole","Gezichtsdetectie en face-safe processing","Slimme belichting en schaduwherstel","Kleur & witbalans","Natuurlijke ruis- en scherptebalans","Behoud van originele beeldkwaliteit"}){TextView row=tv("✓  "+f,13,TEXT,false);row.setPadding(0,dp(3),0,dp(3));tools.addView(row,wrap(-1));}root.addView(tools,lpMargin(-1,-2,0,0,0,12));
        LinearLayout result=card();resultTitle=tv("RESULTATEN",11,MUTED,true);result.addView(resultTitle,wrap(-1));resultsList=new LinearLayout(this);resultsList.setOrientation(LinearLayout.VERTICAL);result.addView(resultsList,wrap(-1));saveButton=bigButton("OPSLAAN / OPENEN IN FOTO'S",CARD2,TEXT);saveButton.setEnabled(false);result.addView(saveButton,lpMargin(-1,dp(50),0,0,0,0));saveButton.setOnClickListener(v->openGalleryFolder());root.addView(result,lpMargin(-1,-2,0,0,0,12));
        TextView privacy=tv("Privacy: foto's verlaten je telefoon niet. Het AI-model wordt alleen eenmalig opgehaald.",11,MUTED,false);privacy.setLineSpacing(0,1.05f);root.addView(privacy,wrap(-1));setContentView(scroll);
    }

    private void refreshModes(LinearLayout m){for(int i=0;i<m.getChildCount();i++){Button b=(Button)m.getChildAt(i);boolean a=b.getText().toString().equals(mode);b.setBackground(round(a?ACCENT:CARD2,22));b.setTextColor(a?BG:TEXT);}}
    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(14),dp(13),dp(14),dp(13));l.setBackground(round(CARD,18));return l;}
    private LinearLayout previewPane(String label,boolean before){LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);TextView t=tv(label,10,MUTED,true);t.setPadding(dp(2),0,0,dp(5));p.addView(t,wrap(-1));ImageView im=imageBox(label);if(before)beforeView=im;else afterView=im;p.addView(im,new LinearLayout.LayoutParams(-1,dp(164)));return p;}
    private ImageView imageBox(String label){ImageView v=new ImageView(this);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(round(CARD2,14));v.setContentDescription(label);return v;}
    private Button bigButton(String s,int bg,int fg){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setTextColor(fg);b.setAllCaps(false);b.setGravity(Gravity.CENTER);b.setBackground(round(bg,16));b.setPadding(dp(10),0,dp(10),0);b.setMinHeight(0);b.setMinWidth(0);return b;}
    private Button smallButton(String s,boolean a){return bigButton(s,a?ACCENT:CARD2,a?BG:TEXT);}
    private TextView tv(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private LinearLayout.LayoutParams wrap(int w){return new LinearLayout.LayoutParams(w,-2);}private LinearLayout.LayoutParams weightLp(int w,int h,float weight){return new LinearLayout.LayoutParams(w,h,weight);}private LinearLayout.LayoutParams lpMargin(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}private android.graphics.drawable.GradientDrawable round(int c,float r){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(c);g.setCornerRadius(dp((int)r));return g;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private void openPicker(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);picker.launch(i);}

    private void initFaceDetector(){FaceDetectorOptions o=new FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE).setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE).build();faceDetector=FaceDetection.getClient(o);}
    private void initOrt(){executor.execute(()->{try{ortEnv=OrtEnvironment.getEnvironment();File model=new File(getFilesDir(),"RealESRGAN_x4plus.onnx");if(!isValidModel(model)){ui(()->{status.setText("AI-model wordt eenmalig gedownload...");modelBadge.setText("●  AI-MODEL DOWNLOADEN");});downloadModel(model);}OrtSession.SessionOptions opts=new OrtSession.SessionOptions();opts.setIntraOpNumThreads(Math.max(2,Runtime.getRuntime().availableProcessors()/2));ortSession=ortEnv.createSession(model.getAbsolutePath(),opts);ui(()->{modelBadge.setText("●  AI-ENGINE ACTIEF  •  KWALITEITSMODUS");modelBadge.setTextColor(GREEN);aiButton.setEnabled(!selected.isEmpty());status.setText(selected.isEmpty()?"Kies foto's om te beginnen":"Klaar voor AI PERFECT");});}catch(Exception e){ui(()->{modelBadge.setText("●  AI-ENGINE FOUT");modelBadge.setTextColor(Color.rgb(230,90,90));status.setText("AI-model laden mislukt: "+e.getMessage());});}});}
    private boolean isValidModel(File f)throws Exception{return f.exists()&&f.length()>=MODEL_MIN_SIZE&&MODEL_SHA256.equalsIgnoreCase(sha256(f));}
    private void downloadModel(File out)throws Exception{File tmp=new File(getFilesDir(),"RealESRGAN_x4plus.onnx.part");if(tmp.exists())tmp.delete();HttpURLConnection c=(HttpURLConnection)new URL(MODEL_URL).openConnection();c.setConnectTimeout(30000);c.setReadTimeout(180000);c.setInstanceFollowRedirects(true);c.setRequestProperty("User-Agent","AI-Fotograaf-PRO/13.0");c.connect();if(c.getResponseCode()!=200)throw new Exception("HTTP "+c.getResponseCode());long total=c.getContentLengthLong();try(InputStream in=new BufferedInputStream(c.getInputStream());OutputStream os=new BufferedOutputStream(new FileOutputStream(tmp))){byte[]buf=new byte[1024*1024];long done=0;int n;while((n=in.read(buf))!=-1){os.write(buf,0,n);done+=n;final int pp=total>0?(int)Math.min(100,done*100/total):0;ui(()->{status.setText("AI-model downloaden... "+pp+"%");progress.setProgress(pp);});}}finally{c.disconnect();}if(!isValidModel(tmp)){tmp.delete();throw new Exception("Modelcontrole mislukt");}if(out.exists())out.delete();if(!tmp.renameTo(out))throw new Exception("Model opslaan mislukt");}
    private String sha256(File f)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[]b=new byte[1024*1024];int n;while((n=in.read(b))!=-1)md.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte b:md.digest())s.append(String.format(Locale.US,"%02x",b));return s.toString();}

    private void showPreview(Uri u){executor.execute(()->{try{Bitmap b=decodeScaled(u,900);ui(()->beforeView.setImageBitmap(b));}catch(Exception ignored){}});}
    private void processAll(){if(processing)return;if(selected.isEmpty()){Toast.makeText(this,"Kies eerst een foto",Toast.LENGTH_SHORT).show();return;}if(ortSession==null){Toast.makeText(this,"AI-engine wordt nog geladen",Toast.LENGTH_SHORT).show();return;}processing=true;aiButton.setEnabled(false);selectButton.setEnabled(false);saveButton.setEnabled(false);resultsList.removeAllViews();progress.setIndeterminate(false);progress.setProgress(0);status.setText("AI PERFECT gestart • kwaliteitsanalyse...");resultTitle.setText("RESULTATEN  •  BEZIG");executor.execute(()->{int done=0;for(Uri uri:selected){try{final int current=done+1;ui(()->status.setText("AI PERFECT • foto "+current+" / "+selected.size()+" • analyseren..."));Bitmap src=decodeScaled(uri,MAX_WORKING);List<Rect>faces=detectFaces(src);ui(()->status.setText("AI PERFECT • foto "+current+" / "+selected.size()+" • "+faces.size()+" gezicht(en) beschermd"));Bitmap result=qualityEnhance(src,faces);if(Math.max(src.getWidth(),src.getHeight())<1200){ui(()->status.setText("AI PERFECT • detailherstel..."));Bitmap ai=runAiConservative(src);if(ai!=null){result=blendDetail(src,ai,0.18f);ai.recycle();result=qualityEnhance(result,faces);}}saveToGallery(result);lastResult=result;int d=++done;Bitmap showSrc=src,showRes=result;ui(()->{beforeView.setImageBitmap(showSrc);afterView.setImageBitmap(showRes);progress.setProgress(d*100/selected.size());status.setText("AI verwerkt: "+d+" / "+selected.size());resultTitle.setText("RESULTATEN  •  "+d+" KLAAR");addResultRow(d);});}catch(Exception e){String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();ui(()->Toast.makeText(this,"AI-fout: "+msg,Toast.LENGTH_LONG).show());} }final int c=done;ui(()->{processing=false;aiButton.setEnabled(true);selectButton.setEnabled(true);saveButton.setEnabled(c>0);status.setText(c>0?"Klaar • originele details beschermd • opgeslagen in Foto's / AI Fotograaf PRO":"Geen foto kon worden verwerkt");resultTitle.setText("RESULTATEN  •  "+c+" KLAAR");});});}
    private void addResultRow(int n){TextView r=tv("✓  Foto "+n+"  •  AI PERFECT  •  kwaliteitsmodus",12,GREEN,false);resultsList.addView(r,wrap(-1));}

    private Bitmap decodeScaled(Uri uri,int max)throws Exception{BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,o);}int w=o.outWidth,h=o.outHeight;if(w<=0||h<=0)throw new Exception("Ongeldige foto");float sc=Math.min(1f,max/(float)Math.max(w,h));int nw=Math.max(1,Math.round(w*sc)),nh=Math.max(1,Math.round(h*sc));BitmapFactory.Options p=new BitmapFactory.Options();p.inPreferredConfig=Bitmap.Config.ARGB_8888;Bitmap b;try(InputStream in=getContentResolver().openInputStream(uri)){b=BitmapFactory.decodeStream(in,null,p);}if(b==null)throw new Exception("Afbeelding kon niet worden gelezen");Bitmap scaled=Bitmap.createScaledBitmap(b,nw,nh,true);if(scaled!=b)b.recycle();try(InputStream exifIn=getContentResolver().openInputStream(uri)){ExifInterface exif=new ExifInterface(exifIn);int ori=exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);Matrix m=new Matrix();if(ori==ExifInterface.ORIENTATION_ROTATE_90)m.postRotate(90);else if(ori==ExifInterface.ORIENTATION_ROTATE_180)m.postRotate(180);else if(ori==ExifInterface.ORIENTATION_ROTATE_270)m.postRotate(270);else if(ori==ExifInterface.ORIENTATION_FLIP_HORIZONTAL)m.setScale(-1,1);else if(ori==ExifInterface.ORIENTATION_FLIP_VERTICAL)m.setScale(1,-1);if(!m.isIdentity()){Bitmap f=Bitmap.createBitmap(scaled,0,0,scaled.getWidth(),scaled.getHeight(),m,true);if(f!=scaled)scaled.recycle();scaled=f;}}catch(Exception ignored){}return scaled;}

    private List<Rect> detectFaces(Bitmap b)throws Exception{if(faceDetector==null)return Collections.emptyList();List<Face> faces=Tasks.await(faceDetector.process(InputImage.fromBitmap(b,0)));ArrayList<Rect> r=new ArrayList<>();for(Face f:faces)r.add(new Rect(f.getBoundingBox()));return r;}
    private boolean inFace(int x,int y,List<Rect> faces){for(Rect r:faces){int pad=Math.max(8,(int)(Math.max(r.width(),r.height())*.08));if(x>=r.left-pad&&x<=r.right+pad&&y>=r.top-pad&&y<=r.bottom+pad)return true;}return false;}

    private Bitmap qualityEnhance(Bitmap src,List<Rect>faces){Bitmap b=src.copy(Bitmap.Config.ARGB_8888,true);int w=b.getWidth(),h=b.getHeight();int[]p=new int[w*h];b.getPixels(p,0,w,0,0,w,h);long sr=0,sg=0,sb=0,count=0;for(int y=0;y<h;y+=16)for(int x=0;x<w;x+=16){int c=p[y*w+x];sr+=Color.red(c);sg+=Color.green(c);sb+=Color.blue(c);count++;}float ar=sr/(float)count,ag=sg/(float)count,ab=sb/(float)count;float wbR=clampf(ag/(ar+1e-3f),.97f,1.03f),wbB=clampf(ag/(ab+1e-3f),.97f,1.03f);float target=mode.equals("LOW LIGHT")?118:mode.equals("LANDSCHAP")?126:122;float avg=(ar*.299f+ag*.587f+ab*.114f);float exposure=clampf((target/(avg+1e-3f)),.94f,1.10f);float sat=mode.equals("LANDSCHAP")?1.035f:mode.equals("LOW LIGHT")?1.015f:1.025f;float contrast=mode.equals("PORTRET")?1.012f:1.018f;float sharpen=mode.equals("PORTRET")?.045f:.09f;if(mode.equals("LOW LIGHT"))sharpen=.055f;int[]q=p.clone();for(int y=1;y<h-1;y++){for(int x=1;x<w-1;x++){int i=y*w+x;int c=p[i];float r=Color.red(c)*wbR*exposure,g=Color.green(c)*exposure,bl=Color.blue(c)*wbB*exposure;float lum=(r*.299f+g*.587f+bl*.114f);float shadow=lum<75?Math.min(8f,(75-lum)*.10f):0;float highlight=lum>205?(lum-205)*.05f:0;r-=highlight;g-=highlight;bl-=highlight;r+=shadow;g+=shadow;bl+=shadow;r=(r-128)*contrast+128;g=(g-128)*contrast+128;bl=(bl-128)*contrast+128;float gray=(r*.299f+g*.587f+bl*.114f);r=gray+(r-gray)*sat;g=gray+(g-gray)*sat;bl=gray+(bl-gray)*sat;if(!inFace(x,y,faces)&&sharpen>0){float nr=(Color.red(p[i-1])+Color.red(p[i+1])+Color.red(p[i-w])+Color.red(p[i+w]))*.25f;float ng=(Color.green(p[i-1])+Color.green(p[i+1])+Color.green(p[i-w])+Color.green(p[i+w]))*.25f;float nb=(Color.blue(p[i-1])+Color.blue(p[i+1])+Color.blue(p[i-w])+Color.blue(p[i+w]))*.25f;r+=((r-nr)*sharpen);g+=((g-ng)*sharpen);bl+=((bl-nb)*sharpen);}q[i]=Color.rgb(clamp(r),clamp(g),clamp(bl));}}b.setPixels(q,0,w,0,0,w,h);return b;}

    private Bitmap runAiConservative(Bitmap src)throws Exception{int max=512;Bitmap small=Bitmap.createScaledBitmap(src,Math.max(1,Math.round(src.getWidth()*max/(float)Math.max(src.getWidth(),src.getHeight()))),Math.max(1,Math.round(src.getHeight()*max/(float)Math.max(src.getWidth(),src.getHeight()))),true);Bitmap up=infer(small);small.recycle();Bitmap scaled=Bitmap.createScaledBitmap(up,src.getWidth(),src.getHeight(),true);up.recycle();return scaled;}
    private Bitmap blendDetail(Bitmap original,Bitmap ai,float strength){Bitmap out=original.copy(Bitmap.Config.ARGB_8888,true);int w=out.getWidth(),h=out.getHeight();int[] a=new int[w*h],b=new int[w*h];original.getPixels(a,0,w,0,0,w,h);ai.getPixels(b,0,w,0,0,w,h);for(int i=0;i<a.length;i++){int ar=Color.red(a[i]),ag=Color.green(a[i]),ab=Color.blue(a[i]);int br=Color.red(b[i]),bg=Color.green(b[i]),bb=Color.blue(b[i]);float r=ar+(br-ar)*strength,g=ag+(bg-ag)*strength,bl=ab+(bb-ab)*strength;float delta=(br*.299f+bg*.587f+bb*.114f)-(ar*.299f+ag*.587f+ab*.114f);r+=delta*.08f;g+=delta*.08f;bl+=delta*.08f;b[i]=Color.rgb(clamp(r),clamp(g),clamp(bl));}out.setPixels(b,0,w,0,0,w,h);return out;}
    private Bitmap infer(Bitmap src)throws Exception{int w=src.getWidth(),h=src.getHeight();float[]input=new float[3*w*h];int[]px=new int[w*h];src.getPixels(px,0,w,0,0,w,h);int plane=w*h;for(int i=0;i<plane;i++){int p=px[i];input[i]=Color.red(p)/255f;input[plane+i]=Color.green(p)/255f;input[2*plane+i]=Color.blue(p)/255f;}OnnxTensor t=OnnxTensor.createTensor(ortEnv,FloatBuffer.wrap(input),new long[]{1,3,h,w});String name=ortSession.getInputNames().iterator().next();OrtSession.Result res=ortSession.run(Collections.singletonMap(name,t));float[][][][]out=(float[][][][])res.get(0).getValue();int oh=out[0][0].length,ow=out[0][0][0].length;Bitmap d=Bitmap.createBitmap(ow,oh,Bitmap.Config.ARGB_8888);int[]op=new int[ow*oh];for(int y=0;y<oh;y++)for(int x=0;x<ow;x++)op[y*ow+x]=Color.rgb(clamp(out[0][0][y][x]*255),clamp(out[0][1][y][x]*255),clamp(out[0][2][y][x]*255));d.setPixels(op,0,ow,0,0,ow,oh);res.close();t.close();return d;}
    private float clampf(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}private int clamp(float v){return (int)Math.max(0,Math.min(255,v));}
    private void saveToGallery(Bitmap b)throws Exception{ContentResolver cr=getContentResolver();ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,"AI_"+System.currentTimeMillis()+".jpg");v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/AI Fotograaf PRO");Uri u=cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(u==null)throw new Exception("Opslaan mislukt");try(OutputStream out=cr.openOutputStream(u)){if(!b.compress(Bitmap.CompressFormat.JPEG,97,out))throw new Exception("JPEG opslaan mislukt");}}
    private void openGalleryFolder(){Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,"image/*");try{startActivity(i);}catch(Exception e){Toast.makeText(this,"Foto's openen lukt niet",Toast.LENGTH_SHORT).show();}}
    private void ui(Runnable r){runOnUiThread(r);}
    @Override protected void onDestroy(){executor.shutdownNow();if(faceDetector!=null)faceDetector.close();if(ortSession!=null){try{ortSession.close();}catch(Exception ignored){}}super.onDestroy();}
}
