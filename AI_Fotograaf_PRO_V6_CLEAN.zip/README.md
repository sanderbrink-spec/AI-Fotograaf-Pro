# AI Fotograaf Pro V6 - Photos by Loes

Clean rebuild. Uses the Android system camera and gallery, so it has no CameraX ambiguity or ML dependency. Includes local photo enhancement, batch processing, and before/after comparison.
