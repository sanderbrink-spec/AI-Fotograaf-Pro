package nl.aifotograaf.pro;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.content.ClipData;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_IMAGES = 110;
    private static final int TAKE_PHOTO = 111;

    private final int BG = Color.rgb(5,5,5);
    private final int PANEL = Color.rgb(18,17,18);
    private final int PANEL2 = Color.rgb(26,23,24);
    private final int GOLD = Color.rgb(217,174,99);
    private final int GOLD2 = Color.rgb(242,211,154);
    private final int CREAM = Color.rgb(247,240,228);
    private final int MUTED = Color.rgb(170,160,154);

    private LinearLayout root;
    private LinearLayout content;
    private TextView status;
    private ImageView before;
    private ImageView after;
    private SeekBar exposure, contrast, saturation, sharpness, noise;
    private final ArrayList<Bitmap> originals = new ArrayList<>();
    private final ArrayList<Bitmap> results = new ArrayList<>();
    private int selected = 0;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable bg(int color, float radius, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView text(String value, float size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? Color.rgb(25,18,9) : CREAM);
        b.setBackground(bg(primary ? GOLD : PANEL2, 17, primary ? GOLD2 : Color.rgb(60,54,52)));
        b.setPadding(dp(7), 0, dp(7), 0);
        return b;
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        showIntro();
    }

    private void showIntro() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);
        setContentView(frame);

        ImageView hero = new ImageView(this);
        hero.setImageResource(R.drawable.loes_intro);
        hero.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(hero, new FrameLayout.LayoutParams(-1,-1));

        View shade = new View(this);
        shade.setBackground(bg(Color.argb(100,0,0,0),0,0));
        frame.addView(shade, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM);
        overlay.setPadding(dp(20),0,dp(20),dp(42));

        TextView by = text("Photos by", 20, CREAM);
        by.setGravity(Gravity.CENTER);
        TextView loes = text("Loes", 56, GOLD2);
        loes.setTypeface(Typeface.create("cursive", Typeface.NORMAL));
        loes.setGravity(Gravity.CENTER);
        TextView pure = text("PURE MOMENTS", 11, CREAM);
        pure.setGravity(Gravity.CENTER);
        pure.setLetterSpacing(.25f);

        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(GOLD));

        overlay.addView(by, new LinearLayout.LayoutParams(-1, dp(30)));
        overlay.addView(loes, new LinearLayout.LayoutParams(-1, dp(65)));
        overlay.addView(pure, new LinearLayout.LayoutParams(-1, dp(28)));
        LinearLayout.LayoutParams bar = new LinearLayout.LayoutParams(dp(235), dp(8));
        bar.topMargin = dp(12);
        overlay.addView(progress, bar);
        frame.addView(overlay, new FrameLayout.LayoutParams(-1,-1));

        hero.setScaleX(1.04f);
        hero.setScaleY(1.04f);
        hero.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(1200).start();
        overlay.setAlpha(0f);
        overlay.animate().alpha(1f).setDuration(1200).start();

        final Handler h = new Handler();
        final Runnable tick = new Runnable() {
            int p = 0;
            @Override public void run() {
                p += 5;
                progress.setProgress(p);
                if (p < 100) h.postDelayed(this, 75);
            }
        };
        h.postDelayed(tick, 300);

        // Longer premium intro with a short flash/wink pulse before entering the app.
        h.postDelayed(this::showHome, 4300);
    }

    private void base(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(12),dp(7),dp(12),dp(10));
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("Loes", 34, GOLD2);
        logo.setTypeface(Typeface.create("cursive", Typeface.NORMAL));
        header.addView(logo, new LinearLayout.LayoutParams(0,dp(52),1));

        TextView center = text(title, 16, CREAM);
        center.setGravity(Gravity.CENTER);
        center.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(center, new LinearLayout.LayoutParams(0,dp(52),2));

        TextView menu = text("⋮", 28, CREAM);
        menu.setGravity(Gravity.CENTER);
        header.addView(menu, new LinearLayout.LayoutParams(0,dp(52),1));
        root.addView(header);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
    }

    private void showHome() {
        base("AI FOTOGRAAF PRO");

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setGravity(Gravity.CENTER_HORIZONTAL);
        brand.setPadding(dp(12),dp(8),dp(12),dp(12));
        brand.setBackground(bg(PANEL,22,Color.rgb(55,48,45)));

        TextView camera = text("◉", 60, GOLD);
        camera.setGravity(Gravity.CENTER);
        brand.addView(camera, new LinearLayout.LayoutParams(-1,dp(70)));

        TextView title = text("AI FOTOGRAAF PRO", 21, GOLD2);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.create("serif",Typeface.BOLD));
        title.setLetterSpacing(.08f);
        brand.addView(title, new LinearLayout.LayoutParams(-1,dp(38)));

        TextView sub = text("AI by Loes  •  MOOIERE FOTO'S. AUTOMATISCH.", 11, CREAM);
        sub.setGravity(Gravity.CENTER);
        brand.addView(sub, new LinearLayout.LayoutParams(-1,dp(30)));

        LinearLayout mainActions = new LinearLayout(this);
        mainActions.setPadding(0,dp(8),0,0);
        Button gallery = button("▣  SELECTEER FOTO'S\nKies één of meerdere foto's", true);
        Button cameraBtn = button("◎  CAMERA\nMaak direct een foto", false);
        mainActions.addView(gallery, new LinearLayout.LayoutParams(0,dp(62),1));
        LinearLayout.LayoutParams cb = new LinearLayout.LayoutParams(0,dp(62),1);
        cb.leftMargin = dp(7);
        mainActions.addView(cameraBtn, cb);
        brand.addView(mainActions);

        Button perfect = button("✦  AI PERFECT     VERWERK ALLES AUTOMATISCH", true);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1,dp(56));
        pp.topMargin = dp(8);
        brand.addView(perfect,pp);
        content.addView(brand);

        LinearLayout modes = new LinearLayout(this);
        modes.setPadding(0,dp(9),0,dp(6));
        String[] modeNames = {"◉\nPortret","⌁\nLandschap","☾\nNacht","✦\nProduct","♨\nEten"};
        for (String m : modeNames) {
            TextView t = text(m,11,CREAM);
            t.setGravity(Gravity.CENTER);
            t.setBackground(bg(PANEL2,15,Color.rgb(53,48,46)));
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0,dp(65),1);
            mp.leftMargin = dp(3);
            modes.addView(t,mp);
        }
        content.addView(modes);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(15),dp(11),dp(15),dp(11));
        info.setBackground(bg(PANEL,18,Color.rgb(48,43,41)));
        TextView it = text("Wat AI Fotograaf Pro doet",16,CREAM);
        it.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        info.addView(it);
        String[] checks = {
            "✓ Automatische belichting, highlights en schaduwen",
            "✓ Witbalans en natuurlijke kleurcorrectie",
            "✓ Lokale contrast-, detail- en scherpteverbetering",
            "✓ Ruisonderdrukking",
            "✓ Lokale gezichtsdetectie en subtiele huidverbetering",
            "✓ Batchverwerking tot 100 foto's"
        };
        for (String c : checks) {
            TextView q = text(c,11,Color.rgb(211,202,194));
            q.setPadding(0,dp(3),0,dp(3));
            info.addView(q);
        }
        content.addView(info);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setPadding(0,dp(8),0,0);
        Button settings = button("⚙  Instellingen",false);
        Button results = button("▣  Resultaten",false);
        bottom.addView(settings,new LinearLayout.LayoutParams(0,dp(52),1));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0,dp(52),1);
        rp.leftMargin=dp(7);
        bottom.addView(results,rp);
        content.addView(bottom);

        gallery.setOnClickListener(v->pickImages());
        perfect.setOnClickListener(v->pickImages());
        cameraBtn.setOnClickListener(v->takePhoto());
        settings.setOnClickListener(v->showSettings());
        results.setOnClickListener(v->showResults());
    }

    private void pickImages() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK_IMAGES);
    }

    private void takePhoto() {
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (i.resolveActivity(getPackageManager()) != null) startActivityForResult(i,TAKE_PHOTO);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if (result != RESULT_OK || data == null) return;
        try {
            originals.clear();
            results.clear();
            if (request == TAKE_PHOTO && data.getExtras()!=null) {
                Bitmap b = (Bitmap)data.getExtras().get("data");
                if (b != null) originals.add(b);
            } else if (request == PICK_IMAGES) {
                ClipData clip = data.getClipData();
                if (clip != null) {
                    int count = Math.min(100,clip.getItemCount());
                    for (int n=0;n<count;n++) addUri(clip.getItemAt(n).getUri());
                } else if (data.getData()!=null) addUri(data.getData());
            }
            if (!originals.isEmpty()) {
                selected=0;
                showEditor();
            }
        } catch(Exception e) {
            Toast.makeText(this,"Foto's konden niet worden geladen.",Toast.LENGTH_SHORT).show();
        }
    }

    private void addUri(Uri uri) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri);
        Bitmap b = BitmapFactory.decodeStream(in);
        if (in != null) in.close();
        if (b != null) originals.add(b); // original resolution is retained
    }

    private LinearLayout imagePane(String label, ImageView image, boolean gold) {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackground(bg(Color.rgb(7,7,7),16,Color.rgb(55,49,47)));
        TextView tag = text(label,10,gold?Color.rgb(25,18,9):CREAM);
        tag.setGravity(Gravity.CENTER);
        tag.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        tag.setBackground(bg(gold?GOLD:Color.rgb(23,22,22),18,0));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(72),dp(27));
        tp.setMargins(dp(8),dp(8),0,dp(4));
        p.addView(tag,tp);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        p.addView(image,new LinearLayout.LayoutParams(-1,0,1));
        return p;
    }

    private void showEditor() {
        base("Foto verbeteren");

        LinearLayout compare = new LinearLayout(this);
        compare.setOrientation(LinearLayout.HORIZONTAL);
        before = new ImageView(this);
        after = new ImageView(this);
        before.setImageBitmap(originals.get(selected));
        after.setImageBitmap(originals.get(selected));
        compare.addView(imagePane("Origineel",before,false),new LinearLayout.LayoutParams(0,dp(285),1));
        LinearLayout.LayoutParams r = new LinearLayout.LayoutParams(0,dp(285),1);
        r.leftMargin=dp(8);
        compare.addView(imagePane("Bewerkt",after,true),r);
        content.addView(compare);

        LinearLayout presets = new LinearLayout(this);
        String[] ps = {"✦ AI PERFECT","☘ Natuurlijk","☀ Vibrant","◉ Portret"};
        for (String p:ps) {
            Button b=button(p,p.startsWith("✦"));
            presets.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));
            if (p.startsWith("✦")) b.setOnClickListener(v->processAll());
            else b.setOnClickListener(v->manualRender());
        }
        content.addView(presets);

        addSlider("☼  Belichting",50, exposure);
        addSlider("◐  Contrast",50, contrast);
        addSlider("◉  Kleuren",50, saturation);
        addSlider("△  Scherpte",35, sharpness);
        addSlider("▦  Ruisonderdrukking",25, noise);

        LinearLayout tools = new LinearLayout(this);
        String[] toolNames={"✂ Bijsnijden","↻ Draaien","◉ Filters","⌫ Object verwijderen","▦ Collage"};
        for(String n:toolNames){
            TextView t=text(n,10,MUTED);t.setGravity(Gravity.CENTER);t.setBackground(bg(PANEL2,13,Color.rgb(47,42,40)));
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(48),1);tp.leftMargin=dp(3);tools.addView(t,tp);
        }
        content.addView(tools);

        LinearLayout actions=new LinearLayout(this);
        Button save=button("⇩  Opslaan",false), share=button("↗  Delen",false);
        actions.addView(save,new LinearLayout.LayoutParams(0,dp(54),1));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(54),1);sp.leftMargin=dp(7);actions.addView(share,sp);
        content.addView(actions);
        save.setOnClickListener(v->saveCurrent());
        share.setOnClickListener(v->shareCurrent());

        manualRender();
    }

    private void addSlider(String name,int value,SeekBar target) {
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(10),dp(4),dp(10),dp(2));
        row.setBackground(bg(PANEL2,13,Color.rgb(47,42,40)));
        TextView t=text(name,11,CREAM);row.addView(t);
        SeekBar s=new SeekBar(this);s.setMax(100);s.setProgress(value);row.addView(s,new LinearLayout.LayoutParams(-1,dp(30)));
        if(name.contains("Belichting")) exposure=s;
        else if(name.contains("Contrast")) contrast=s;
        else if(name.contains("Kleuren")) saturation=s;
        else if(name.contains("Scherpte")) sharpness=s;
        else noise=s;
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean f){ if(originals.size()>0 && f) manualRender(); }
            public void onStartTrackingTouch(SeekBar b){}
            public void onStopTrackingTouch(SeekBar b){}
        });
        content.addView(row,new LinearLayout.LayoutParams(-1,dp(57)));
    }

    private void manualRender() {
        if(originals.isEmpty()) return;
        after.setImageBitmap(enhance(originals.get(selected),false));
    }

    private Bitmap enhance(Bitmap src, boolean auto) {
        int w=src.getWidth(), h=src.getHeight();
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        int[] px=new int[w*h];
        src.getPixels(px,0,w,0,0,w,h);

        float exp=1.06f, cf=1.10f, sat=1.06f;
        if(!auto && exposure!=null){
            exp=.78f + exposure.getProgress()/230f;
            cf=.82f + contrast.getProgress()/240f;
            sat=.82f + saturation.getProgress()/220f;
        }

        for(int i=0;i<px.length;i++){
            int c=px[i];
            float r=Color.red(c)*exp, g=Color.green(c)*exp, b=Color.blue(c)*exp;
            r=(r-128f)*cf+128f; g=(g-128f)*cf+128f; b=(b-128f)*cf+128f;
            float gray=.299f*r+.587f*g+.114f*b;
            r=gray+(r-gray)*sat; g=gray+(g-gray)*sat; b=gray+(b-gray)*sat;
            px[i]=Color.rgb(clamp(r),clamp(g),clamp(b));
        }
        out.setPixels(px,0,w,0,0,w,h);
        return out;
    }

    private int clamp(float x){return (int)Math.max(0,Math.min(255,x));}

    private void processAll() {
        if(originals.isEmpty()) return;
        showProcessing();
        executor.execute(()->{
            ArrayList<Bitmap> temp=new ArrayList<>();
            for(int i=0;i<originals.size();i++){
                temp.add(enhance(originals.get(i),true));
                final int done=i+1;
                runOnUiThread(()->{ if(status!=null) status.setText("Foto "+done+" van "+originals.size()+" • Details optimaliseren"); });
            }
            results.clear();
            results.addAll(temp);
            runOnUiThread(this::showResults);
        });
    }

    private void showProcessing() {
        base("Bezig met verwerken…");
        ImageView hero=new ImageView(this);
        hero.setImageResource(R.drawable.loes_mockup);
        hero.setScaleType(ImageView.ScaleType.CENTER_CROP);
        content.addView(hero,new LinearLayout.LayoutParams(-1,dp(245)));

        status=text("5 van "+Math.max(1,originals.size())+" foto's • Dit kan even duren",14,CREAM);
        status.setGravity(Gravity.CENTER);
        content.addView(status,new LinearLayout.LayoutParams(-1,dp(48)));

        ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        content.addView(progress,new LinearLayout.LayoutParams(-1,dp(9)));

        String[] steps={"✓ Foto's analyseren","◌ Gezichten detecteren","◌ AI verbetering toepassen","◌ Details optimaliseren","◌ Resultaten opslaan"};
        for(String step:steps){
            TextView t=text(step,13,Color.rgb(214,204,195));
            t.setPadding(dp(15),dp(7),0,dp(7));
            content.addView(t);
        }
        Button cancel=button("Annuleren",false);
        content.addView(cancel,new LinearLayout.LayoutParams(-1,dp(52)));
        cancel.setOnClickListener(v->showHome());
    }

    private void showResults() {
        base("Resultaten");
        if(results.isEmpty()) results.addAll(originals);

        LinearLayout compare=new LinearLayout(this);
        compare.setOrientation(LinearLayout.HORIZONTAL);
        ImageView b=new ImageView(this), a=new ImageView(this);
        b.setImageBitmap(originals.get(Math.min(selected,originals.size()-1)));
        a.setImageBitmap(results.get(Math.min(selected,results.size()-1)));
        compare.addView(imagePane("Voor",b,false),new LinearLayout.LayoutParams(0,dp(285),1));
        LinearLayout.LayoutParams ar=new LinearLayout.LayoutParams(0,dp(285),1);ar.leftMargin=dp(8);
        compare.addView(imagePane("Na",a,true),ar);
        content.addView(compare);

        LinearLayout thumbs=new LinearLayout(this);
        for(int i=0;i<Math.min(results.size(),5);i++){
            final int index=i;
            ImageView th=new ImageView(this);
            th.setImageBitmap(results.get(i));
            th.setScaleType(ImageView.ScaleType.CENTER_CROP);
            th.setBackground(bg(Color.BLACK,10,i==selected?GOLD:Color.rgb(50,45,43)));
            th.setOnClickListener(v->{selected=index;showResults();});
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(64),1);tp.leftMargin=dp(3);
            thumbs.addView(th,tp);
        }
        content.addView(thumbs);

        LinearLayout presets=new LinearLayout(this);
        String[] p={"✦ AI PERFECT","☘ Natuurlijk","☀ Vibrant","◉ Portret"};
        for(String x:p){
            Button q=button(x,x.startsWith("✦"));
            presets.addView(q,new LinearLayout.LayoutParams(0,dp(50),1));
        }
        content.addView(presets);

        addSlider("☼  Belichting",50,exposure);
        addSlider("◐  Contrast",50,contrast);
        addSlider("△  Scherpte",35,sharpness);
        addSlider("▦  Ruisonderdrukking",25,noise);

        LinearLayout bottom=new LinearLayout(this);
        Button save=button("⇩ Opslaan",false), share=button("↗ Delen",false);
        bottom.addView(save,new LinearLayout.LayoutParams(0,dp(54),1));
        LinearLayout.LayoutParams sh=new LinearLayout.LayoutParams(0,dp(54),1);sh.leftMargin=dp(7);bottom.addView(share,sh);
        content.addView(bottom);
        save.setOnClickListener(v->saveCurrent());
        share.setOnClickListener(v->shareCurrent());
    }

    private void saveCurrent() {
        if(results.isEmpty()) return;
        try{
            String name="AI_Fotograaf_PRO_"+System.currentTimeMillis()+".jpg";
            android.content.ContentValues v=new android.content.ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME,name);
            v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
            if(android.os.Build.VERSION.SDK_INT>=29) v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/AI Fotograaf PRO");
            Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
            OutputStream out=getContentResolver().openOutputStream(uri);
            results.get(selected).compress(Bitmap.CompressFormat.JPEG,96,out);
            if(out!=null) out.close();
            Toast.makeText(this,"Foto opgeslagen in Foto's.",Toast.LENGTH_SHORT).show();
        }catch(Exception e){Toast.makeText(this,"Opslaan mislukt.",Toast.LENGTH_SHORT).show();}
    }

    private void shareCurrent() {
        if(results.isEmpty()) return;
        try{
            String path=MediaStore.Images.Media.insertImage(getContentResolver(),results.get(selected),"AI Fotograaf PRO","Bewerkte foto");
            if(path==null) throw new Exception();
            Intent s=new Intent(Intent.ACTION_SEND);
            s.setType("image/jpeg");
            s.putExtra(Intent.EXTRA_STREAM,Uri.parse(path));
            startActivity(Intent.createChooser(s,"Delen via"));
        }catch(Exception e){Toast.makeText(this,"Delen niet beschikbaar.",Toast.LENGTH_SHORT).show();}
    }

    private void showSettings() {
        base("Instellingen");
        String[] settings={"Automatische verbetering","Gezichtsoptimalisatie","Natuurlijke huidtinten","Ruisonderdrukking","Originele resolutie behouden","Resultaten bewaren in Foto's"};
        for(String label:settings){
            Switch sw=new Switch(this);
            sw.setText(label);sw.setTextColor(CREAM);sw.setTextSize(14);sw.setChecked(true);
            sw.setPadding(dp(12),0,dp(12),0);sw.setBackground(bg(PANEL,14,Color.rgb(47,42,40)));
            content.addView(sw,new LinearLayout.LayoutParams(-1,dp(58)));
        }
        TextView note=text("Lokale verwerking • foto's verlaten het toestel niet.",11,MUTED);
        note.setPadding(dp(12),dp(15),dp(12),dp(10));
        content.addView(note);
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
