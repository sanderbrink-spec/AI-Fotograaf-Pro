package nl.aifotograaf.pro;

import android.animation.ObjectAnimator;
import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int PICK = 1001;
    ImageView beforeView, afterView;
    Bitmap original, enhanced;
    TextView status, exposureValue, contrastValue, colorValue, sharpValue;
    SeekBar exposure, contrast, color, sharpness;
    LinearLayout root;
    final int GOLD = Color.rgb(231,189,114);
    final int GOLD2 = Color.rgb(247,217,154);
    final int BG = Color.rgb(7,7,7);
    final int PANEL = Color.rgb(20,21,24);

    int dp(float v){ return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
    }

    TextView text(String s, float size, int color){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    GradientDrawable bg(int color, float radius, int strokeColor){
        GradientDrawable g=new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        if(strokeColor!=Color.TRANSPARENT) g.setStroke(dp(1),strokeColor);
        return g;
    }

    Button button(String label, boolean primary){
        Button b=new Button(this);
        b.setText(label); b.setTextSize(13); b.setAllCaps(false);
        b.setTextColor(primary ? Color.rgb(25,19,10) : Color.WHITE);
        b.setBackground(bg(primary ? GOLD : Color.rgb(27,28,32),16,
                primary ? GOLD2 : Color.rgb(48,49,54)));
        b.setPadding(dp(10),0,dp(10),0);
        return b;
    }

    void buildUi(){
        ScrollView scroll=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12),dp(10),dp(12),dp(18));
        root.setBackgroundColor(BG);
        scroll.addView(root);
        setContentView(scroll);

        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header,new LinearLayout.LayoutParams(-1,dp(92)));
        CameraLogo logo=new CameraLogo(this); header.addView(logo,new LinearLayout.LayoutParams(dp(82),dp(82)));
        LinearLayout brand=new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        TextView loes=text("Loes ♡",42,GOLD2); loes.setTypeface(Typeface.create("cursive",Typeface.NORMAL));
        brand.addView(loes,new LinearLayout.LayoutParams(-1,dp(45)));
        TextView title=text("PHOTO ENHANCER",15,Color.WHITE); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        title.setLetterSpacing(.18f); brand.addView(title,new LinearLayout.LayoutParams(-1,dp(25)));
        TextView sub=text("MOOIERE FOTO'S. AUTOMATISCH.",10,Color.rgb(190,176,151)); sub.setLetterSpacing(.12f);
        brand.addView(sub,new LinearLayout.LayoutParams(-1,dp(20)));
        header.addView(brand,new LinearLayout.LayoutParams(0,-1,1));

        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        Button choose=button("＋  Foto kiezen",false);
        Button improve=button("📷  Foto verbeteren",true);
        actions.addView(choose,new LinearLayout.LayoutParams(0,dp(52),1));
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,dp(52),1); ip.leftMargin=dp(7); actions.addView(improve,ip);
        root.addView(actions);

        choose.setOnClickListener(v->pickImage());
        improve.setOnClickListener(v->enhance());

        status=text("Kies een foto om te beginnen.",12,Color.rgb(170,170,176));
        status.setPadding(dp(3),dp(8),dp(3),dp(8));
        root.addView(status);

        LinearLayout compare=new LinearLayout(this); compare.setOrientation(LinearLayout.HORIZONTAL);
        compare.setPadding(0,dp(5),0,dp(5));
        LinearLayout left=pane("ORIGINEEL"), right=pane("BEWERKT");
        beforeView=(ImageView)left.getChildAt(1); afterView=(ImageView)right.getChildAt(1);
        compare.addView(left,new LinearLayout.LayoutParams(0,dp(285),1));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(285),1); rp.leftMargin=dp(8); compare.addView(right,rp);
        root.addView(compare);

        TextView section=text("Automatische verbetering",17,Color.WHITE);
        section.setTypeface(Typeface.DEFAULT,Typeface.BOLD); section.setPadding(dp(3),dp(12),0,dp(6)); root.addView(section);

        addSlider("☼  Belichting", exposureValue=new TextView(this), exposure=new SeekBar(this), -30,30,0);
        addSlider("◐  Contrast", contrastValue=new TextView(this), contrast=new SeekBar(this), -30,30,0);
        addSlider("◉  Kleuren", colorValue=new TextView(this), color=new SeekBar(this), -25,25,0);
        addSlider("△  Scherpte", sharpValue=new TextView(this), sharpness=new SeekBar(this), 0,100,0);

        LinearLayout bottom=new LinearLayout(this); bottom.setPadding(0,dp(9),0,0);
        Button reset=button("Origineel",false), save=button("Opslaan",false);
        bottom.addView(reset,new LinearLayout.LayoutParams(0,dp(50),1));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(50),1); sp.leftMargin=dp(7); bottom.addView(save,sp);
        root.addView(bottom);
        reset.setOnClickListener(v->resetImage());
        save.setOnClickListener(v->saveImage());
    }

    LinearLayout pane(String label){
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL);
        p.setBackground(bg(PANEL,16,Color.rgb(42,43,47)));
        TextView tag=text(label,10, label.equals("BEWERKT") ? Color.rgb(25,19,10) : Color.WHITE);
        tag.setTypeface(Typeface.DEFAULT,Typeface.BOLD); tag.setGravity(Gravity.CENTER);
        tag.setBackground(bg(label.equals("BEWERKT")?GOLD:Color.rgb(5,5,5),20,Color.TRANSPARENT));
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(dp(105),dp(28)); tp.gravity=Gravity.TOP|Gravity.LEFT; tp.setMargins(dp(10),dp(10),0,dp(3));
        p.addView(tag,tp);
        ImageView im=new ImageView(this); im.setScaleType(ImageView.ScaleType.FIT_CENTER);
        im.setBackgroundColor(Color.rgb(5,5,6));
        p.addView(im,new LinearLayout.LayoutParams(-1,0,1));
        return p;
    }

    void addSlider(String label, TextView value, SeekBar seek, int min, int max, int initial){
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(12),dp(7),dp(12),dp(5)); row.setBackground(bg(Color.rgb(25,26,29),14,Color.rgb(43,44,48)));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(72)); rp.setMargins(0,dp(5),0,0);
        root.addView(row,rp);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView l=text(label,13,Color.LTGRAY); top.addView(l,new LinearLayout.LayoutParams(0,dp(28),1));
        value.setText("0"); value.setTextColor(GOLD2); value.setTextSize(12); value.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        top.addView(value,new LinearLayout.LayoutParams(dp(48),dp(28))); row.addView(top);
        seek.setMax(max-min); seek.setProgress(initial-min); seek.setProgressDrawable(tintProgress());
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(GOLD));
        row.addView(seek,new LinearLayout.LayoutParams(-1,dp(30)));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean from){ int v=p+min; value.setText((v>0?"+":"")+v); if(original!=null) renderManual(); }
            public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}
        });
    }

    Drawable tintProgress(){
        GradientDrawable g=bg(Color.rgb(50,50,54),10,Color.TRANSPARENT); return g;
    }

    void pickImage(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK);
    }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==PICK && result==RESULT_OK && data!=null){
            try{
                Uri u=data.getData(); InputStream in=getContentResolver().openInputStream(u);
                Bitmap b=BitmapFactory.decodeStream(in); in.close(); setOriginal(b);
            }catch(Exception e){status.setText("Foto kon niet worden geladen.");}
        }
    }

    void setOriginal(Bitmap b){
        if(b==null)return;
        int max=1800; float scale=Math.min(1f,max/(float)Math.max(b.getWidth(),b.getHeight()));
        original=scale<1?Bitmap.createScaledBitmap(b,(int)(b.getWidth()*scale),(int)(b.getHeight()*scale),true):b;
        beforeView.setImageBitmap(original); afterView.setImageBitmap(original);
        status.setText("Foto geladen. Loes kan hem nu verbeteren.");
    }

    void enhance(){
        if(original==null){status.setText("Kies eerst een foto."); return;}
        status.setText("Loes analyseert de foto...");
        new AsyncTask<Void,Integer,Bitmap>(){
            protected void onPreExecute(){ animateButton();}
            protected Bitmap doInBackground(Void... v){
                for(int i=0;i<6;i++){publishProgress(i+1);SystemClock.sleep(140);}
                return improveBitmap(original);
            }
            protected void onProgressUpdate(Integer... p){status.setText(new String[]{"Foto analyseren...","Belichting herstellen...","Dynamisch bereik optimaliseren...","Kleur en witbalans optimaliseren...","Details verbeteren...","Natuurlijke eindcontrole..."}[p[0]-1]);}
            protected void onPostExecute(Bitmap b){
                enhanced=b; afterView.setImageBitmap(b);
                exposure.setProgress(10); contrast.setProgress(40); color.setProgress(31); sharpness.setProgress(32);
                status.setText("Klaar. De foto is natuurlijk verbeterd.");
            }
        }.execute();
    }

    void animateButton(){
        ObjectAnimator a=ObjectAnimator.ofFloat(root,View.ALPHA,1f,.86f,1f); a.setDuration(500); a.start();
    }

    Bitmap improveBitmap(Bitmap src){
        int w=src.getWidth(),h=src.getHeight();
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        int[] px=new int[w*h]; src.getPixels(px,0,w,0,0,w,h);
        long sum=0; for(int i=0;i<px.length;i+=Math.max(1,px.length/50000)){int c=px[i];sum+=(Color.red(c)+Color.green(c)+Color.blue(c))/3;}
        int samples=Math.min(50000,px.length), mean=(int)(sum/Math.max(1,samples));
        float exp=Math.max(.96f,Math.min(1.16f,1f+(128-mean)/900f));
        for(int i=0;i<px.length;i++){
            int c=px[i]; float r=Color.red(c)*exp,g=Color.green(c)*exp,b=Color.blue(c)*exp;
            float cf=1.10f; r=(r-128)*cf+128;g=(g-128)*cf+128;b=(b-128)*cf+128;
            float gray=.299f*r+.587f*g+.114f*b, sat=1.06f;
            r=gray+(r-gray)*sat;g=gray+(g-gray)*sat;b=gray+(b-gray)*sat;
            px[i]=Color.rgb(clamp(r),clamp(g),clamp(b));
        }
        out.setPixels(px,0,w,0,0,w,h);
        return out;
    }

    int clamp(float x){return (int)Math.max(0,Math.min(255,x));}

    void renderManual(){
        if(original==null)return;
        int w=original.getWidth(),h=original.getHeight(); Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        int[] src=new int[w*h], dst=new int[w*h]; original.getPixels(src,0,w,0,0,w,h);
        float e=(float)Math.pow(2,(exposure.getProgress()-30)/100.0);
        float cv=contrast.getProgress()-30; float cf=(259*(cv+255))/(255*(259-cv));
        float sat=1f+(color.getProgress()-25)/100f;
        for(int i=0;i<src.length;i++){
            int c=src[i]; float r=Color.red(c)*e,g=Color.green(c)*e,b=Color.blue(c)*e;
            r=cf*(r-128)+128;g=cf*(g-128)+128;b=cf*(b-128)+128;
            float gr=.299f*r+.587f*g+.114f*b;
            r=gr+(r-gr)*sat;g=gr+(g-gr)*sat;b=gr+(b-gr)*sat;
            dst[i]=Color.rgb(clamp(r),clamp(g),clamp(b));
        }
        out.setPixels(dst,0,w,0,0,w,h); enhanced=out;afterView.setImageBitmap(out);
    }

    void resetImage(){
        if(original==null)return; exposure.setProgress(30);contrast.setProgress(30);color.setProgress(25);sharpness.setProgress(0);
        enhanced=original;afterView.setImageBitmap(original);status.setText("Origineel weergegeven.");
    }

    void saveImage(){
        if(enhanced==null){status.setText("Verbeter eerst een foto.");return;}
        try{
            String name="Loes_Enhanced_"+System.currentTimeMillis()+".jpg";
            ContentValues v=new ContentValues(); v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
            if(Build.VERSION.SDK_INT>=29)v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Loes Photo Enhancer");
            Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
            OutputStream o=getContentResolver().openOutputStream(u); enhanced.compress(Bitmap.CompressFormat.JPEG,96,o);o.close();
            status.setText("Foto opgeslagen in Foto's.");
        }catch(Exception e){status.setText("Opslaan mislukt.");}
    }

    class CameraLogo extends View{
        Paint p=new Paint(3); float t=0;
        CameraLogo(Context c){super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        protected void onDraw(Canvas c){
            super.onDraw(c); float d=getWidth()/90f;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3*d);p.setColor(GOLD);p.setShadowLayer(12*d,0,0,GOLD);
            RectF body=new RectF(8*d,28*d,78*d,68*d);c.drawRoundRect(body,10*d,10*d,p);
            c.drawRoundRect(new RectF(20*d,18*d,44*d,30*d),5*d,5*d,p);
            p.setShadowLayer(0,0,0,0);p.setColor(Color.WHITE);c.drawCircle(45*d,48*d,13*d,p);
            p.setColor(GOLD);c.drawCircle(45*d,48*d,8*d,p);
            p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);
            c.drawCircle(42*d,45*d,2*d,p);
            p.setTextSize(25*d); c.drawText("✦",62*d,23*d,p);
            t+=.04; if(t>6.28)t=0; postInvalidateDelayed(45);
        }
    }
}
