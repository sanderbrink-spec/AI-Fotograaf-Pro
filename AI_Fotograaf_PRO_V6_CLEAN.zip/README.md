# AI Fotograaf PRO V6

Schone Android-basis voor de AI Fotograaf PRO app.

V6 bevat:
- Photos by Loes stijl
- foto selecteren
- begin/resultaat naast elkaar
- lokale beeldverbetering
- geen externe camera-library
- geen oude V5-code
- geschikt als schone basis voor verdere AI-functies
