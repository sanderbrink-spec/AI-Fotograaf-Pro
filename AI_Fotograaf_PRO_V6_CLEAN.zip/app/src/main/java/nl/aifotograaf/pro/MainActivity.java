package nl.aifotograaf.pro;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int PICK_IMAGE = 1001;

    private ImageView beforeImage;
    private ImageView afterImage;
    private TextView status;
    private Button improveButton;
    private Bitmap originalBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createInterface();
    }

    private void createInterface() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);
        root.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("AI FOTOGRAAF PRO");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);

        TextView subtitle = new TextView(this);
        subtitle.setText("PHOTOS BY LOES");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, 20);

        Button selectButton = new Button(this);
        selectButton.setText("SELECTEER FOTO");

        improveButton = new Button(this);
        improveButton.setText("AI PERFECT");
        improveButton.setEnabled(false);

        status = new TextView(this);
        status.setText("Klaar");
        status.setTextColor(Color.WHITE);
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 18, 0, 18);

        LinearLayout comparison = new LinearLayout(this);
        comparison.setOrientation(LinearLayout.HORIZONTAL);

        beforeImage = new ImageView(this);
        afterImage = new ImageView(this);

        beforeImage.setBackgroundColor(Color.DKGRAY);
        afterImage.setBackgroundColor(Color.DKGRAY);
        beforeImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        afterImage.setScaleType(ImageView.ScaleType.CENTER_CROP);

        comparison.addView(beforeImage, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1));
        comparison.addView(afterImage, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1));

        root.addView(title);
        root.addView(subtitle);
        root.addView(selectButton);
        root.addView(improveButton);
        root.addView(status);
        root.addView(comparison, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(root);

        selectButton.setOnClickListener(v -> selectPhoto());

        improveButton.setOnClickListener(v -> {
            if (originalBitmap == null) return;

            status.setText("AI PERFECT • BEZIG...");
            improveButton.setEnabled(false);

            new Thread(() -> {
                Bitmap result = improvePhoto(originalBitmap);

                runOnUiThread(() -> {
                    afterImage.setImageBitmap(result);
                    status.setText("AI PERFECT • RESULTAAT KLAAR");
                    improveButton.setEnabled(true);
                });
            }).start();
        });
    }

    private void selectPhoto() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != PICK_IMAGE || resultCode != RESULT_OK ||
                data == null || data.getData() == null) {
            return;
        }

        try {
            Uri uri = data.getData();
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);

            originalBitmap = bitmap;
            beforeImage.setImageBitmap(bitmap);
            afterImage.setImageBitmap(bitmap);
            improveButton.setEnabled(true);
            status.setText("Foto geladen • klaar voor AI PERFECT");

        } catch (Exception e) {
            Toast.makeText(this, "Foto kon niet worden geladen", Toast.LENGTH_SHORT).show();
        }
    }

    private Bitmap improvePhoto(Bitmap source) {
        Bitmap result = Bitmap.createBitmap(
                source.getWidth(),
                source.getHeight(),
                Bitmap.Config.ARGB_8888
        );

        Canvas canvas = new Canvas(result);
        ColorMatrix matrix = new ColorMatrix();
        matrix.setSaturation(1.08f);

        ColorMatrix contrast = new ColorMatrix(new float[] {
                1.08f, 0, 0, 0, -8,
                0, 1.08f, 0, 0, -8,
                0, 0, 1.08f, 0, -8,
                0, 0, 0, 1, 0
        });

        matrix.postConcat(contrast);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setFilterBitmap(true);
        paint.setColorFilter(new ColorMatrixColorFilter(matrix));
        canvas.drawBitmap(source, 0, 0, paint);

        return result;
    }
}
