package nl.aifotograaf.pro;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int PICK = 10, CAMERA = 11;
    final int BG=Color.rgb(5,5,5), GOLD=Color.rgb(220,174,95), CREAM=Color.rgb(250,242,225), MUTED=Color.rgb(178,164,143), PANEL=Color.rgb(21,18,15);
    FrameLayout root; ImageView image; Bitmap original, edited; Uri cameraUri; boolean before=false;
    SeekBar exposure, contrast, saturation, sharpness; TextView status;

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(BG); showHome(); }
    TextView text(String s,int size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); return t; }
    Button button(String s, boolean gold){ Button b=new Button(this); b.setText(s); b.setTextSize(13); b.setTextColor(gold?BG:CREAM); b.setAllCaps(false); b.setBackgroundResource(gold?R.drawable.button_gold:R.drawable.button_dark); return b; }
    LinearLayout col(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(18,18,18,18); l.setBackgroundColor(BG); return l; }

    void showHome(){
        LinearLayout p=col();
        TextView title=text("PHOTOS BY LOES",27,GOLD); p.addView(title,new LinearLayout.LayoutParams(-1,70));
        TextView sub=text("AI FOTOGRAAF PRO  •  LOKAAL",13,MUTED); p.addView(sub,new LinearLayout.LayoutParams(-1,38));
        Button camera=button("CAMERA",true); p.addView(camera,new LinearLayout.LayoutParams(-1,62));
        Button gallery=button("FOTO'S UIT GALERIJ",false); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,62);gp.topMargin=12;p.addView(gallery,gp);
        Button batch=button("TOT 100 FOTO'S VERWERKEN",false); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,62);bp.topMargin=12;p.addView(batch,bp);
        status=text("Volledig lokaal • foto's verlaten het toestel niet",12,MUTED); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,50);sp.topMargin=24;p.addView(status,sp);
        TextView tools=text("BELICHTING • CONTRAST • KLEUR • DETAIL • SCHERPTE • VOOR/NA",12,CREAM); tools.setGravity(Gravity.CENTER); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,80);tp.topMargin=25;p.addView(tools,tp);
        setContentView(p);
        camera.setOnClickListener(v->takePhoto()); gallery.setOnClickListener(v->pick(false)); batch.setOnClickListener(v->pick(true));
    }

    void takePhoto(){
        ContentValues v=new ContentValues(); v.put(MediaStore.Images.Media.DISPLAY_NAME,"Loes_capture_"+System.currentTimeMillis()+".jpg"); v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg"); v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Photos by Loes");
        cameraUri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
        if(cameraUri==null){ toast("Camera kon niet worden voorbereid"); return; }
        Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE); i.putExtra(MediaStore.EXTRA_OUTPUT,cameraUri); i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivityForResult(i,CAMERA);
    }
    void pick(boolean multi){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,multi); startActivityForResult(i,PICK); }
    @Override protected void onActivityResult(int r,int c,Intent d){ super.onActivityResult(r,c,d); if(c!=RESULT_OK)return; try{ if(r==CAMERA){ original=read(cameraUri); showEditor(); } else if(r==PICK && d!=null){ ArrayList<Uri> list=new ArrayList<>(); if(d.getClipData()!=null){ for(int n=0;n<Math.min(100,d.getClipData().getItemCount());n++) list.add(d.getClipData().getItemAt(n).getUri()); } else if(d.getData()!=null) list.add(d.getData()); if(list.size()==1){original=read(list.get(0));showEditor();} else processBatch(list);} }catch(Exception e){toast("Foto kon niet worden geopend");} }
    Bitmap read(Uri u)throws Exception{ try(InputStream in=getContentResolver().openInputStream(u)){ Bitmap b=BitmapFactory.decodeStream(in); if(b==null)throw new IOException("bitmap"); return b.copy(Bitmap.Config.ARGB_8888,true); } }

    void showEditor(){
        LinearLayout page=col();
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        Button back=button("TERUG",false); head.addView(back,new LinearLayout.LayoutParams(85,52)); TextView t=text("AI FOTOGRAAF PRO",17,GOLD); head.addView(t,new LinearLayout.LayoutParams(0,52,1)); Button cmp=button("VOOR / NA",false); head.addView(cmp,new LinearLayout.LayoutParams(100,52)); page.addView(head);
        image=new ImageView(this); image.setScaleType(ImageView.ScaleType.FIT_CENTER); LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,0,1); ip.topMargin=8; page.addView(image,ip);
        Button ai=button("✦ AI PERFECT",true); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,55);ap.topMargin=8;page.addView(ai,ap);
        exposure=slider(page,"BELICHTING",-100,100,0); contrast=slider(page,"CONTRAST",-100,100,0); saturation=slider(page,"KLEUR",-100,100,0); sharpness=slider(page,"DETAIL",0,100,35);
        Button save=button("OPSLAAN",false); LinearLayout.LayoutParams sv=new LinearLayout.LayoutParams(-1,55);sv.topMargin=8;page.addView(save,sv);
        setContentView(page); edited=original.copy(Bitmap.Config.ARGB_8888,true); image.setImageBitmap(edited);
        back.setOnClickListener(v->showHome()); cmp.setOnClickListener(v->{before=!before;image.setImageBitmap(before?original:edited);cmp.setText(before?"NA TONEN":"VOOR / NA");}); ai.setOnClickListener(v->{exposure.setProgress(62);contrast.setProgress(65);saturation.setProgress(57);sharpness.setProgress(75);apply();}); save.setOnClickListener(v->saveEdited());
    }
    SeekBar slider(LinearLayout p,String name,int min,int max,int val){ TextView l=text(name,11,MUTED); p.addView(l,new LinearLayout.LayoutParams(-1,24)); SeekBar s=new SeekBar(this);s.setMax(max-min);s.setProgress(val-min);s.setTag(new Object[]{name,min,l});s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int x,boolean f){l.setText(name+"  "+(x+min));if(f)apply();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});p.addView(s,new LinearLayout.LayoutParams(-1,36)); return s; }
    void apply(){ if(original==null||exposure==null)return; int e=exposure.getProgress()-100,c=contrast.getProgress()-100,s=saturation.getProgress()-100,sh=sharpness.getProgress(); edited=enhance(scale(original,1800),e/100f,c/100f,s/100f,sh/100f); if(!before)image.setImageBitmap(edited); }
    Bitmap scale(Bitmap b,int max){float f=Math.min(1f,max/(float)Math.max(b.getWidth(),b.getHeight()));return f>=.999f?b.copy(Bitmap.Config.ARGB_8888,true):Bitmap.createScaledBitmap(b,Math.max(1,(int)(b.getWidth()*f)),Math.max(1,(int)(b.getHeight()*f)),true).copy(Bitmap.Config.ARGB_8888,true);}
    Bitmap enhance(Bitmap src,float e,float c,float s,float sh){Bitmap b=src.copy(Bitmap.Config.ARGB_8888,true);int w=b.getWidth(),h=b.getHeight();int[] p=new int[w*h];b.getPixels(p,0,w,0,0,w,h);float gain=1f+e*.45f, cg=1f+c*.30f, sat=1f+s*.25f;for(int i=0;i<p.length;i++){int q=p[i];float r=Color.red(q)*gain,g=Color.green(q)*gain,bl=Color.blue(q)*gain,gr=(r+g+bl)/3f;r=gr+(r-gr)*sat;g=gr+(g-gr)*sat;bl=gr+(bl-gr)*sat;r=(r-128)*cg+128;g=(g-128)*cg+128;bl=(bl-128)*cg+128;p[i]=Color.rgb(clamp((int)r),clamp((int)g),clamp((int)bl));}b.setPixels(p,0,w,0,0,w,h);if(sh>.05f)sharpen(b,.04f+.20f*sh);return b;}
    void sharpen(Bitmap b,float k){int w=b.getWidth(),h=b.getHeight();int[] p=new int[w*h];b.getPixels(p,0,w,0,0,w,h);int[] o=p.clone();for(int y=1;y<h-1;y++)for(int x=1;x<w-1;x++){int i=y*w+x,lum=(Color.red(p[i])*30+Color.green(p[i])*59+Color.blue(p[i])*11)/100;int avg=((Color.red(p[i-1])*30+Color.green(p[i-1])*59+Color.blue(p[i-1])*11)+(Color.red(p[i+1])*30+Color.green(p[i+1])*59+Color.blue(p[i+1])*11)+(Color.red(p[i-w])*30+Color.green(p[i-w])*59+Color.blue(p[i-w])*11)+(Color.red(p[i+w])*30+Color.green(p[i+w])*59+Color.blue(p[i+w])*11))/400;int d=lum-avg;o[i]=Color.rgb(clamp((int)(Color.red(p[i])+d*k)),clamp((int)(Color.green(p[i])+d*k)),clamp((int)(Color.blue(p[i])+d*k)));}b.setPixels(o,0,w,0,0,w,h);}
    int clamp(int v){return Math.max(0,Math.min(255,v));}
    void saveEdited(){if(edited==null)return;try{save(edited);toast("Opgeslagen in Foto's");}catch(Exception e){toast("Opslaan mislukt");}}
    void save(Bitmap b)throws Exception{String n="Photos_by_Loes_AI_"+System.currentTimeMillis()+".jpg";ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,n);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Photos by Loes");Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(u==null)throw new IOException();try(OutputStream o=getContentResolver().openOutputStream(u)){b.compress(Bitmap.CompressFormat.JPEG,97,o);}}
    void processBatch(ArrayList<Uri> list){ final int total=list.size(); LinearLayout p=col();TextView t=text("AI PERFECT",26,GOLD);p.addView(t,new LinearLayout.LayoutParams(-1,70));ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(total);p.addView(bar,new LinearLayout.LayoutParams(-1,25));TextView s=text("0 / "+total+" foto's",15,CREAM);p.addView(s,new LinearLayout.LayoutParams(-1,60));setContentView(p);new Thread(()->{int n=0;for(Uri u:list){try{Bitmap b=scale(read(u),2200);Bitmap out=enhance(b,.12f,.18f,.10f,.65f);save(out);b.recycle();out.recycle();}catch(Exception ignored){}n++;int z=n;runOnUiThread(()->{bar.setProgress(z);s.setText(z+" / "+total+" foto's verwerkt");});} }).start();}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
