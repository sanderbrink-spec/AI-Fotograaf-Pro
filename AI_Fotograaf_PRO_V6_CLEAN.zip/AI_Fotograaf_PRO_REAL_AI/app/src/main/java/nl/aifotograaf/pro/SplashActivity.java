package nl.aifotograaf.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class SplashActivity extends Activity {
    private static final int BG = Color.rgb(7, 9, 12);
    private static final int GOLD = Color.rgb(232, 198, 125);
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(30), dp(30), dp(30), dp(30));
        root.setBackgroundColor(BG);

        TextView brand = text("PHOTOS BY LOES", 13, GOLD, true);
        brand.setLetterSpacing(.16f);
        root.addView(brand, new LinearLayout.LayoutParams(-2, dp(34)));

        TextView line = text("✦", 30, GOLD, true);
        line.setGravity(Gravity.CENTER);
        root.addView(line, new LinearLayout.LayoutParams(-1, dp(54)));

        TextView title = text("AI FOTOGRAAF PRO", 30, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(50)));

        TextView sub = text("PROFESSIONELE FOTOVERBETERING", 12, Color.rgb(166,171,181), true);
        sub.setGravity(Gravity.CENTER);
        sub.setLetterSpacing(.08f);
        root.addView(sub, new LinearLayout.LayoutParams(-1, dp(36)));

        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(210), dp(5));
        bp.topMargin = dp(34);
        root.addView(bar, bp);

        TextView privacy = text("LOKAAL • PRIVACY • GEEN CLOUD", 10, Color.rgb(125,131,142), true);
        privacy.setGravity(Gravity.CENTER);
        privacy.setLetterSpacing(.10f);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(30));
        pp.topMargin = dp(12);
        root.addView(privacy, pp);
        setContentView(root);

        AlphaAnimation fade = new AlphaAnimation(.2f, 1f);
        fade.setDuration(900);
        fade.setRepeatMode(AlphaAnimation.REVERSE);
        fade.setRepeatCount(1);
        root.startAnimation(fade);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }, 2300);
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return t;
    }
}
