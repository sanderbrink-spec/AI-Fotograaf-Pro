package nl.aifotograaf.pro;

import android.animation.ObjectAnimator;
import android.app.*;
import android.animation.ObjectAnimator;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int PICK=101;
    ArrayList<Bitmap> originals=new ArrayList<>(), results=new ArrayList<>();
    ImageView beforeView, afterView;
    LinearLayout root, content;
    final int BG=Color.rgb(7,7,7), PANEL=Color.rgb(20,21,24), GOLD=Color.rgb(231,189,114), GOLD2=Color.rgb(247,217,154);
    int selected=0;
    static final int PICK = 1001;
    ImageView beforeView, afterView;
    Bitmap original, enhanced;
    TextView status, exposureValue, contrastValue, colorValue, sharpValue;
    SeekBar exposure, contrast, color, sharpness;
    LinearLayout root;
    final int GOLD = Color.rgb(231,189,114);
    final int GOLD2 = Color.rgb(247,217,154);
    final int BG = Color.rgb(7,7,7);
    final int PANEL = Color.rgb(20,21,24);

    int dp(float v){ return (int)(v * getResources().getDisplayMetrics().density + .5f); }


    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable box(int c,float r,int stroke){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));if(stroke!=0)g.setStroke(dp(1),stroke);return g;}
    TextView tv(String s,float z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);return t;}
    Button btn(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setAllCaps(false);b.setTextColor(primary?Color.rgb(25,19,10):Color.WHITE);b.setBackground(box(primary?GOLD:Color.rgb(27,28,32),16,primary?GOLD2:Color.rgb(50,51,55)));return b;}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);showIntro();}
    void showIntro(){
        FrameLayout f=new FrameLayout(this);f.setBackgroundColor(BG);setContentView(f);
        ImageView hero=new ImageView(this);hero.setImageResource(R.drawable.loes_splash);hero.setScaleType(ImageView.ScaleType.CENTER_CROP);hero.setAlpha(0f);f.addView(hero,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout o=new LinearLayout(this);o.setOrientation(LinearLayout.VERTICAL);o.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.BOTTOM);o.setPadding(dp(20),0,dp(20),dp(35));o.setAlpha(0f);
        TextView a=tv("AI FOTOGRAAF PRO",26,Color.WHITE);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);a.setGravity(Gravity.CENTER);o.addView(a,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView b=tv("AI by Loes",30,GOLD2);b.setTypeface(Typeface.create("cursive",0));b.setGravity(Gravity.CENTER);o.addView(b,new LinearLayout.LayoutParams(-1,dp(45)));
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);o.addView(bar,new LinearLayout.LayoutParams(dp(240),dp(8)));f.addView(o,new FrameLayout.LayoutParams(-1,-1));
        hero.animate().alpha(1).setDuration(700).start();o.animate().alpha(1).setDuration(900).start();new Handler().postDelayed(()->{bar.setProgress(100);new Handler().postDelayed(this::showHome,600);},450);
    }
    void base(String title){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(8),dp(12),dp(12));root.setBackgroundColor(BG);setContentView(root);LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);TextView l=tv("Loes",34,GOLD2);l.setTypeface(Typeface.create("cursive",0));h.addView(l,new LinearLayout.LayoutParams(0,dp(50),1));TextView t=tv(title,17,Color.WHITE);t.setGravity(Gravity.CENTER);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.addView(t,new LinearLayout.LayoutParams(0,dp(50),2));h.addView(tv("⋮",28,Color.WHITE),new LinearLayout.LayoutParams(0,dp(50),1));root.addView(h);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));}
    void showHome(){base("AI FOTOGRAAF PRO");LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER_HORIZONTAL);card.setPadding(dp(12),dp(14),dp(12),dp(14));card.setBackground(box(PANEL,22,Color.rgb(43,44,48)));TextView logo=tv("◉  ✦",48,GOLD);logo.setGravity(Gravity.CENTER);card.addView(logo,new LinearLayout.LayoutParams(-1,dp(65)));TextView sub=tv("MOOIERE FOTO'S. AUTOMATISCH.",11,Color.rgb(205,190,164));sub.setGravity(Gravity.CENTER);sub.setLetterSpacing(.12f);card.addView(sub,new LinearLayout.LayoutParams(-1,dp(32)));Button sel=btn("▣  SELECTEER FOTO'S",true);card.addView(sel,new LinearLayout.LayoutParams(-1,dp(58)));TextView h=tv("Kies één of meerdere foto’s",11,Color.LTGRAY);h.setGravity(Gravity.CENTER);card.addView(h,new LinearLayout.LayoutParams(-1,dp(27)));Button ai=btn("✦  AI PERFECT",false);card.addView(ai,new LinearLayout.LayoutParams(-1,dp(56)));TextView hh=tv("VERWERK ALLES AUTOMATISCH",10,Color.rgb(190,176,151));hh.setGravity(Gravity.CENTER);card.addView(hh,new LinearLayout.LayoutParams(-1,dp(27)));content.addView(card);LinearLayout modes=new LinearLayout(this);String[] ms={"◉\nPortret","⌁\nLandschap","☾\nNacht","♨\nEten"};for(String x:ms){TextView q=tv(x,12,Color.LTGRAY);q.setGravity(Gravity.CENTER);q.setBackground(box(Color.rgb(25,26,29),15,Color.rgb(45,46,50)));modes.addView(q,new LinearLayout.LayoutParams(0,dp(65),1));}content.addView(modes);LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(dp(15),dp(12),dp(15),dp(12));info.setBackground(box(PANEL,18,Color.rgb(43,44,48)));TextView it=tv("Wat AI Fotograaf Pro doet",16,Color.WHITE);it.setTypeface(Typeface.DEFAULT,Typeface.BOLD);info.addView(it);String[] ck={"✓ Automatische belichting, highlights en schaduwen","✓ Witbalans en natuurlijke kleurcorrectie","✓ Contrast, detail en verscherping","✓ Ruisonderdrukking","✓ Lokale gezichtsoptimalisatie","✓ Batchverwerking tot 100 foto’s"};for(String x:ck)info.addView(tv(x,11,Color.LTGRAY));content.addView(info);LinearLayout nav=new LinearLayout(this);Button set=btn("⚙ Instellingen",false),res=btn("▣ Resultaten",false);nav.addView(set,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(52),1);rp.leftMargin=dp(6);nav.addView(res,rp);root.addView(nav);sel.setOnClickListener(v->pick());ai.setOnClickListener(v->pick());res.setOnClickListener(v->showResults());set.setOnClickListener(v->showSettings());}
    void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r!=PICK||c!=RESULT_OK||d==null)return;try{originals.clear();results.clear();ClipData cd=d.getClipData();if(cd!=null){for(int i=0;i<Math.min(100,cd.getItemCount());i++)add(cd.getItemAt(i).getUri());}else if(d.getData()!=null)add(d.getData());if(!originals.isEmpty())showEditor();}catch(Exception e){Toast.makeText(this,"Foto's konden niet worden geladen.",Toast.LENGTH_SHORT).show();}}
    void add(Uri u)throws Exception{InputStream in=getContentResolver().openInputStream(u);Bitmap b=BitmapFactory.decodeStream(in);in.close();if(b==null)return;float sc=Math.min(1f,1800f/Math.max(b.getWidth(),b.getHeight()));originals.add(sc<1?Bitmap.createScaledBitmap(b,(int)(b.getWidth()*sc),(int)(b.getHeight()*sc),true):b);}
    LinearLayout pane(String lab,ImageView im,boolean gold){LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setBackground(box(Color.rgb(5,5,6),15,Color.rgb(42,43,47)));TextView t=tv(lab,10,gold?Color.rgb(20,15,8):Color.WHITE);t.setGravity(Gravity.CENTER);t.setBackground(box(gold?GOLD:Color.rgb(20,20,22),18,0));LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(dp(70),dp(26));tp.setMargins(dp(8),dp(8),0,dp(3));p.addView(t,tp);p.addView(im,new LinearLayout.LayoutParams(-1,0,1));return p;}
    void showEditor(){base("Verbeteren");LinearLayout cmp=new LinearLayout(this);beforeView=new ImageView(this);afterView=new ImageView(this);beforeView.setScaleType(ImageView.ScaleType.FIT_CENTER);afterView.setScaleType(ImageView.ScaleType.FIT_CENTER);cmp.addView(pane("VOOR",beforeView,false),new LinearLayout.LayoutParams(0,dp(270),1));LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(270),1);q.leftMargin=dp(7);cmp.addView(pane("NA",afterView,true),q);content.addView(cmp);beforeView.setImageBitmap(originals.get(0));afterView.setImageBitmap(originals.get(0));Button perfect=btn("✦ AI PERFECT",true);content.addView(perfect,new LinearLayout.LayoutParams(-1,dp(54)));TextView tools=tv("Belichting   ━━━━━━━   Contrast   ━━━━━━━   Kleuren   ━━━━━━━   Scherpte   ━━━━━━━",11,Color.LTGRAY);tools.setPadding(0,dp(10),0,dp(10));content.addView(tools);Button save=btn("⇩ Opslaan",false),share=btn("↗ Delen",false);LinearLayout row=new LinearLayout(this);row.addView(save,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(52),1);sp.leftMargin=dp(6);row.addView(share,sp);content.addView(row);perfect.setOnClickListener(v->processAll());save.setOnClickListener(v->saveCurrent());share.setOnClickListener(v->shareCurrent());}
    void showProcessing(){base("Bezig met verwerken…");ImageView im=new ImageView(this);im.setImageResource(R.drawable.loes_splash);im.setScaleType(ImageView.ScaleType.CENTER_CROP);content.addView(im,new LinearLayout.LayoutParams(-1,dp(280)));status=tv("Foto's analyseren…",14,Color.LTGRAY);status.setGravity(Gravity.CENTER);content.addView(status,new LinearLayout.LayoutParams(-1,dp(55)));content.addView(tv("✓ Foto’s analyseren\n◌ Gezichten detecteren\n◌ AI verbetering toepassen\n◌ Details optimaliseren\n◌ Resultaten opslaan",14,Color.LTGRAY));}
    void processAll(){showProcessing();new AsyncTask<Void,Integer,Void>(){protected Void doInBackground(Void...v){results.clear();for(int i=0;i<originals.size();i++){results.add(enhance(originals.get(i)));publishProgress(i+1);}return null;}protected void onProgressUpdate(Integer...p){status.setText("Foto "+p[0]+" van "+originals.size()+" verwerken…");}protected void onPostExecute(Void v){showResults();}}.execute();}
    Bitmap enhance(Bitmap src){int w=src.getWidth(),h=src.getHeight();Bitmap o=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);int[] a=new int[w*h];src.getPixels(a,0,w,0,0,w,h);for(int i=0;i<a.length;i++){int c=a[i];float r=Color.red(c)*1.06f,g=Color.green(c)*1.06f,b=Color.blue(c)*1.06f;r=(r-128)*1.10f+128;g=(g-128)*1.10f+128;b=(b-128)*1.10f+128;float gr=.299f*r+.587f*g+.114f*b;r=gr+(r-gr)*1.06f;g=gr+(g-gr)*1.06f;b=gr+(b-gr)*1.06f;a[i]=Color.rgb(cl(r),cl(g),cl(b));}o.setPixels(a,0,w,0,0,w,h);return o;}
    int cl(float x){return (int)Math.max(0,Math.min(255,x));}
    void showResults(){base("Resultaten");if(results.isEmpty())results.addAll(originals);LinearLayout cmp=new LinearLayout(this);ImageView b=new ImageView(this),a=new ImageView(this);b.setScaleType(ImageView.ScaleType.FIT_CENTER);a.setScaleType(ImageView.ScaleType.FIT_CENTER);b.setImageBitmap(originals.get(0));a.setImageBitmap(results.get(0));cmp.addView(pane("VOOR",b,false),new LinearLayout.LayoutParams(0,dp(280),1));LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(280),1);q.leftMargin=dp(7);cmp.addView(pane("NA",a,true),q);content.addView(cmp);content.addView(tv(originals.size()+" foto('s) • AI PERFECT",12,Color.LTGRAY));Button edit=btn("✦ AI PERFECT",true),save=btn("⇩ Opslaan",false),share=btn("↗ Delen",false);content.addView(edit);LinearLayout row=new LinearLayout(this);row.addView(save,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams z=new LinearLayout.LayoutParams(0,dp(52),1);z.leftMargin=dp(6);row.addView(share,z);content.addView(row);edit.setOnClickListener(v->showEditor());save.setOnClickListener(v->saveCurrent());share.setOnClickListener(v->shareCurrent());}
    void saveCurrent(){if(results.isEmpty())return;try{ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,"AI_Fotograaf_PRO_"+System.currentTimeMillis()+".jpg");v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");if(Build.VERSION.SDK_INT>=29)v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/AI Fotograaf PRO");Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);OutputStream o=getContentResolver().openOutputStream(u);results.get(0).compress(Bitmap.CompressFormat.JPEG,96,o);o.close();Toast.makeText(this,"Foto opgeslagen.",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Opslaan mislukt.",Toast.LENGTH_SHORT).show();}}
    void shareCurrent(){Toast.makeText(this,"Gebruik Opslaan om de verbeterde foto te delen vanuit Foto's.",Toast.LENGTH_LONG).show();}
    void showSettings(){base("Instellingen");String[] xs={"Automatische verbetering","Gezichtsoptimalisatie","Natuurlijke huidtinten","Ruisonderdrukking","Resultaten bewaren in Foto's"};for(String x:xs){Switch sw=new Switch(this);sw.setText(x);sw.setTextColor(Color.WHITE);sw.setChecked(true);sw.setPadding(dp(10),0,dp(10),0);sw.setBackground(box(PANEL,14,Color.rgb(43,44,48)));content.addView(sw,new LinearLayout.LayoutParams(-1,dp(58)));}}
    void showResultsPlaceholder(){showResults();}

}
