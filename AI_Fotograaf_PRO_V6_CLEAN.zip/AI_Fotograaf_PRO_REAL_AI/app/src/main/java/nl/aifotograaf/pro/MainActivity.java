package nl.aifotograaf.pro;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.exifinterface.media.ExifInterface;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.google.android.gms.tasks.Tasks;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Quality-first local photo enhancer.
 * No destructive 4x upscaling. ML Kit is used for local scene/face analysis;
 * the enhancement itself is conservative and detail-preserving.
 */
public class MainActivity extends AppCompatActivity {
    private static final int BG=Color.rgb(8,10,13), CARD=Color.rgb(18,21,27), CARD2=Color.rgb(24,28,35);
    private static final int TEXT=Color.WHITE, MUTED=Color.rgb(157,164,175), ACCENT=Color.rgb(232,198,125), GREEN=Color.rgb(82,201,139);
    private static final int MAX_WORKING=1400;

    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final ArrayList<android.net.Uri> selected=new ArrayList<>();
    private final ArrayList<File> resultFiles=new ArrayList<>();
    private Bitmap previewOriginalBitmap, previewResultBitmap;
    private ActivityResultLauncher<Intent> picker;
    private TextView counter,status,resultTitle,modelBadge;
    private ProgressBar progress;
    private Button selectButton,aiButton,saveButton;
    private ImageView beforeView,afterView;
    private LinearLayout resultsList;
    private String mode="AUTOMATISCH";
    private FaceDetector faceDetector;
    private boolean processing=false;

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        picker=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r->{
            if(r.getResultCode()!=RESULT_OK || r.getData()==null) return;
            Intent d=r.getData(); selected.clear();
            if(d.getClipData()!=null){int n=Math.min(100,d.getClipData().getItemCount()); for(int i=0;i<n;i++) selected.add(d.getClipData().getItemAt(i).getUri());}
            else if(d.getData()!=null) selected.add(d.getData());
            counter.setText(selected.size()==1?"1 foto geselecteerd":selected.size()+" foto's geselecteerd");
            aiButton.setEnabled(!selected.isEmpty()&&!processing);
            status.setText("Klaar voor AI PERFECT");
            if(!selected.isEmpty()) showPreview(selected.get(0));
        });
        buildUi(); initFaceDetector();
        modelBadge.setText("●  LOKALE AI • KWALITEITSMODUS KLAAR");
        status.setText("Kies foto's voor AI PERFECT");
    }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(16),dp(18),dp(28)); scroll.addView(root,new ScrollView.LayoutParams(-1,-1));
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=tv("AI FOTOGRAAF PRO",27,TEXT,true); title.setSingleLine(true); header.addView(title,weightLp(0,dp(48),1));
        TextView pro=tv("PRO",11,BG,true); pro.setGravity(Gravity.CENTER); pro.setBackground(round(ACCENT,18)); header.addView(pro,new LinearLayout.LayoutParams(dp(52),dp(34))); root.addView(header,lpMargin(-1,dp(48),0,0,0,6));
        TextView by=tv("PHOTOS BY LOES  •  STUDIO EDITION",12,ACCENT,true);
        by.setLetterSpacing(.06f);
        root.addView(by,lpMargin(-1,dp(24),0,0,0,8));
        LinearLayout hero=card(); hero.addView(tv("Maak van elke foto een PRO-foto",18,TEXT,true),wrap(-1)); hero.addView(tv("Professionele lokale beeldverbetering • natuurlijk resultaat • privacy eerst",13,MUTED,false),wrap(-1));
        modelBadge=tv("●  LOKALE AI WORDT GESTART...",11,MUTED,true); modelBadge.setPadding(0,dp(8),0,0); hero.addView(modelBadge,wrap(-1)); root.addView(hero,lpMargin(-1,-2,0,0,0,12));
        counter=tv("Nog geen foto's geselecteerd",13,MUTED,false); root.addView(counter,lpMargin(-1,dp(28),0,0,0,8));
        selectButton=bigButton("＋  FOTO'S KIEZEN  •  MAX. 100",CARD2,TEXT); root.addView(selectButton,lpMargin(-1,dp(54),0,0,0,14)); selectButton.setOnClickListener(v->openPicker());
        root.addView(tv("BEWERKPROFIEL",11,MUTED,true),lpMargin(-1,dp(22),0,0,0,7));
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); LinearLayout modes=new LinearLayout(this); modes.setOrientation(LinearLayout.HORIZONTAL);
        for(String m:new String[]{"AUTOMATISCH","PORTRET","LANDSCHAP","LOW LIGHT"}){Button b=smallButton(m,m.equals(mode)); LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(dp(126),dp(48)); mp.setMargins(0,0,dp(8),0); modes.addView(b,mp); b.setOnClickListener(v->{mode=((Button)v).getText().toString();refreshModes(modes);});}
        hs.addView(modes,new HorizontalScrollView.LayoutParams(-2,dp(48))); root.addView(hs,lpMargin(-1,dp(48),0,0,0,14));
        LinearLayout preview=card(); preview.addView(tv("VOOR / NA",11,MUTED,true),wrap(-1));
        LinearLayout cmp=new LinearLayout(this); cmp.setOrientation(LinearLayout.HORIZONTAL); cmp.setPadding(0,dp(8),0,0); LinearLayout bp=previewPane("ORIGINEEL",true),ap=previewPane("AI PERFECT",false);
        cmp.addView(bp,weightLp(0,dp(194),1)); cmp.addView(new View(this),new LinearLayout.LayoutParams(dp(8),1)); cmp.addView(ap,weightLp(0,dp(194),1)); preview.addView(cmp,wrap(-1)); root.addView(preview,lpMargin(-1,-2,0,0,0,12));
        aiButton=bigButton("✦  AI PERFECT  •  VERBETER FOTO'S",ACCENT,BG); aiButton.setEnabled(false); root.addView(aiButton,lpMargin(-1,dp(58),0,0,0,8)); aiButton.setOnClickListener(v->processAll());
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setMax(100); progress.setProgress(0); root.addView(progress,lpMargin(-1,dp(8),0,0,0,4));
        status=tv("Kies foto's voor AI PERFECT",12,MUTED,false); root.addView(status,lpMargin(-1,dp(30),0,0,0,12));
        LinearLayout tools=card(); tools.addView(tv("PRO-FUNCTIES",11,MUTED,true),wrap(-1));
        for(String f:new String[]{"AI-scèneanalyse op het toestel","Gezichtsdetectie en face-safe processing","Slimme belichting en schaduwherstel","Kleur & witbalans zonder kleurzweem","Natuurlijke ruis- en detailbalans","Originele resolutie blijft behouden"}){TextView row=tv("✓  "+f,13,TEXT,false); row.setPadding(0,dp(3),0,dp(3)); tools.addView(row,wrap(-1));} root.addView(tools,lpMargin(-1,-2,0,0,0,12));
        LinearLayout result=card(); resultTitle=tv("RESULTATEN",11,MUTED,true); result.addView(resultTitle,wrap(-1)); resultsList=new LinearLayout(this); resultsList.setOrientation(LinearLayout.VERTICAL); result.addView(resultsList,wrap(-1));
        saveButton=bigButton("OPSLAAN / OPENEN IN FOTO'S",CARD2,TEXT); saveButton.setEnabled(false); result.addView(saveButton,lpMargin(-1,dp(50),0,0,0,0)); saveButton.setOnClickListener(v->openGalleryFolder()); root.addView(result,lpMargin(-1,-2,0,0,0,12));
        TextView privacy=tv("PHOTOS BY LOES  •  AI FOTOGRAAF PRO  •  PRIVACY FIRST",10,MUTED,true); privacy.setLineSpacing(0,1.05f); root.addView(privacy,wrap(-1)); setContentView(scroll);
    }

    private void refreshModes(LinearLayout m){for(int i=0;i<m.getChildCount();i++){Button b=(Button)m.getChildAt(i);boolean a=b.getText().toString().equals(mode);b.setBackground(round(a?ACCENT:CARD2,22));b.setTextColor(a?BG:TEXT);}}
    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(14),dp(13),dp(14),dp(13));l.setBackground(round(CARD,18));return l;}
    private LinearLayout previewPane(String label,boolean before){LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);TextView t=tv(label,10,MUTED,true);t.setPadding(dp(2),0,0,dp(5));p.addView(t,wrap(-1));ImageView im=imageBox(label);if(before)beforeView=im;else afterView=im;p.addView(im,new LinearLayout.LayoutParams(-1,dp(164)));return p;}
    private ImageView imageBox(String label){ImageView v=new ImageView(this);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(round(CARD2,14));v.setContentDescription(label);return v;}
    private Button bigButton(String s,int bg,int fg){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);b.setTextColor(fg);b.setAllCaps(false);b.setGravity(Gravity.CENTER);b.setBackground(round(bg,16));b.setPadding(dp(10),0,dp(10),0);b.setMinHeight(0);b.setMinWidth(0);return b;}
    private Button smallButton(String s,boolean a){Button b=bigButton(s,a?ACCENT:CARD2,a?BG:TEXT);b.setTextSize(12);return b;}
    private TextView tv(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setTypeface(android.graphics.Typeface.DEFAULT,bold?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL);return t;}
    private LinearLayout.LayoutParams wrap(int w){return new LinearLayout.LayoutParams(w,-2);}
    private LinearLayout.LayoutParams lpMargin(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(l,t,r,b);return p;}
    private LinearLayout.LayoutParams weightLp(int w,int h,float wt){return new LinearLayout.LayoutParams(w,h,wt);}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private android.graphics.drawable.GradientDrawable round(int c,int r){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}

    private void openPicker(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);picker.launch(i);}
    private void showPreview(android.net.Uri uri){executor.execute(()->{try{Bitmap b=decodeScaled(uri,MAX_WORKING);ui(()->{beforeView.setImageBitmap(b);afterView.setImageDrawable(null);});}catch(Exception e){ui(()->status.setText("Foto kon niet worden gelezen"));}});}
    private void initFaceDetector(){FaceDetectorOptions opts=new FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE).setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE).build();faceDetector=FaceDetection.getClient(opts);}

    private void processAll(){if(processing||selected.isEmpty())return;processing=true;aiButton.setEnabled(false);selectButton.setEnabled(false);saveButton.setEnabled(false);resultFiles.clear();resultsList.removeAllViews();progress.setProgress(0);resultTitle.setText("RESULTATEN • BEZIG");
        executor.execute(()->{int total=selected.size(); for(int n=0;n<total;n++){final int index=n+1;try{ui(()->status.setText(String.format(Locale.getDefault(),"AI PERFECT • foto %d / %d • analyseren...",index,total)));Bitmap src=decodeScaled(selected.get(n),MAX_WORKING);List<Rect> faces=detectFaces(src);ui(()->status.setText(String.format(Locale.getDefault(),"AI PERFECT • foto %d / %d • verbeteren...",index,total)));Bitmap out=enhancePhoto(src,faces);
                    File cached=cacheResult(out,index);
                    resultFiles.add(cached);
                    if(n==0){
                        Bitmap pvSrc=src.copy(Bitmap.Config.ARGB_8888,false);
                        Bitmap pvOut=out.copy(Bitmap.Config.ARGB_8888,false);
                        ui(()->lastPreview(pvSrc,pvOut));
                    }
                    if(out!=src && !out.isRecycled()) out.recycle();
                    if(src!=null && !src.isRecycled()) src.recycle();
                    final int done=n+1;ui(()->{progress.setProgress(done*100/total);addResultRow(done,faces.size());});}catch(Exception e){final String msg=e.getMessage()==null?"onbekende fout":e.getMessage();ui(()->status.setText("Foto "+index+": "+msg));}}
            ui(()->{processing=false;aiButton.setEnabled(!selected.isEmpty());selectButton.setEnabled(true);saveButton.setEnabled(!resultFiles.isEmpty());resultTitle.setText("RESULTATEN • "+resultFiles.size()+" KLAAR");status.setText(resultFiles.isEmpty()?"Geen resultaat":"AI PERFECT klaar • professionele lokale bewerking voltooid");});
        });
    }
    private void lastPreview(Bitmap src,Bitmap out){
        if(previewOriginalBitmap!=null && !previewOriginalBitmap.isRecycled()) previewOriginalBitmap.recycle();
        if(previewResultBitmap!=null && !previewResultBitmap.isRecycled()) previewResultBitmap.recycle();
        previewOriginalBitmap=src; previewResultBitmap=out;
        beforeView.setImageBitmap(src); afterView.setImageBitmap(out);
    }
    private void addResultRow(int n,int faces){TextView r=tv("✓  Foto "+n+"  •  AI PERFECT  •  "+faces+" gezicht(en) beschermd",12,GREEN,false);resultsList.addView(r,wrap(-1));}

    private List<Rect> detectFaces(Bitmap b)throws Exception{if(faceDetector==null)return Collections.emptyList();List<Face> faces=Tasks.await(faceDetector.process(InputImage.fromBitmap(b,0)));ArrayList<Rect> r=new ArrayList<>();for(Face f:faces)r.add(new Rect(f.getBoundingBox()));return r;}
    private boolean inFace(int x,int y,List<Rect> faces){for(Rect r:faces){int pad=Math.max(12,(int)(Math.max(r.width(),r.height())*.12));if(x>=r.left-pad&&x<=r.right+pad&&y>=r.top-pad&&y<=r.bottom+pad)return true;}return false;}

    private Bitmap enhancePhoto(Bitmap src,List<Rect>faces){
        int w=src.getWidth(),h=src.getHeight();int[] p=new int[w*h],q=new int[w*h];src.getPixels(p,0,w,0,0,w,h);System.arraycopy(p,0,q,0,p.length);
        int[] hist=new int[256];long count=0;double mean=0;
        for(int y=0;y<h;y+=10)for(int x=0;x<w;x+=10){int c=p[y*w+x];int l=Math.max(0,Math.min(255,Math.round(luma(c))));hist[l]++;mean+=l;count++;}
        mean/=Math.max(1,count);int p05=percentile(hist,count,.05),p95=percentile(hist,count,.95);
        float exposure=1f;if(mean<92)exposure=1.045f;else if(mean<108)exposure=1.025f;else if(mean>168)exposure=.975f;else if(mean>184)exposure=.955f;
        float range=Math.max(80,p95-p05);float contrast=mode.equals("LANDSCHAP")?1.025f:mode.equals("PORTRET")?1.012f:mode.equals("LOW LIGHT")?1.018f:1.018f;
        float sat=mode.equals("LANDSCHAP")?1.035f:mode.equals("PORTRET")?1.005f:1.012f;
        float shadow=mode.equals("LOW LIGHT")?7f:4f;float hi=mode.equals("LOW LIGHT")?8f:6f;
        for(int y=1;y<h-1;y++){
            for(int x=1;x<w-1;x++){
                int i=y*w+x,c=p[i];float r=Color.red(c),g=Color.green(c),b=Color.blue(c),lum=luma(c);
                float t=(lum-p05)/range;t=clampf(t,0,1);float mapped=(t-.5f)*contrast+.5f;float target=mapped*range+p05;target*=exposure;
                if(lum<78)target+=Math.min(shadow,(78-lum)*.12f);if(lum>210)target-=Math.min(hi,(lum-210)*.10f);target=clampf(target,0,255);
                float gain=lum>4?target/lum:1f;r*=gain;g*=gain;b*=gain;float gray=r*.299f+g*.587f+b*.114f;r=gray+(r-gray)*sat;g=gray+(g-gray)*sat;b=gray+(b-gray)*sat;
                float local=(luma(p[i-1])+luma(p[i+1])+luma(p[i-w])+luma(p[i+w]))*.25f;float edge=lum-local;boolean face=inFace(x,y,faces);
                float sharp=face?.018f:(mode.equals("LANDSCHAP")?.055f:mode.equals("LOW LIGHT")?.035f:.040f);float detail=clampf(edge*sharp,-6f,6f);r+=detail;g+=detail;b+=detail;
                q[i]=Color.rgb(clamp(r),clamp(g),clamp(b));
            }
        }
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);out.setPixels(q,0,w,0,0,w,h);return out;
    }
    private int percentile(int[] hist,long total,double f){long target=Math.max(1,Math.round(total*f)),s=0;for(int i=0;i<hist.length;i++){s+=hist[i];if(s>=target)return i;}return 255;}
    private float luma(int c){return Color.red(c)*.299f+Color.green(c)*.587f+Color.blue(c)*.114f;}
    private float clampf(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}private int clamp(float v){return Math.max(0,Math.min(255,Math.round(v)));}

    private Bitmap decodeScaled(android.net.Uri uri,int max)throws Exception{BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,o);}int w=o.outWidth,h=o.outHeight;if(w<=0||h<=0)throw new Exception("Ongeldige foto");float sc=Math.min(1f,max/(float)Math.max(w,h));int nw=Math.max(1,Math.round(w*sc)),nh=Math.max(1,Math.round(h*sc));BitmapFactory.Options p=new BitmapFactory.Options();p.inPreferredConfig=Bitmap.Config.ARGB_8888;Bitmap b;try(InputStream in=getContentResolver().openInputStream(uri)){b=BitmapFactory.decodeStream(in,null,p);}if(b==null)throw new Exception("Afbeelding kon niet worden gelezen");Bitmap scaled=Bitmap.createScaledBitmap(b,nw,nh,true);if(scaled!=b)b.recycle();try(InputStream exifIn=getContentResolver().openInputStream(uri)){ExifInterface exif=new ExifInterface(exifIn);int ori=exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);Matrix m=new Matrix();if(ori==ExifInterface.ORIENTATION_ROTATE_90)m.postRotate(90);else if(ori==ExifInterface.ORIENTATION_ROTATE_180)m.postRotate(180);else if(ori==ExifInterface.ORIENTATION_ROTATE_270)m.postRotate(270);else if(ori==ExifInterface.ORIENTATION_FLIP_HORIZONTAL)m.setScale(-1,1);else if(ori==ExifInterface.ORIENTATION_FLIP_VERTICAL)m.setScale(1,-1);if(!m.isIdentity()){Bitmap f=Bitmap.createBitmap(scaled,0,0,scaled.getWidth(),scaled.getHeight(),m,true);if(f!=scaled)scaled.recycle();scaled=f;}}catch(Exception ignored){}return scaled;}

    private void saveToGallery(File file, int index)throws Exception{ContentResolver cr=getContentResolver();ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,String.format(Locale.getDefault(),"AI_Fotograaf_PRO_%03d.jpg",index));v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/AI Fotograaf PRO");android.net.Uri u=cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(u==null)throw new Exception("Opslaan mislukt");try(InputStream in=new FileInputStream(file);OutputStream out=cr.openOutputStream(u)){byte[] buf=new byte[65536];int len;while((len=in.read(buf))!=-1)out.write(buf,0,len);}}
    private void openGalleryFolder(){if(resultFiles.isEmpty()){Toast.makeText(this,"Nog geen resultaten",Toast.LENGTH_SHORT).show();return;}executor.execute(()->{int n=0;for(int i=0;i<resultFiles.size();i++)try{saveToGallery(resultFiles.get(i),i+1);n++;}catch(Exception ignored){}final int done=n;ui(()->Toast.makeText(this,done+" foto('s) opgeslagen in AI Fotograaf PRO",Toast.LENGTH_LONG).show());});}
    private void ui(Runnable r){runOnUiThread(r);}
    private File cacheResult(Bitmap b,int index)throws Exception{File f=new File(getCacheDir(),"ai_result_"+index+".jpg");try(FileOutputStream out=new FileOutputStream(f)){if(!b.compress(Bitmap.CompressFormat.JPEG,96,out))throw new Exception("Resultaat kon niet worden opgeslagen");}return f;}
    @Override protected void onDestroy(){executor.shutdownNow();if(faceDetector!=null)faceDetector.close();if(previewOriginalBitmap!=null&&!previewOriginalBitmap.isRecycled())previewOriginalBitmap.recycle();if(previewResultBitmap!=null&&!previewResultBitmap.isRecycled())previewResultBitmap.recycle();super.onDestroy();}
}
