package nl.aifotograaf.pro;

import android.app.*;
import android.os.*;
import android.provider.MediaStore;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.ExifInterface;
import android.net.Uri;
import android.view.*;
import android.view.WindowInsets;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    static final int PICK=101;
    LinearLayout root, content, bottom;
    ScrollView scroll;
    ImageView before, after;
    Bitmap original;
    float exposure=0, contrast=0, saturation=0, sharp=28, noise=28;
    TextView status;
    ArrayList<SeekBar> bars=new ArrayList<>();
    final Handler ui=new Handler(Looper.getMainLooper());
    final ExecutorService processor=Executors.newSingleThreadExecutor();
    int previewJob=0;
    int gold=Color.rgb(217,169,87), white=Color.rgb(247,242,232), panel=Color.rgb(23,21,21);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(Build.VERSION.SDK_INT>=30) getWindow().setDecorFitsSystemWindows(true);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        showIntro();
    }
    @Override protected void onDestroy(){ super.onDestroy(); processor.shutdownNow(); }
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(c);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(8),dp(4),dp(8),dp(4));return t;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;}

    void showIntro(){
        FrameLayout f=new FrameLayout(this); f.setBackgroundColor(Color.BLACK);
        ImageView hero=new ImageView(this); hero.setImageResource(R.drawable.loes_splash); hero.setScaleType(ImageView.ScaleType.CENTER_CROP); f.addView(hero,new FrameLayout.LayoutParams(-1,-1));
        View flash=new View(this); flash.setBackgroundColor(Color.WHITE); flash.setAlpha(0); f.addView(flash,new FrameLayout.LayoutParams(-1,-1));
        TextView brand=tv("PHOTOS BY LOES  •  AI FOTOGRAAF PRO",14,white); brand.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,dp(55),Gravity.BOTTOM);bp.setMargins(dp(18),0,dp(18),dp(24));f.addView(brand,bp);
        setContentView(f);
        hero.setAlpha(0f); hero.animate().alpha(1f).setDuration(850).start();
        ui.postDelayed(()->{flash.setAlpha(.95f);flash.animate().alpha(0).setDuration(460).start();},1250);
        ui.postDelayed(this::showHome,3900);
    }

    void showHome(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(8,8,8));
        root.setFitsSystemWindows(true);setContentView(root);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            int nav=0;
            if(Build.VERSION.SDK_INT>=30) nav=insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
            else nav=insets.getSystemWindowInsetBottom();
            if(bottom!=null){bottom.setPadding(dp(8),dp(6),dp(8),dp(6)+nav);}
            return insets;
        });

        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(dp(12),dp(6),dp(12),dp(6));
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.loes_app_logo);logo.setContentDescription("Loes AI Fotograaf");logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        head.addView(logo,new LinearLayout.LayoutParams(dp(62),dp(54)));
        TextView title=tv("Foto verbeteren",20,white);title.setGravity(Gravity.CENTER);head.addView(title,new LinearLayout.LayoutParams(0,dp(54),1));
        TextView more=tv("⋮",30,white);more.setGravity(Gravity.CENTER);head.addView(more,new LinearLayout.LayoutParams(dp(42),dp(54)));root.addView(head);

        scroll=new ScrollView(this);scroll.setFillViewport(true);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(12),dp(2),dp(12),dp(20));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        buildEditor();buildBottom();root.requestApplyInsets();
    }

    void buildEditor(){
        TextView hint=tv("Tijdloos • warm • natuurlijk • professioneel",14,Color.LTGRAY);hint.setPadding(dp(4),dp(6),dp(4),dp(8));content.addView(hint);
        LinearLayout actions=row();
        Button newP=button("＋ Nieuw project",gold,Color.BLACK);newP.setOnClickListener(v->newProject());actions.addView(newP,new LinearLayout.LayoutParams(0,dp(48),1));
        Button pick=button("▣ Foto kiezen",panel,white);pick.setOnClickListener(v->pickImages());actions.addView(pick,new LinearLayout.LayoutParams(0,dp(48),1));content.addView(actions);

        LinearLayout compare=row();before=new ImageView(this);after=new ImageView(this);styleImage(before);styleImage(after);
        compare.addView(cardImage(before,"Origineel"),new LinearLayout.LayoutParams(0,dp(285),1));compare.addView(cardImage(after,"Loes AI • verbeterd"),new LinearLayout.LayoutParams(0,dp(285),1));content.addView(compare);

        LinearLayout presets=row();String[] p={"✦ AI PERFECT","☘ Natuurlijk","☀ Vibrant","◉ Portret"};
        for(int i=0;i<p.length;i++){Button x=button(p[i],i==0?gold:panel,i==0?Color.BLACK:white);final int n=i;x.setOnClickListener(v->preset(n));presets.addView(x,new LinearLayout.LayoutParams(0,dp(58),1));}content.addView(presets);

        addSlider("☼ Belichting",-100,100,0,0);addSlider("◐ Contrast",-100,100,0,1);addSlider("◉ Kleuren",-100,100,0,2);addSlider("△ Scherpte",0,100,28,3);addSlider("▦ Ruisonderdrukking",0,100,28,4);

        LinearLayout tools=row();String[] ts={"✂ Bijsnijden","↻ Draaien","◉ Filters","⌫ Object verwijderen","▦ Collage"};
        for(String s:ts){Button x=button(s,panel,white);x.setOnClickListener(v->toolAction(s));tools.addView(x,new LinearLayout.LayoutParams(0,dp(54),1));}content.addView(tools);
        status=tv("Kies een foto om te beginnen.",13,Color.LTGRAY);status.setPadding(dp(6),dp(10),dp(6),dp(10));content.addView(status);
        LinearLayout save=row();Button sv=button("↓ Opslaan",gold,Color.BLACK);sv.setOnClickListener(v->save());Button sh=button("↗ Delen",panel,white);sh.setOnClickListener(v->share());save.addView(sv,new LinearLayout.LayoutParams(0,dp(58),1));save.addView(sh,new LinearLayout.LayoutParams(0,dp(58),1));content.addView(save);
        TextView end=tv("Loes AI Fotograaf PRO",12,Color.DKGRAY);end.setGravity(Gravity.CENTER);content.addView(end,new LinearLayout.LayoutParams(-1,dp(55)));
    }
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER);return l;}
    Button button(String s,int c,int tc){Button b=new Button(this);b.setText(s);b.setTextColor(tc);b.setTextSize(12);b.setAllCaps(false);b.setMinHeight(0);b.setMinWidth(0);b.setBackground(bg(c,22));return b;}
    LinearLayout cardImage(ImageView im,String label){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(2),dp(2),dp(2),dp(2));l.setBackground(bg(panel,22));TextView t=tv(label,12,label.contains("verbeterd")?gold:white);t.setGravity(Gravity.CENTER);l.addView(t,new LinearLayout.LayoutParams(-1,dp(34)));l.addView(im,new LinearLayout.LayoutParams(-1,0,1));return l;}
    void styleImage(ImageView i){i.setScaleType(ImageView.ScaleType.FIT_CENTER);i.setBackgroundColor(Color.BLACK);}

    void addSlider(String name,int min,int max,int val,int which){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(12),dp(6),dp(12),dp(3));c.setBackground(bg(panel,22));TextView lab=tv(name,14,white);c.addView(lab);
        SeekBar s=new SeekBar(this);s.setMax(max-min);s.setProgress(val-min);s.setPadding(dp(2),0,dp(2),0);bars.add(s);c.addView(s,new LinearLayout.LayoutParams(-1,dp(40)));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean f){float v=p+min;if(which==0)exposure=v;if(which==1)contrast=v;if(which==2)saturation=v;if(which==3)sharp=v;if(which==4)noise=v;schedulePreview();}
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){schedulePreview();}
        });
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(80));cp.setMargins(0,dp(4),0,0);content.addView(c,cp);
    }

    void buildBottom(){
        bottom=row();bottom.setBackgroundColor(Color.rgb(12,12,12));bottom.setElevation(dp(12));
        String[] n={"⌂ Home","＋ Nieuw","▣ Resultaten","⚙ Instellingen"};
        for(int i=0;i<n.length;i++){
            Button b=button(n[i],i==0?gold:panel,i==0?Color.BLACK:white);b.setMinHeight(dp(54));b.setPadding(dp(1),0,dp(1),0);final int x=i;
            b.setOnClickListener(v->{if(x==0)scroll.smoothScrollTo(0,0);else if(x==1)newProject();else if(x==2)scrollToResults();else showSettings();});
            bottom.addView(b,new LinearLayout.LayoutParams(0,dp(60),1));
        }
        root.addView(bottom,new LinearLayout.LayoutParams(-1,dp(72)));root.requestApplyInsets();
    }

    void showSettings(){
        new AlertDialog.Builder(this).setTitle("Loes AI Fotograaf PRO").setMessage("Lokale verwerking\nOriginele foto blijft behouden\nVolledige kwaliteit bij opslaan\nPreview gebruikt een kleinere kopie voor directe bediening\n\nVersie 3.0 PRO").setPositiveButton("Sluiten",null).show();
    }

    void newProject(){
        previewJob++;original=null;before.setImageDrawable(null);after.setImageDrawable(null);exposure=contrast=saturation=0;sharp=28;noise=28;
        int[] defaults={100,100,100,28,28};for(int i=0;i<bars.size();i++)bars.get(i).setProgress(defaults[i]);status.setText("Nieuw project gestart. Kies een foto.");scroll.smoothScrollTo(0,0);
    }
    void pickImages(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK&&c==RESULT_OK&&d!=null){Uri u=d.getData();if(u!=null)loadImage(u);}}

    void loadImage(Uri u){
        try{
            InputStream in=getContentResolver().openInputStream(u);BitmapFactory.Options o=new BitmapFactory.Options();o.inPreferredConfig=Bitmap.Config.ARGB_8888;Bitmap b=BitmapFactory.decodeStream(in);in.close();
            if(b==null)throw new Exception();b=orient(u,b);original=scale(b,3200);before.setImageBitmap(original);after.setImageBitmap(scale(original,900));status.setText("Foto geladen. Loes AI PERFECT analyseert de opname...");schedulePreview();
        }catch(Exception e){Toast.makeText(this,"Foto kon niet worden geladen.",Toast.LENGTH_SHORT).show();}
    }
    Bitmap orient(Uri u,Bitmap b)throws Exception{InputStream in=getContentResolver().openInputStream(u);ExifInterface ex=new ExifInterface(in);int o=ex.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);in.close();Matrix m=new Matrix();if(o==ExifInterface.ORIENTATION_ROTATE_90)m.postRotate(90);else if(o==ExifInterface.ORIENTATION_ROTATE_180)m.postRotate(180);else if(o==ExifInterface.ORIENTATION_ROTATE_270)m.postRotate(270);else return b;return Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,true);}
    Bitmap scale(Bitmap b,int max){float q=Math.min(1f,max/(float)Math.max(b.getWidth(),b.getHeight()));if(q>=1)return b;return Bitmap.createScaledBitmap(b,Math.round(b.getWidth()*q),Math.round(b.getHeight()*q),true);}

    void schedulePreview(){
        final int job=++previewJob;ui.removeCallbacksAndMessages("preview");
        Runnable r=()->processor.submit(()->{
            if(original==null)return;Bitmap src=scale(original,900);Bitmap out=process(src);
            ui.post(()->{if(job==previewJob&&after!=null){after.setImageBitmap(out);status.setText("AI PERFECT • live preview");}});
        });ui.postAtTime(r,"preview",System.currentTimeMillis()+90);
    }

    Bitmap process(Bitmap src){
        int w=src.getWidth(),h=src.getHeight();Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);int[] p=new int[w*h];src.getPixels(p,0,w,0,0,w,h);
        // Gentle auto correction. Preserve the warm, authentic character instead of flattening it.
        double sumR=0,sumG=0,sumB=0,sumL=0;int count=0;
        for(int i=0;i<p.length;i+=Math.max(1,p.length/12000)){int c=p[i];sumR+=(c>>16)&255;sumG+=(c>>8)&255;sumB+=c&255;sumL=(((c>>16)&255)+((c>>8)&255)+(c&255))/3.0;count++;}
        double ar=sumR/count,ag=sumG/count,ab=sumB/count,al=sumL/count;
        float wbR=(float)Math.max(.94,Math.min(1.06,ag/ar));float wbB=(float)Math.max(.94,Math.min(1.06,ag/ab));
        float exp=(float)Math.pow(2.0,exposure/100f*.55f);float con=1f+contrast/100f*.42f;float sat=1f+saturation/100f*.34f;
        for(int i=0;i<p.length;i++){
            int c=p[i];float r=(c>>16)&255,g=(c>>8)&255,b=c&255;
            // modest white-balance correction, weighted toward neutral so warm lamps remain warm
            float lum=(r+g+b)/3f;float wb=(lum<235?0.38f:0.22f);r*=1+(wbR-1)*wb;g*=1; b*=1+(wbB-1)*wb;
            r*=exp;g*=exp;b*=exp;
            // Film-like tone curve: opens midtones and shadows while protecting highlights.
            r=(float)(255*Math.pow(Math.max(0,Math.min(1,r/255f)),0.93));
            g=(float)(255*Math.pow(Math.max(0,Math.min(1,g/255f)),0.93));
            b=(float)(255*Math.pow(Math.max(0,Math.min(1,b/255f)),0.93));
            float L=(r+g+b)/3f/255f;float shadow=(1-L);float highlight=L;
            float shadowLift=(0.055f+0.10f*Math.max(0,exposure/100f))*shadow;
            float highlightProtect=0.045f*highlight;
            r+=255*shadowLift-255*highlightProtect;g+=255*shadowLift;b+=255*shadowLift-255*highlightProtect;
            r=(r-128)*con+128;g=(g-128)*con+128;b=(b-128)*con+128;
            float gray=(r+g+b)/3f;r=gray+(r-gray)*sat;g=gray+(g-gray)*sat;b=gray+(b-gray)*sat;
            p[i]=Color.rgb(clamp(r),clamp(g),clamp(b));
        }
        // Denoise only when requested, then sharpen with a restrained unsharp pass.
        if(noise>2) p=blur3(p,w,h,Math.min(0.35f,noise/100f*.32f));
        if(sharp>1) p=unsharp(p,w,h,Math.min(.72f,sharp/100f*.70f));
        out.setPixels(p,0,w,0,0,w,h);return out;
    }
    int[] blur3(int[] src,int w,int h,float amount){int[] out=src.clone();for(int y=1;y<h-1;y++)for(int x=1;x<w-1;x++){int i=y*w+x,c=src[i];int r=(c>>16)&255,g=(c>>8)&255,b=c&255;int ar=0,ag=0,ab=0;for(int yy=-1;yy<=1;yy++)for(int xx=-1;xx<=1;xx++){int q=src[(y+yy)*w+x+xx];ar+=(q>>16)&255;ag+=(q>>8)&255;ab+=q&255;}ar/=9;ag/=9;ab/=9;int rr=clamp(r+(ar-r)*amount),gg=clamp(g+(ag-g)*amount),bb=clamp(b+(ab-b)*amount);out[i]=Color.rgb(rr,gg,bb);}return out;}
    int[] unsharp(int[] src,int w,int h,float amount){int[] out=src.clone();for(int y=1;y<h-1;y++)for(int x=1;x<w-1;x++){int i=y*w+x,c=src[i];int up=src[i-w],dn=src[i+w],lf=src[i-1],rt=src[i+1];float r=(c>>16)&255,g=(c>>8)&255,b=c&255;float br=(((up>>16)&255)+((dn>>16)&255)+((lf>>16)&255)+((rt>>16)&255))/4f;float bg=(((up>>8)&255)+((dn>>8)&255)+((lf>>8)&255)+((rt>>8)&255))/4f;float bb=((up&255)+(dn&255)+(lf&255)+(rt&255))/4f;out[i]=Color.rgb(clamp(r+(r-br)*amount),clamp(g+(g-bg)*amount),clamp(b+(b-bb)*amount));}return out;}
    int clamp(float v){return (int)Math.max(0,Math.min(255,v));}

    void preset(int n){if(original==null){Toast.makeText(this,"Kies eerst een foto.",Toast.LENGTH_SHORT).show();return;}if(n==0){exposure=7;contrast=8;saturation=5;sharp=34;noise=30;}if(n==1){exposure=4;contrast=4;saturation=1;sharp=24;noise=24;}if(n==2){exposure=5;contrast=12;saturation=15;sharp=38;noise=18;}if(n==3){exposure=7;contrast=7;saturation=3;sharp=42;noise=32;}syncBars();schedulePreview();}
    void syncBars(){int[] vals={(int)exposure+100,(int)contrast+100,(int)saturation+100,(int)sharp,(int)noise};for(int i=0;i<bars.size();i++)bars.get(i).setProgress(vals[i]);}

    void toolAction(String s){
        if(original==null){Toast.makeText(this,"Kies eerst een foto.",Toast.LENGTH_SHORT).show();return;}
        if(s.contains("Draaien")){original=rotate(original,90);before.setImageBitmap(original);schedulePreview();}
        else if(s.contains("Filters")){preset(2);status.setText("Vibrant filter toegepast.");}
        else if(s.contains("Bijsnijden")){int w=original.getWidth(),h=original.getHeight(),side=Math.min(w,h);int x=(w-side)/2,y=(h-side)/2;original=Bitmap.createBitmap(original,x,y,side,side);before.setImageBitmap(original);schedulePreview();status.setText("Centrale uitsnede toegepast.");}
        else if(s.contains("Object verwijderen")){showObjectInfo();}
        else if(s.contains("Collage")){showCollageInfo();}
    }
    void showObjectInfo(){new AlertDialog.Builder(this).setTitle("Object verwijderen").setMessage("Deze PRO-versie bewaart de originele foto en voorkomt automatische vervorming van gezichten of personen. Selectieve AI-objectverwijdering wordt pas toegepast wanneer je zelf een gebied aanwijst.").setPositiveButton("Begrepen",null).show();}
    void showCollageInfo(){new AlertDialog.Builder(this).setTitle("Collage").setMessage("Collage is voorbereid voor meerdere foto's. De huidige workflow werkt bewust met één foto per project zodat de bewerking snel en stabiel blijft.").setPositiveButton("Begrepen",null).show();}
    Bitmap rotate(Bitmap b,int d){Matrix m=new Matrix();m.postRotate(d);return Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,true);}
    void scrollToResults(){scroll.smoothScrollTo(0,content.getHeight());}

    Bitmap rendered(){return original==null?null:process(original);}
    void save(){
        if(original==null){Toast.makeText(this,"Kies eerst een foto.",Toast.LENGTH_SHORT).show();return;}
        status.setText("Volledige PRO-bewerking wordt verwerkt...");
        processor.submit(()->{Bitmap b=rendered();ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,"Loes_AI_Foto_"+System.currentTimeMillis()+".jpg");v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/AI Fotograaf PRO");Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);try{OutputStream o=getContentResolver().openOutputStream(u);b.compress(Bitmap.CompressFormat.JPEG,97,o);o.close();ui.post(()->{status.setText("Klaar • volledige kwaliteit opgeslagen.");Toast.makeText(this,"Foto opgeslagen in AI Fotograaf PRO.",Toast.LENGTH_SHORT).show();});}catch(Exception e){ui.post(()->Toast.makeText(this,"Opslaan mislukt.",Toast.LENGTH_SHORT).show());}});
    }
    void share(){if(original==null){Toast.makeText(this,"Kies eerst een foto.",Toast.LENGTH_SHORT).show();return;}Toast.makeText(this,"Sla de foto eerst op; daarna kun je hem vanuit je galerij delen.",Toast.LENGTH_SHORT).show();}
}
