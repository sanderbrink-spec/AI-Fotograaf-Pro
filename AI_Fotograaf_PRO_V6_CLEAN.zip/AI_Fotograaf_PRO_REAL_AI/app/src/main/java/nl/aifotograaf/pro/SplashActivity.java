package nl.aifotograaf.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Typeface;

public class SplashActivity extends Activity {
    private static final int BG = Color.rgb(8,9,12);
    private static final int GOLD = Color.rgb(217,180,107);
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(dp(28), dp(20), dp(28), dp(20));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1,-1);
        cp.gravity = Gravity.CENTER;
        root.addView(content, cp);

        TextView brand = text("PHOTOS BY LOES", 13, GOLD, true);
        brand.setLetterSpacing(.18f);
        content.addView(brand, new LinearLayout.LayoutParams(-2, dp(34)));

        FrameLayout stage = new FrameLayout(this);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(270), dp(270));
        sp.topMargin = dp(18); sp.bottomMargin = dp(8);
        content.addView(stage, sp);

        ImageView ring = new ImageView(this);
        ring.setImageResource(R.drawable.splash_camera_ring);
        stage.addView(ring, frame(-1,-1,Gravity.CENTER));

        ImageView camera = new ImageView(this);
        camera.setImageResource(R.drawable.loes_logo);
        stage.addView(camera, frame(dp(178),dp(178),Gravity.CENTER));

        ImageView flash = new ImageView(this);
        flash.setImageResource(R.drawable.splash_flash);
        flash.setAlpha(0f);
        stage.addView(flash, frame(dp(70),dp(70),Gravity.CENTER));

        TextView title = text("AI FOTOGRAAF PRO", 30, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        content.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));

        TextView sub = text("PURE • ECHT • TIJDLOOS", 11, Color.rgb(166,171,181), true);
        sub.setGravity(Gravity.CENTER); sub.setLetterSpacing(.13f);
        content.addView(sub, new LinearLayout.LayoutParams(-1, dp(32)));

        TextView shot = text("●  LOES EDIT ENGINE  •  LOKAAL", 10, GOLD, true);
        shot.setGravity(Gravity.CENTER); shot.setLetterSpacing(.08f);
        content.addView(shot, new LinearLayout.LayoutParams(-1, dp(30)));

        setContentView(root);

        animateCamera(camera, ring, flash, title, sub, shot);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }, 3600);
    }

    private void animateCamera(ImageView camera, ImageView ring, ImageView flash, TextView title, TextView sub, TextView shot) {
        camera.setScaleX(.82f); camera.setScaleY(.82f); camera.setAlpha(.2f);
        ring.setScaleX(.88f); ring.setScaleY(.88f); ring.setAlpha(.2f);
        title.setAlpha(0f); sub.setAlpha(0f); shot.setAlpha(0f);

        camera.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).setInterpolator(new AccelerateDecelerateInterpolator()).start();
        ring.animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(360f).setDuration(1800).setInterpolator(new AccelerateDecelerateInterpolator()).start();
        title.animate().alpha(1f).setStartDelay(650).setDuration(600).start();
        sub.animate().alpha(1f).setStartDelay(900).setDuration(600).start();
        shot.animate().alpha(1f).setStartDelay(1150).setDuration(600).start();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            flash.animate().alpha(1f).scaleX(1.3f).scaleY(1.3f).setDuration(90).withEndAction(() ->
                flash.animate().alpha(0f).scaleX(.7f).scaleY(.7f).setDuration(220).start()).start();
            camera.animate().scaleX(.93f).scaleY(.93f).setDuration(90).withEndAction(() ->
                camera.animate().scaleX(1f).scaleY(1f).setDuration(260).start()).start();
        }, 1650);
    }

    private FrameLayout.LayoutParams frame(int w, int h, int gravity) {
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(w,h); p.gravity=gravity; return p;
    }
    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL); return t;
    }
}
