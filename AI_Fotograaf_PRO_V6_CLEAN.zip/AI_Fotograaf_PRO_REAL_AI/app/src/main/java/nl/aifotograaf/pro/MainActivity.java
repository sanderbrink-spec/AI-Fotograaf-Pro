package nl.aifotograaf.pro;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.exifinterface.media.ExifInterface;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * AI Fotograaf PRO Studio Edition.
 * Local, conservative photo enhancement with professional manual controls.
 * Original pixels remain the source; no cloud upload is used.
 */
public class MainActivity extends AppCompatActivity {
    private static final int BG=Color.rgb(7,9,12), CARD=Color.rgb(17,20,26), CARD2=Color.rgb(24,28,35);
    private static final int TEXT=Color.WHITE, MUTED=Color.rgb(157,164,175), ACCENT=Color.rgb(232,198,125), GREEN=Color.rgb(82,201,139);
    private static final int MAX_WORKING=2048;

    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final ArrayList<android.net.Uri> selected=new ArrayList<>();
    private final ArrayList<File> resultFiles=new ArrayList<>();
    private Bitmap previewOriginalBitmap, previewResultBitmap;
    private ActivityResultLauncher<Intent> picker;
    private TextView counter,status,resultTitle,modelBadge,editSummary;
    private ProgressBar progress;
    private Button selectButton,aiButton,saveButton;
    private ImageView beforeView,afterView;
    private LinearLayout resultsList, advancedTools;
    private String mode="AUTOMATISCH";
    private FaceDetector faceDetector;
    private boolean processing=false;
    private int rotation=0;

    // 0..200, center = neutral.
    private int exposure=100, contrast=100, highlights=100, shadows=100, saturation=100, warmth=100, clarity=100, sharpness=100;

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        picker=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r->{
            if(r.getResultCode()!=RESULT_OK || r.getData()==null) return;
            Intent d=r.getData(); selected.clear();
            if(d.getClipData()!=null){int n=Math.min(100,d.getClipData().getItemCount()); for(int i=0;i<n;i++) selected.add(d.getClipData().getItemAt(i).getUri());}
            else if(d.getData()!=null) selected.add(d.getData());
            counter.setText(selected.size()==1?"1 foto geselecteerd":selected.size()+" foto's geselecteerd");
            aiButton.setEnabled(!selected.isEmpty()&&!processing);
            status.setText("Klaar voor AI PERFECT");
            if(!selected.isEmpty()) showPreview(selected.get(0));
        });
        buildUi(); initFaceDetector(); animateEntrance();
        modelBadge.setText("●  LOKALE AI-ANALYSE • STUDIO ENGINE");
        status.setText("Kies foto's en maak ze PRO");
    }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(12),dp(18),dp(30)); scroll.addView(root,new ScrollView.LayoutParams(-1,-1));

        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=tv("AI FOTOGRAAF",27,TEXT,true); title.setLetterSpacing(.015f); header.addView(title,weightLp(0,dp(48),1));
        TextView pro=tv("PRO",11,BG,true); pro.setGravity(Gravity.CENTER); pro.setBackground(round(ACCENT,18)); header.addView(pro,new LinearLayout.LayoutParams(dp(58),dp(36))); root.addView(header,lpMargin(-1,dp(48),0,0,0,4));
        TextView by=tv("PHOTOS BY LOES  •  STUDIO EDITION",11,ACCENT,true); by.setLetterSpacing(.10f); root.addView(by,lpMargin(-1,dp(22),0,0,0,10));

        LinearLayout hero=card(); hero.setBackground(roundGradient(CARD,ACCENT,20));
        hero.addView(tv("JOUW FOTO. PROFESSIONEEL AFGEWERKT.",18,TEXT,true),wrap(-1));
        hero.addView(tv("Lokale AI-analyse • natuurlijke details • volledige controle",12,MUTED,false),lpMargin(-1,-2,0,dp(5),0,0));
        modelBadge=tv("●  ENGINE INITIALISEERT...",10,GREEN,true); modelBadge.setPadding(0,dp(8),0,0); hero.addView(modelBadge,wrap(-1));
        root.addView(hero,lpMargin(-1,-2,0,0,0,12));

        counter=tv("Nog geen foto's geselecteerd",13,MUTED,false); root.addView(counter,lpMargin(-1,dp(26),0,0,0,7));
        selectButton=bigButton("＋  FOTO'S KIEZEN  •  MAX. 100",CARD2,TEXT); root.addView(selectButton,lpMargin(-1,dp(54),0,0,0,12)); selectButton.setOnClickListener(v->openPicker());

        root.addView(tv("BEWERKPROFIEL",11,MUTED,true),lpMargin(-1,dp(22),0,0,0,7));
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); LinearLayout modes=new LinearLayout(this); modes.setOrientation(LinearLayout.HORIZONTAL);
        for(String m:new String[]{"AUTOMATISCH","PORTRET","LANDSCHAP","LOW LIGHT","CINEMATIC"}){Button b=smallButton(m,m.equals(mode)); LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(dp(122),dp(48)); mp.setMargins(0,0,dp(8),0); modes.addView(b,mp); b.setOnClickListener(v->{mode=((Button)v).getText().toString();applyPreset(mode);refreshModes(modes);updateEditorLabels();});}
        hs.addView(modes,new HorizontalScrollView.LayoutParams(-2,dp(48))); root.addView(hs,lpMargin(-1,dp(48),0,0,0,14));

        LinearLayout preview=card(); preview.addView(tv("VOOR / NA  •  LIVE",11,MUTED,true),wrap(-1));
        LinearLayout cmp=new LinearLayout(this); cmp.setOrientation(LinearLayout.HORIZONTAL); cmp.setPadding(0,dp(8),0,0);
        LinearLayout bp=previewPane("ORIGINEEL",true), ap=previewPane("AI PERFECT",false);
        cmp.addView(bp,weightLp(0,dp(202),1)); cmp.addView(new View(this),new LinearLayout.LayoutParams(dp(8),1)); cmp.addView(ap,weightLp(0,dp(202),1)); preview.addView(cmp,wrap(-1)); root.addView(preview,lpMargin(-1,-2,0,0,0,12));

        aiButton=bigButton("✦  AI PERFECT  •  VERBETER FOTO'S",ACCENT,BG); aiButton.setEnabled(false); root.addView(aiButton,lpMargin(-1,dp(58),0,0,0,8)); aiButton.setOnClickListener(v->pulse(v)); aiButton.setOnClickListener(v->processAll());
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setMax(100); progress.setProgress(0); root.addView(progress,lpMargin(-1,dp(8),0,0,0,4));
        status=tv("Kies foto's voor AI PERFECT",12,MUTED,false); root.addView(status,lpMargin(-1,dp(30),0,0,0,10));

        // Professional manual editor.
        LinearLayout editor=card();
        LinearLayout editorHead=new LinearLayout(this); editorHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView eh=tv("PRO EDITOR",12,TEXT,true); editorHead.addView(eh,weightLp(0,dp(30),1));
        Button reset=smallButton("RESET",false); reset.setTextSize(10); editorHead.addView(reset,new LinearLayout.LayoutParams(dp(72),dp(34))); editor.addView(editorHead,wrap(-1));
        editSummary=tv("Belichting 0  •  Contrast 0  •  Kleur 0",10,MUTED,false); editor.addView(editSummary,lpMargin(-1,dp(22),0,0,0,4));
        advancedTools=new LinearLayout(this); advancedTools.setOrientation(LinearLayout.VERTICAL); editor.addView(advancedTools,wrap(-1));
        String[] names={"BELICHTING","CONTRAST","HIGHLIGHTS","SCHADUWEN","VERZADIGING","WARMTE","CLARITY","DETAIL"};
        int[] vals={exposure,contrast,highlights,shadows,saturation,warmth,clarity,sharpness};
        for(int i=0;i<names.length;i++){SeekBar sb=addTool(editor,names[i],vals[i]); final int idx=i; sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean from){setToolValue(idx,p); updateEditorLabels();} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}});}
        reset.setOnClickListener(v->{applyPreset("AUTOMATISCH"); updateEditorLabels();});
        root.addView(editor,lpMargin(-1,-2,0,0,0,12));

        LinearLayout tools=card(); tools.addView(tv("STUDIO TOOLS",11,MUTED,true),wrap(-1));
        HorizontalScrollView toolScroll=new HorizontalScrollView(this); toolScroll.setHorizontalScrollBarEnabled(false); LinearLayout toolRow=new LinearLayout(this);
        Button rotate=smallButton("↻  ROTEREN",false); Button enhance=smallButton("✦  AUTO",false); Button info=smallButton("ⓘ  DETAILS",false);
        toolRow.addView(rotate,new LinearLayout.LayoutParams(dp(116),dp(44))); toolRow.addView(enhance,new LinearLayout.LayoutParams(dp(110),dp(44))); toolRow.addView(info,new LinearLayout.LayoutParams(dp(116),dp(44)));
        rotate.setOnClickListener(v->{rotation=(rotation+90)%360; if(!selected.isEmpty()) showPreview(selected.get(0)); status.setText("Rotatie ingesteld op "+rotation+"°");});
        enhance.setOnClickListener(v->{applyPreset("AUTOMATISCH"); updateEditorLabels(); status.setText("Automatische studio-instellingen toegepast");});
        info.setOnClickListener(v->Toast.makeText(this,"Alle bewerkingen blijven lokaal op je telefoon.",Toast.LENGTH_LONG).show());
        toolScroll.addView(toolRow); tools.addView(toolScroll,lpMargin(-1,dp(46),0,0,0,0)); root.addView(tools,lpMargin(-1,-2,0,0,0,12));

        LinearLayout features=card(); features.addView(tv("PRO-FUNCTIES",11,MUTED,true),wrap(-1));
        for(String f:new String[]{"Lokale scène- en gezichtsanalyse","Gezichtsveilige detailverwerking","Belichting, highlights & schaduwen","Kleur, warmte & verzadiging","Clarity & detailcontrole","Batchverwerking tot 100 foto's","Geen cloud • geen account nodig"}){TextView row=tv("✓  "+f,13,TEXT,false); row.setPadding(0,dp(3),0,dp(3)); features.addView(row,wrap(-1));}
        root.addView(features,lpMargin(-1,-2,0,0,0,12));

        LinearLayout result=card(); resultTitle=tv("RESULTATEN",11,MUTED,true); result.addView(resultTitle,wrap(-1)); resultsList=new LinearLayout(this); resultsList.setOrientation(LinearLayout.VERTICAL); result.addView(resultsList,wrap(-1));
        saveButton=bigButton("OPSLAAN / OPENEN IN FOTO'S",CARD2,TEXT); saveButton.setEnabled(false); result.addView(saveButton,lpMargin(-1,dp(50),0,0,0,0)); saveButton.setOnClickListener(v->openGalleryFolder()); root.addView(result,lpMargin(-1,-2,0,0,0,12));
        TextView privacy=tv("PHOTOS BY LOES  •  AI FOTOGRAAF PRO  •  PRIVACY FIRST",10,MUTED,true); privacy.setLetterSpacing(.05f); root.addView(privacy,wrap(-1));
        setContentView(scroll);
    }

    private SeekBar addTool(LinearLayout parent,String name,int value){
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,dp(2),0,dp(2));
        TextView label=tv(name,10,MUTED,true); row.addView(label,new LinearLayout.LayoutParams(dp(96),dp(42)));
        SeekBar sb=new SeekBar(this); sb.setMax(200); sb.setProgress(value); row.addView(sb,weightLp(0,dp(42),1)); parent.addView(row,wrap(-1)); return sb;
    }

    private void setToolValue(int idx,int v){switch(idx){case 0:exposure=v;break;case 1:contrast=v;break;case 2:highlights=v;break;case 3:shadows=v;break;case 4:saturation=v;break;case 5:warmth=v;break;case 6:clarity=v;break;case 7:sharpness=v;break;}}
    private void updateEditorLabels(){if(editSummary!=null)editSummary.setText(String.format(Locale.getDefault(),"Belichting %+d  •  Contrast %+d  •  Kleur %+d",exposure-100,contrast-100,saturation-100));}

    private void applyPreset(String p){
        if(p.equals("PORTRET")){exposure=104;contrast=103;highlights=94;shadows=112;saturation=101;warmth=104;clarity=96;sharpness=94;}
        else if(p.equals("LANDSCHAP")){exposure=101;contrast=108;highlights=92;shadows=105;saturation=110;warmth=98;clarity=110;sharpness=108;}
        else if(p.equals("LOW LIGHT")){exposure=112;contrast=103;highlights=88;shadows=125;saturation=101;warmth=102;clarity=98;sharpness=100;}
        else if(p.equals("CINEMATIC")){exposure=98;contrast=108;highlights=90;shadows=110;saturation=96;warmth=104;clarity=104;sharpness=98;}
        else {exposure=100;contrast=102;highlights=96;shadows=108;saturation=102;warmth=100;clarity=101;sharpness=100;}
        if(advancedTools!=null){for(int i=0;i<advancedTools.getChildCount();i++){View r=advancedTools.getChildAt(i);if(r instanceof LinearLayout){for(int j=0;j<((LinearLayout)r).getChildCount();j++){View c=((LinearLayout)r).getChildAt(j);if(c instanceof SeekBar){int[] v={exposure,contrast,highlights,shadows,saturation,warmth,clarity,sharpness};((SeekBar)c).setProgress(v[i]);}}}}}
    }

    private void refreshModes(LinearLayout m){for(int i=0;i<m.getChildCount();i++){Button b=(Button)m.getChildAt(i);boolean a=b.getText().toString().equals(mode);b.setBackground(round(a?ACCENT:CARD2,22));b.setTextColor(a?BG:TEXT);}}
    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(14),dp(13),dp(14),dp(13));l.setBackground(round(CARD,18));return l;}
    private LinearLayout previewPane(String label,boolean before){LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);TextView t=tv(label,10,MUTED,true);t.setPadding(dp(2),0,0,dp(5));p.addView(t,wrap(-1));ImageView im=imageBox(label);if(before)beforeView=im;else afterView=im;p.addView(im,new LinearLayout.LayoutParams(-1,dp(172)));return p;}
    private ImageView imageBox(String label){ImageView v=new ImageView(this);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(round(CARD2,14));v.setContentDescription(label);return v;}
    private Button bigButton(String s,int bg,int fg){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);b.setTextColor(fg);b.setAllCaps(false);b.setGravity(Gravity.CENTER);b.setBackground(round(bg,16));b.setPadding(dp(10),0,dp(10),0);b.setMinHeight(0);b.setMinWidth(0);return b;}
    private Button smallButton(String s,boolean a){Button b=bigButton(s,a?ACCENT:CARD2,a?BG:TEXT);b.setTextSize(11);return b;}
    private TextView tv(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setTypeface(android.graphics.Typeface.DEFAULT,bold?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL);return t;}
    private LinearLayout.LayoutParams wrap(int w){return new LinearLayout.LayoutParams(w,-2);}
    private LinearLayout.LayoutParams lpMargin(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(l,t,r,b);return p;}
    private LinearLayout.LayoutParams weightLp(int w,int h,float wt){return new LinearLayout.LayoutParams(w,h,wt);}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private android.graphics.drawable.GradientDrawable round(int c,int r){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    private android.graphics.drawable.GradientDrawable roundGradient(int c,int accent,int r){android.graphics.drawable.GradientDrawable g=round(c,r);g.setStroke(dp(1),Color.rgb(58,53,44));return g;}

    private void animateEntrance(){
        final View root=findViewById(android.R.id.content); AlphaAnimation a=new AlphaAnimation(.0f,1f);a.setDuration(550);root.startAnimation(a);
    }
    private void pulse(View v){ScaleAnimation s=new ScaleAnimation(1f,.985f,1f,.985f,1,0.5f,1,0.5f);s.setDuration(110);s.setRepeatCount(1);s.setRepeatMode(ScaleAnimation.REVERSE);v.startAnimation(s);}

    private void openPicker(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);picker.launch(i);}
    private void showPreview(android.net.Uri uri){executor.execute(()->{try{Bitmap b=decodeScaled(uri,MAX_WORKING);ui(()->{beforeView.setImageBitmap(b);afterView.setImageDrawable(null);});}catch(Exception e){ui(()->status.setText("Foto kon niet worden gelezen"));}});}
    private void initFaceDetector(){FaceDetectorOptions opts=new FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE).setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL).setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).build();faceDetector=FaceDetection.getClient(opts);}

    private void processAll(){if(processing||selected.isEmpty())return;processing=true;pulse(aiButton);aiButton.setEnabled(false);selectButton.setEnabled(false);saveButton.setEnabled(false);resultFiles.clear();resultsList.removeAllViews();progress.setProgress(0);resultTitle.setText("RESULTATEN • BEZIG");
        executor.execute(()->{int total=selected.size(); for(int n=0;n<total;n++){final int index=n+1;try{ui(()->status.setText(String.format(Locale.getDefault(),"AI PERFECT • foto %d / %d • analyseren...",index,total)));Bitmap src=decodeScaled(selected.get(n),MAX_WORKING);List<Rect> faces=detectFaces(src);ui(()->status.setText(String.format(Locale.getDefault(),"AI PERFECT • foto %d / %d • studio-bewerking...",index,total)));Bitmap out=enhancePhoto(src,faces);
                    File cached=cacheResult(out,index); resultFiles.add(cached);
                    if(n==0){Bitmap pvSrc=src.copy(Bitmap.Config.ARGB_8888,false);Bitmap pvOut=out.copy(Bitmap.Config.ARGB_8888,false);ui(()->lastPreview(pvSrc,pvOut));}
                    if(out!=src&&!out.isRecycled())out.recycle(); if(src!=null&&!src.isRecycled())src.recycle(); final int done=n+1;ui(()->{progress.setProgress(done*100/total);addResultRow(done,faces.size());});
                }catch(Exception e){final String msg=e.getMessage()==null?"onbekende fout":e.getMessage();ui(()->status.setText("Foto "+index+": "+msg));}}
            ui(()->{processing=false;aiButton.setEnabled(!selected.isEmpty());selectButton.setEnabled(true);saveButton.setEnabled(!resultFiles.isEmpty());resultTitle.setText("RESULTATEN • "+resultFiles.size()+" KLAAR");status.setText(resultFiles.isEmpty()?"Geen resultaat":"AI PERFECT klaar • AI studio-bewerking voltooid");});
        });
    }
    private void lastPreview(Bitmap src,Bitmap out){if(previewOriginalBitmap!=null&&!previewOriginalBitmap.isRecycled())previewOriginalBitmap.recycle();if(previewResultBitmap!=null&&!previewResultBitmap.isRecycled())previewResultBitmap.recycle();previewOriginalBitmap=src;previewResultBitmap=out;beforeView.setImageBitmap(src);afterView.setImageBitmap(out);}
    private void addResultRow(int n,int faces){TextView r=tv("✓  Foto "+n+"  •  STUDIO  •  "+faces+" gezicht(en) beschermd",12,GREEN,false);resultsList.addView(r,wrap(-1));}
    private List<Rect> detectFaces(Bitmap b)throws Exception{if(faceDetector==null)return Collections.emptyList();List<Face> faces=Tasks.await(faceDetector.process(InputImage.fromBitmap(b,0)));ArrayList<Rect> r=new ArrayList<>();for(Face f:faces)r.add(new Rect(f.getBoundingBox()));return r;}
    private boolean inFace(int x,int y,List<Rect> faces){for(Rect r:faces){int pad=Math.max(12,(int)(Math.max(r.width(),r.height())*.14));if(x>=r.left-pad&&x<=r.right+pad&&y>=r.top-pad&&y<=r.bottom+pad)return true;}return false;}

    /**
     * Quality-first local photo engine.
     * This deliberately avoids destructive 4x upscaling. It analyses the image first,
     * restores dynamic range, corrects mild colour casts, reduces chroma noise, adds
     * edge-aware detail and protects detected faces from aggressive processing.
     */
    private Bitmap enhancePhoto(Bitmap src,List<Rect>faces){
        final int w=src.getWidth(), h=src.getHeight();
        final int[] p=new int[w*h], q=new int[w*h];
        src.getPixels(p,0,w,0,0,w,h);

        // 1. Robust exposure analysis using a luminance histogram.
        int[] hist=new int[256]; long count=0; double mean=0, meanR=0, meanG=0, meanB=0;
        for(int y=0;y<h;y+=8){
            for(int x=0;x<w;x+=8){
                int c=p[y*w+x];
                int l=clamp(Math.round(luma(c)));
                hist[l]++; count++; mean+=l;
                meanR+=Color.red(c); meanG+=Color.green(c); meanB+=Color.blue(c);
            }
        }
        mean/=Math.max(1,count); meanR/=Math.max(1,count); meanG/=Math.max(1,count); meanB/=Math.max(1,count);
        int p01=percentile(hist,count,.01), p50=percentile(hist,count,.50), p99=percentile(hist,count,.99);
        float range=Math.max(80,p99-p01);

        // Limited gray-world correction. Never allow a strong colour shift.
        float avg=(float)((meanR+meanG+meanB)/3.0);
        float rWB=clampf(avg/(float)Math.max(1,meanR),.94f,1.06f);
        float gWB=clampf(avg/(float)Math.max(1,meanG),.96f,1.04f);
        float bWB=clampf(avg/(float)Math.max(1,meanB),.94f,1.06f);

        // Automatic exposure is intentionally noticeable, but capped to avoid blown highlights.
        float targetMean=132f;
        float autoExp=clampf(1f+(targetMean-(float)mean)/420f,.93f,1.10f);
        if(p99>248) autoExp=Math.min(autoExp,1.01f);
        if(p01<8 && mean<105) autoExp=Math.max(autoExp,1.025f);

        float userExp=(float)Math.pow(2.0,(exposure-100)/100.0*.55);
        float contrastGain=1f+(contrast-100)/100f*.24f;
        float satGain=1f+(saturation-100)/100f*.22f;
        float warm=(warmth-100)/100f*.055f;
        float shadowLift=(shadows-100)/100f*18f;
        float highlightCut=(highlights-100)/100f*20f;
        float clarityGain=1f+(clarity-100)/100f*.30f;
        float sharpGain=1f+(sharpness-100)/100f*.10f;

        for(int y=1;y<h-1;y++){
            for(int x=1;x<w-1;x++){
                int i=y*w+x, c=p[i];
                float r=Color.red(c), g=Color.green(c), b=Color.blue(c);
                float lum=luma(c);
                boolean face=inFace(x,y,faces);

                // Dynamic range mapping: open shadows and gently compress highlights.
                float t=clampf((lum-p01)/range,0,1);
                float curve=(t-.5f)*contrastGain+.5f;
                float mapped=curve*range+p01;
                if(lum<105) mapped+=Math.min(20f,(105-lum)*.22f+shadowLift);
                if(lum>190) mapped-=Math.min(24f,(lum-190)*.17f+highlightCut);
                float desired=clampf(mapped*autoExp*userExp,0,255);
                float gain=lum>6?desired/lum:1f;
                r*=gain; g*=gain; b*=gain;

                // Mild automatic white balance and user warmth.
                r*=rWB*(1f+warm); g*=gWB; b*=bWB*(1f-warm*.85f);

                // Smart saturation: protect skin/bright areas from cartoon colours.
                float gray=r*.299f+g*.587f+b*.114f;
                float localSat=satGain;
                if(lum>220) localSat*=.75f;
                if(face) localSat=Math.min(localSat,1.08f);
                r=gray+(r-gray)*localSat;
                g=gray+(g-gray)*localSat;
                b=gray+(b-gray)*localSat;

                // Edge-aware local contrast using a 4-neighbour low-pass estimate.
                float avgN=(luma(p[i-1])+luma(p[i+1])+luma(p[i-w])+luma(p[i+w]))*.25f;
                float edge=lum-avgN;
                float detail=clampf(edge*(face?sharpGain*.30f:sharpGain)*clarityGain,-10f,10f);

                // Chroma noise reduction: stronger in flat areas, weaker around faces/edges.
                float nr=Color.red(p[i-1])+Color.red(p[i+1])+Color.red(p[i-w])+Color.red(p[i+w]);
                float ng=Color.green(p[i-1])+Color.green(p[i+1])+Color.green(p[i-w])+Color.green(p[i+w]);
                float nb=Color.blue(p[i-1])+Color.blue(p[i+1])+Color.blue(p[i-w])+Color.blue(p[i+w]);
                float noiseBlend=face?.035f:.075f;
                r=r*(1-noiseBlend)+(nr*.25f)*noiseBlend;
                g=g*(1-noiseBlend)+(ng*.25f)*noiseBlend;
                b=b*(1-noiseBlend)+(nb*.25f)*noiseBlend;

                // Preserve faces: less sharpening, and very subtle skin texture smoothing only.
                if(face){
                    float maxc=Math.max(r,Math.max(g,b)), minc=Math.min(r,Math.min(g,b));
                    float sat=(maxc-minc)/Math.max(1,maxc);
                    boolean skinLike=(r>g*.92f && r>b*1.08f && g>b*1.02f && sat>.05f && sat<.55f);
                    if(skinLike){
                        float skinAvg=(r+g+b)/3f;
                        r=r*.94f+skinAvg*.06f; g=g*.94f+skinAvg*.06f; b=b*.94f+skinAvg*.06f;
                    }
                }

                r+=detail; g+=detail; b+=detail;
                q[i]=Color.rgb(clamp(r),clamp(g),clamp(b));
            }
        }
        // Copy untouched border pixels.
        for(int x=0;x<w;x++){q[x]=p[x];q[(h-1)*w+x]=p[(h-1)*w+x];}
        for(int y=0;y<h;y++){q[y*w]=p[y*w];q[y*w+w-1]=p[y*w+w-1];}
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        out.setPixels(q,0,w,0,0,w,h);
        return out;
    }
    private int percentile(int[] hist,long total,double f){long target=Math.max(1,Math.round(total*f)),s=0;for(int i=0;i<hist.length;i++){s+=hist[i];if(s>=target)return i;}return 255;}
    private float luma(int c){return Color.red(c)*.299f+Color.green(c)*.587f+Color.blue(c)*.114f;}
    private float clampf(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}private int clamp(float v){return Math.max(0,Math.min(255,Math.round(v)));}

    private Bitmap decodeScaled(android.net.Uri uri,int max)throws Exception{BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,o);}int w=o.outWidth,h=o.outHeight;if(w<=0||h<=0)throw new Exception("Ongeldige foto");float sc=Math.min(1f,max/(float)Math.max(w,h));int nw=Math.max(1,Math.round(w*sc)),nh=Math.max(1,Math.round(h*sc));BitmapFactory.Options p=new BitmapFactory.Options();p.inPreferredConfig=Bitmap.Config.ARGB_8888;Bitmap b;try(InputStream in=getContentResolver().openInputStream(uri)){b=BitmapFactory.decodeStream(in,null,p);}if(b==null)throw new Exception("Afbeelding kon niet worden gelezen");Bitmap scaled=Bitmap.createScaledBitmap(b,nw,nh,true);if(scaled!=b)b.recycle();try(InputStream exifIn=getContentResolver().openInputStream(uri)){ExifInterface exif=new ExifInterface(exifIn);int ori=exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);Matrix m=new Matrix();if(ori==ExifInterface.ORIENTATION_ROTATE_90)m.postRotate(90);else if(ori==ExifInterface.ORIENTATION_ROTATE_180)m.postRotate(180);else if(ori==ExifInterface.ORIENTATION_ROTATE_270)m.postRotate(270);else if(ori==ExifInterface.ORIENTATION_FLIP_HORIZONTAL)m.setScale(-1,1);else if(ori==ExifInterface.ORIENTATION_FLIP_VERTICAL)m.setScale(1,-1);if(rotation!=0)m.postRotate(rotation);if(!m.isIdentity()){Bitmap f=Bitmap.createBitmap(scaled,0,0,scaled.getWidth(),scaled.getHeight(),m,true);if(f!=scaled)scaled.recycle();scaled=f;}}catch(Exception ignored){}return scaled;}
    private void saveToGallery(File file,int index)throws Exception{ContentResolver cr=getContentResolver();ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,String.format(Locale.getDefault(),"AI_Fotograaf_PRO_%03d.jpg",index));v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/AI Fotograaf PRO");android.net.Uri u=cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(u==null)throw new Exception("Opslaan mislukt");try(InputStream in=new FileInputStream(file);OutputStream out=cr.openOutputStream(u)){byte[] buf=new byte[65536];int len;while((len=in.read(buf))!=-1)out.write(buf,0,len);}}
    private void openGalleryFolder(){if(resultFiles.isEmpty()){Toast.makeText(this,"Nog geen resultaten",Toast.LENGTH_SHORT).show();return;}executor.execute(()->{int n=0;for(int i=0;i<resultFiles.size();i++)try{saveToGallery(resultFiles.get(i),i+1);n++;}catch(Exception ignored){}final int done=n;ui(()->Toast.makeText(this,done+" foto('s) opgeslagen in AI Fotograaf PRO",Toast.LENGTH_LONG).show());});}
    private void ui(Runnable r){runOnUiThread(r);}private File cacheResult(Bitmap b,int index)throws Exception{File f=new File(getCacheDir(),"ai_result_"+index+".jpg");try(FileOutputStream out=new FileOutputStream(f)){if(!b.compress(Bitmap.CompressFormat.JPEG,96,out))throw new Exception("Resultaat kon niet worden opgeslagen");}return f;}
    @Override protected void onDestroy(){executor.shutdownNow();if(faceDetector!=null)faceDetector.close();if(previewOriginalBitmap!=null&&!previewOriginalBitmap.isRecycled())previewOriginalBitmap.recycle();if(previewResultBitmap!=null&&!previewResultBitmap.isRecycled())previewResultBitmap.recycle();super.onDestroy();}
}
