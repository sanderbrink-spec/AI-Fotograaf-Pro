package nl.aifotograaf.pro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Typeface;

public class SplashActivity extends Activity {
    private static final int BG = Color.rgb(8,9,12);
    private static final int GOLD = Color.rgb(217,180,107);
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        ImageView hero = new ImageView(this);
        hero.setImageResource(R.drawable.splash_loes_photo);
        hero.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hero.setAlpha(.0f);
        root.addView(hero, new FrameLayout.LayoutParams(-1, dp(315), Gravity.TOP));

        View shade = new View(this);
        shade.setBackgroundColor(Color.argb(42,0,0,0));
        root.addView(shade, new FrameLayout.LayoutParams(-1, dp(315), Gravity.TOP));

        ImageView wink = new ImageView(this);
        wink.setImageResource(R.drawable.wink_overlay);
        wink.setScaleType(ImageView.ScaleType.FIT_XY);
        wink.setAlpha(0f);
        FrameLayout.LayoutParams wp = new FrameLayout.LayoutParams(-1, dp(315), Gravity.TOP);
        root.addView(wink, wp);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setGravity(Gravity.CENTER_HORIZONTAL);
        bottom.setPadding(dp(24),dp(10),dp(24),dp(22));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);
        root.addView(bottom,bp);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.loes_photo_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        logo.setAlpha(0f);
        bottom.addView(logo,new LinearLayout.LayoutParams(dp(128),dp(128)));

        TextView brand = text("PHOTOS BY LOES", 13, GOLD, true);
        brand.setLetterSpacing(.18f);
        brand.setGravity(Gravity.CENTER);
        bottom.addView(brand,new LinearLayout.LayoutParams(-1,dp(28)));

        TextView title = text("AI FOTOGRAAF PRO", 29, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        bottom.addView(title,new LinearLayout.LayoutParams(-1,dp(46)));

        TextView sub = text("PURE • ECHT • TIJDLOOS", 11, Color.rgb(166,171,181), true);
        sub.setGravity(Gravity.CENTER); sub.setLetterSpacing(.13f);
        bottom.addView(sub,new LinearLayout.LayoutParams(-1,dp(30)));

        TextView shot = text("●  LOES EDIT ENGINE  •  LOKAAL", 10, GOLD, true);
        shot.setGravity(Gravity.CENTER); shot.setLetterSpacing(.08f);
        bottom.addView(shot,new LinearLayout.LayoutParams(-1,dp(28)));

        setContentView(root);
        animateSplash(hero,wink,logo,title,sub,shot);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(this,MainActivity.class));
            finish();
        },3800);
    }

    private void animateSplash(ImageView hero,ImageView wink,ImageView logo,TextView title,TextView sub,TextView shot){
        hero.animate().alpha(1f).setDuration(650).start();
        logo.setScaleX(.75f);logo.setScaleY(.75f);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(350).setDuration(650).setInterpolator(new AccelerateDecelerateInterpolator()).start();
        title.setAlpha(0f);sub.setAlpha(0f);shot.setAlpha(0f);
        title.animate().alpha(1f).setStartDelay(850).setDuration(550).start();
        sub.animate().alpha(1f).setStartDelay(1050).setDuration(550).start();
        shot.animate().alpha(1f).setStartDelay(1250).setDuration(550).start();

        // Camera click + flash + wink at exactly the same moment.
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            wink.setAlpha(1f);
            logo.animate().scaleX(.90f).scaleY(.90f).setDuration(80).withEndAction(() ->
                    logo.animate().scaleX(1f).scaleY(1f).setDuration(260).start()).start();
            FrameLayout parent = (FrameLayout)hero.getParent();
            View flash = new View(SplashActivity.this);
            flash.setBackgroundColor(Color.WHITE);
            FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(-1,-1);
            parent.getOverlay().add(flash);
            flash.animate().alpha(0f).setDuration(240).withEndAction(() -> parent.getOverlay().remove(flash)).start();
            wink.animate().alpha(0f).setStartDelay(110).setDuration(180).start();
        },1850);
    }

    private TextView text(String s,float size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);return t;
    }
}
