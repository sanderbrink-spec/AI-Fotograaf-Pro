package nl.aifotograaf.pro;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ArrayList<Uri> selected = new ArrayList<>();
    private ImageView beforeView, afterView;
    private TextView status, counter;
    private ProgressBar progress;
    private Button processButton, pickButton;
    private OrtEnvironment ortEnv;
    private OrtSession ortSession;
    private final ActivityResultLauncher<Intent> picker = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
            Intent d = result.getData(); selected.clear();
            if (d.getClipData() != null) {
                int n = Math.min(100, d.getClipData().getItemCount());
                for (int i=0;i<n;i++) selected.add(d.getClipData().getItemAt(i).getUri());
            } else if (d.getData() != null) selected.add(d.getData());
            counter.setText(selected.size()+" foto"+(selected.size()==1?"":"'s")+" geselecteerd");
            processButton.setEnabled(!selected.isEmpty());
            status.setText("Klaar voor echte lokale AI-verwerking");
        });

    @Override protected void onCreate(Bundle b) { super.onCreate(b); buildUi(); initOrt(); }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,30,28,22); root.setBackgroundColor(Color.rgb(9,10,13));
        TextView title = text("AI FOTOGRAAF PRO", 27, Color.WHITE); root.addView(title);
        TextView sub = text("ECHTE LOKALE AI • PHOTOS BY LOES", 12, Color.rgb(167,171,181)); root.addView(sub, lp(-1,42));
        counter=text("Nog geen foto's geselecteerd",14,Color.rgb(167,171,181)); root.addView(counter,lp(-1,48));
        pickButton=new Button(this); pickButton.setText("FOTO'S KIEZEN • MAX. 100"); root.addView(pickButton,lp(-1,56)); pickButton.setOnClickListener(v->openPicker());
        processButton=new Button(this); processButton.setText("AI PERFECT • ECHTE AI"); processButton.setEnabled(false); root.addView(processButton,lp(-1,60)); processButton.setOnClickListener(v->processAll());
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setMax(100); progress.setProgress(0); root.addView(progress,lp(-1,12));
        status=text("Model wordt lokaal voorbereid...",13,Color.rgb(167,171,181)); root.addView(status,lp(-1,42));
        LinearLayout pair=new LinearLayout(this); pair.setOrientation(LinearLayout.HORIZONTAL); pair.setGravity(Gravity.CENTER); 
        beforeView=new ImageView(this); afterView=new ImageView(this); beforeView.setScaleType(ImageView.ScaleType.CENTER_CROP); afterView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        pair.addView(beforeView,weightLp()); pair.addView(afterView,weightLp()); root.addView(pair,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams weightLp(){return new LinearLayout.LayoutParams(0,-1,1);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;}

    private void openPicker(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true); i.addCategory(Intent.CATEGORY_OPENABLE); picker.launch(i); }

    private static final String MODEL_URL = "https://huggingface.co/skillsafe-ai/realesrgan-x4plus/resolve/main/model.onnx?download=true";
    private static final String MODEL_SHA256 = "4851ec156207d271f5328605d0582eeb851e656227da8aca093ced9e60789291";
    private static final long MODEL_MIN_SIZE = 60000000L;

    private void initOrt(){
        executor.execute(() -> {
            try {
                ortEnv = OrtEnvironment.getEnvironment();
                File model = new File(getFilesDir(), "RealESRGAN_x4plus.onnx");
                if (!isValidModel(model)) {
                    runOnUiThread(() -> status.setText("AI-model wordt eenmalig gedownload..."));
                    downloadModel(model);
                }
                OrtSession.SessionOptions opts = new OrtSession.SessionOptions();
                opts.setIntraOpNumThreads(Math.max(2, Runtime.getRuntime().availableProcessors()/2));
                ortSession = ortEnv.createSession(model.getAbsolutePath(), opts);
                runOnUiThread(() -> status.setText("Echte AI-engine actief • volledig lokaal"));
            } catch(Exception e){
                runOnUiThread(() -> status.setText("AI-model laden mislukt: " + e.getMessage()));
            }
        });
    }

    private boolean isValidModel(File model) throws Exception {
        if (!model.exists() || model.length() < MODEL_MIN_SIZE) return false;
        return MODEL_SHA256.equalsIgnoreCase(sha256(model));
    }

    private void downloadModel(File out) throws Exception {
        File tmp = new File(getFilesDir(), "RealESRGAN_x4plus.onnx.part");
        if (tmp.exists()) tmp.delete();
        HttpURLConnection c = (HttpURLConnection) new URL(MODEL_URL).openConnection();
        c.setConnectTimeout(30000);
        c.setReadTimeout(120000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "AI-Fotograaf-PRO/1.0");
        c.connect();
        if (c.getResponseCode() != HttpURLConnection.HTTP_OK) throw new Exception("Model-download HTTP " + c.getResponseCode());
        long total = c.getContentLengthLong();
        try (InputStream in = new BufferedInputStream(c.getInputStream()); OutputStream os = new BufferedOutputStream(new FileOutputStream(tmp))) {
            byte[] buf = new byte[1024 * 1024];
            long done = 0; int n;
            while ((n = in.read(buf)) != -1) {
                os.write(buf, 0, n); done += n;
                final int pct = total > 0 ? (int)Math.min(100, done * 100 / total) : 0;
                runOnUiThread(() -> status.setText("AI-model downloaden... " + pct + "%"));
            }
        } finally { c.disconnect(); }
        if (tmp.length() < MODEL_MIN_SIZE) { tmp.delete(); throw new Exception("Gedownload model is te klein"); }
        if (!MODEL_SHA256.equalsIgnoreCase(sha256(tmp))) { tmp.delete(); throw new Exception("SHA-256 controle van AI-model mislukt"); }
        if (out.exists()) out.delete();
        if (!tmp.renameTo(out)) throw new Exception("AI-model kon niet worden opgeslagen");
    }

    private String sha256(File file) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new BufferedInputStream(new java.io.FileInputStream(file))) {
            byte[] buf = new byte[1024 * 1024]; int n;
            while ((n = in.read(buf)) != -1) md.update(buf, 0, n);
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private void processAll(){ if(ortSession==null){Toast.makeText(this,"AI-engine wordt nog geladen",Toast.LENGTH_SHORT).show();return;} processButton.setEnabled(false); pickButton.setEnabled(false); progress.setProgress(0); executor.execute(()->{int done=0; for(Uri u:selected){ try { Bitmap src=decodeScaled(u,768); Bitmap ai=runAi(src); ai=finishEnhancement(ai); saveToGallery(ai); final Bitmap showSrc=src; final Bitmap showAi=ai; int d=++done; runOnUiThread(()->{beforeView.setImageBitmap(showSrc);afterView.setImageBitmap(showAi);progress.setProgress(d*100/selected.size());status.setText("AI verwerkt: "+d+" / "+selected.size());}); } catch(Exception e){ runOnUiThread(()->Toast.makeText(this,"Fout: "+e.getMessage(),Toast.LENGTH_LONG).show()); } } runOnUiThread(()->{processButton.setEnabled(true);pickButton.setEnabled(true);status.setText("Klaar • AI-resultaten opgeslagen in Foto's / AI Fotograaf PRO");}); }); }

    private Bitmap decodeScaled(Uri uri,int max) throws Exception { BitmapFactory.Options o=new BitmapFactory.Options(); o.inJustDecodeBounds=true; InputStream a=getContentResolver().openInputStream(uri); BitmapFactory.decodeStream(a,null,o); a.close(); int w=o.outWidth,h=o.outHeight; float sc=Math.min(1f,max/(float)Math.max(w,h)); int nw=Math.max(1,Math.round(w*sc)),nh=Math.max(1,Math.round(h*sc)); InputStream in=getContentResolver().openInputStream(uri); Bitmap b=BitmapFactory.decodeStream(in);in.close(); return Bitmap.createScaledBitmap(b,nw,nh,true); }

    private Bitmap runAi(Bitmap src) throws Exception { int w=src.getWidth(),h=src.getHeight(); float[] input=new float[3*w*h]; int[] px=new int[w*h]; src.getPixels(px,0,w,0,0,w,h); for(int y=0;y<h;y++)for(int x=0;x<w;x++){int p=px[y*w+x];int k=y*w+x;input[k]=Color.red(p)/255f;input[w*h+k]=Color.green(p)/255f;input[2*w*h+k]=Color.blue(p)/255f;} long[] shape={1,3,h,w}; OnnxTensor tensor=OnnxTensor.createTensor(ortEnv,FloatBuffer.wrap(input),shape); String name=ortSession.getInputNames().iterator().next(); OrtSession.Result r=ortSession.run(Collections.singletonMap(name,tensor)); Object value=r.get(0).getValue(); float[][][][] out=(float[][][][])value; int oh=out[0][0].length,ow=out[0][0][0].length; Bitmap dst=Bitmap.createBitmap(ow,oh,Bitmap.Config.ARGB_8888); int[] op=new int[ow*oh]; for(int y=0;y<oh;y++)for(int x=0;x<ow;x++){int rr=clamp(out[0][0][y][x]*255);int gg=clamp(out[0][1][y][x]*255);int bb=clamp(out[0][2][y][x]*255);op[y*ow+x]=Color.rgb(rr,gg,bb);} dst.setPixels(op,0,ow,0,0,ow,oh); r.close();tensor.close(); return dst; }
    private int clamp(float v){return (int)Math.max(0,Math.min(255,v));}

    private Bitmap finishEnhancement(Bitmap src){ Bitmap b=src.copy(Bitmap.Config.ARGB_8888,true); int w=b.getWidth(),h=b.getHeight(); int[] p=new int[w*h]; b.getPixels(p,0,w,0,0,w,h); for(int i=0;i<p.length;i++){int r=Color.red(p[i]),g=Color.green(p[i]),bl=Color.blue(p[i]); float lum=(r+g+bl)/3f; float contrast=1.045f; r=clamp((r-lum)*contrast+lum+2);g=clamp((g-lum)*contrast+lum+2);bl=clamp((bl-lum)*contrast+lum+2);p[i]=Color.rgb(r,g,bl);} b.setPixels(p,0,w,0,0,w,h); return b; }

    private void saveToGallery(Bitmap b) throws Exception { ContentResolver cr=getContentResolver(); String name="AI_"+System.currentTimeMillis()+".jpg"; ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/AI Fotograaf PRO");Uri u=cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v); if(u==null)throw new Exception("Opslaan mislukt"); java.io.OutputStream out=cr.openOutputStream(u);b.compress(Bitmap.CompressFormat.JPEG,95,out);out.close(); }
    @Override protected void onDestroy(){executor.shutdownNow();super.onDestroy();}
}
