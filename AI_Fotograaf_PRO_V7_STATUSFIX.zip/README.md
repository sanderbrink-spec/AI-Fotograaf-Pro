AI Fotograaf PRO V7 STATUSFIX

Herstelt de compileerfout uit GitHub build #59:
symbol: variable status

De status TextView is nu correct als class-veld gedeclareerd.
De bestaande Loes-intro, layout en fotofuncties blijven behouden.
