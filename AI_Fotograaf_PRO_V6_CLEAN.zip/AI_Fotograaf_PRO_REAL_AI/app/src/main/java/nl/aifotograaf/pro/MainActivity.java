package nl.aifotograaf.pro;

import ai.onnxruntime.OnnxTensor;
import ai.onnxruntime.OrtEnvironment;
import ai.onnxruntime.OrtSession;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.exifinterface.media.ExifInterface;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.FloatBuffer;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static final int BG = Color.rgb(8, 10, 13);
    private static final int CARD = Color.rgb(18, 21, 27);
    private static final int CARD2 = Color.rgb(24, 28, 35);
    private static final int TEXT = Color.WHITE;
    private static final int MUTED = Color.rgb(157, 164, 175);
    private static final int ACCENT = Color.rgb(232, 198, 125);
    private static final int GREEN = Color.rgb(82, 201, 139);

    private static final String MODEL_URL = "https://huggingface.co/skillsafe-ai/realesrgan-x4plus/resolve/main/model.onnx?download=true";
    private static final String MODEL_SHA256 = "4851ec156207d271f5328605d0582eeb851e656227da8aca093ced9e60789291";
    private static final long MODEL_MIN_SIZE = 60000000L;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ArrayList<Uri> selected = new ArrayList<>();
    private ActivityResultLauncher<Intent> picker;

    private TextView counter, status, modelBadge, resultTitle;
    private ProgressBar progress;
    private Button selectButton, aiButton, saveButton;
    private ImageView beforeView, afterView;
    private LinearLayout resultsList;
    private String mode = "AUTOMATISCH";
    private OrtEnvironment ortEnv;
    private OrtSession ortSession;
    private Bitmap lastResult;
    private Bitmap lastSource;
    private boolean processing = false;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        picker = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
            Intent data = result.getData();
            selected.clear();
            if (data.getClipData() != null) {
                int n = Math.min(100, data.getClipData().getItemCount());
                for (int i = 0; i < n; i++) selected.add(data.getClipData().getItemAt(i).getUri());
            } else if (data.getData() != null) selected.add(data.getData());
            counter.setText(selected.size() + (selected.size() == 1 ? " foto geselecteerd" : " foto's geselecteerd"));
            aiButton.setEnabled(!selected.isEmpty());
            status.setText(ortSession == null ? "Foto's klaar • AI-engine wordt voorbereid" : "Klaar voor AI PERFECT");
            if (!selected.isEmpty()) showPreview(selected.get(0));
        });
        buildUi();
        initOrt();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -1));

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = tv("AI FOTOGRAAF PRO", 27, TEXT, true);
        title.setSingleLine(true);
        header.addView(title, weightLp(0, dp(48), 1));
        TextView version = tv("PRO", 11, BG, true);
        version.setGravity(Gravity.CENTER);
        version.setBackground(round(ACCENT, 18));
        header.addView(version, new LinearLayout.LayoutParams(dp(52), dp(34)));
        root.addView(header, lpMargin(-1, dp(48), 0, 0, 0, 6));

        TextView brand = tv("PHOTOS BY LOES  •  ECHTE LOKALE AI", 12, MUTED, true);
        root.addView(brand, lpMargin(-1, dp(24), 0, 0, 0, 8));

        // Hero card. Height is WRAP_CONTENT so text can never overlap on smaller screens.
        LinearLayout hero = card();
        TextView heroTitle = tv("Maak van elke foto een PRO-foto", 18, TEXT, true);
        heroTitle.setPadding(0, 0, 0, dp(4));
        hero.addView(heroTitle, wrap(-1));
        TextView heroSub = tv("AI-detailherstel, scherpte, licht en kleur. Verwerking gebeurt op het toestel.", 13, MUTED, false);
        heroSub.setLineSpacing(0, 1.05f);
        hero.addView(heroSub, wrap(-1));
        modelBadge = tv("●  AI-ENGINE WORDT GESTART...", 11, MUTED, true);
        modelBadge.setPadding(0, dp(8), 0, 0);
        hero.addView(modelBadge, wrap(-1));
        root.addView(hero, lpMargin(-1, -2, 0, 0, 0, 12));

        counter = tv("Nog geen foto's geselecteerd", 13, MUTED, false);
        root.addView(counter, lpMargin(-1, dp(28), 0, 0, 0, 8));

        selectButton = bigButton("＋  FOTO'S KIEZEN  •  MAX. 100", CARD2, TEXT);
        selectButton.setClickable(true);
        root.addView(selectButton, lpMargin(-1, dp(54), 0, 0, 0, 14));
        selectButton.setOnClickListener(v -> openPicker());

        TextView profileLabel = tv("BEWERKPROFIEL", 11, MUTED, true);
        root.addView(profileLabel, lpMargin(-1, dp(22), 0, 0, 0, 7));

        HorizontalScrollView modeScroll = new HorizontalScrollView(this);
        modeScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        String[] modeNames = {"AUTOMATISCH", "PORTRET", "LANDSCHAP", "LOW LIGHT"};
        for (String m : modeNames) {
            Button b = smallButton(m, m.equals(mode));
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(dp(126), dp(42));
            mp.setMargins(0, 0, dp(8), 0);
            modes.addView(b, mp);
            b.setOnClickListener(v -> { mode = ((Button) v).getText().toString(); refreshModes(modes); });
        }
        modeScroll.addView(modes, new HorizontalScrollView.LayoutParams(-2, dp(42)));
        root.addView(modeScroll, lpMargin(-1, dp(42), 0, 0, 0, 14));

        // Before / after preview
        LinearLayout previewCard = card();
        previewCard.addView(tv("VOOR / NA", 11, MUTED, true), wrap(-1));
        LinearLayout compare = new LinearLayout(this);
        compare.setOrientation(LinearLayout.HORIZONTAL);
        compare.setGravity(Gravity.TOP);
        compare.setPadding(0, dp(8), 0, 0);
        LinearLayout beforePane = previewPane("ORIGINEEL");
        LinearLayout afterPane = previewPane("AI PERFECT");
        compare.addView(beforePane, weightLp(0, dp(194), 1));
        compare.addView(space(8), new LinearLayout.LayoutParams(dp(8), dp(1)));
        compare.addView(afterPane, weightLp(0, dp(194), 1));
        previewCard.addView(compare, wrap(-1));
        root.addView(previewCard, lpMargin(-1, -2, 0, 0, 0, 12));

        aiButton = bigButton("✦  AI PERFECT  •  VERBETER FOTO'S", ACCENT, BG);
        aiButton.setClickable(true);
        aiButton.setEnabled(false);
        root.addView(aiButton, lpMargin(-1, dp(58), 0, 0, 0, 8));
        aiButton.setOnClickListener(v -> processAll());

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        root.addView(progress, lpMargin(-1, dp(8), 0, 0, 0, 4));
        status = tv("AI-engine voorbereiden...", 12, MUTED, false);
        root.addView(status, lpMargin(-1, dp(30), 0, 0, 0, 12));

        // Feature card
        LinearLayout tools = card();
        tools.addView(tv("PRO-FUNCTIES", 11, MUTED, true), wrap(-1));
        String[] features = {"AI-detailherstel", "Slimme belichting", "Kleur & witbalans", "Ruisreductie", "Portretvriendelijke verbetering", "4× super-resolution"};
        for (String f : features) {
            TextView row = tv("✓  " + f, 13, TEXT, false);
            row.setPadding(0, dp(3), 0, dp(3));
            tools.addView(row, wrap(-1));
        }
        root.addView(tools, lpMargin(-1, -2, 0, 0, 0, 12));

        // Results card
        LinearLayout resultCard = card();
        resultTitle = tv("RESULTATEN", 11, MUTED, true);
        resultCard.addView(resultTitle, wrap(-1));
        resultsList = new LinearLayout(this);
        resultsList.setOrientation(LinearLayout.VERTICAL);
        resultCard.addView(resultsList, wrap(-1));
        saveButton = bigButton("OPSLAAN / OPENEN IN FOTO'S", CARD2, TEXT);
        saveButton.setClickable(true);
        saveButton.setEnabled(false);
        resultCard.addView(saveButton, lpMargin(-1, dp(50), 0, 0, 0, 0));
        saveButton.setOnClickListener(v -> openGalleryFolder());
        root.addView(resultCard, lpMargin(-1, -2, 0, 0, 0, 12));

        TextView privacy = tv("Privacy: foto's verlaten je telefoon niet. Alleen het AI-model wordt eenmalig gedownload.", 11, MUTED, false);
        privacy.setLineSpacing(0, 1.05f);
        root.addView(privacy, wrap(-1));

        setContentView(scroll);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            scroll.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars());
                root.setPadding(dp(18), bars.top + dp(10), dp(18), bars.bottom + dp(18));
                return insets;
            });
            scroll.requestApplyInsets();
        }
    }

    private void refreshModes(LinearLayout modes) {
        for (int i = 0; i < modes.getChildCount(); i++) {
            Button b = (Button)modes.getChildAt(i);
            boolean active = b.getText().toString().equals(mode);
            b.setBackground(round(active ? ACCENT : CARD2, 22));
            b.setTextColor(active ? BG : TEXT);
        }
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(13), dp(14), dp(13));
        l.setBackground(round(CARD, 18));
        return l;
    }

    private LinearLayout previewPane(String label) {
        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setPadding(0, 0, 0, 0);
        TextView tag = tv(label, 10, MUTED, true);
        tag.setPadding(dp(2), 0, 0, dp(5));
        pane.addView(tag, wrap(-1));
        ImageView image = imageBox(label);
        if (label.startsWith("ORIGINEEL")) beforeView = image; else afterView = image;
        pane.addView(image, new LinearLayout.LayoutParams(-1, dp(164)));
        return pane;
    }

    private ImageView imageBox(String label) {
        ImageView v = new ImageView(this);
        v.setScaleType(ImageView.ScaleType.CENTER_CROP);
        v.setBackground(round(CARD2, 14));
        v.setContentDescription(label);
        return v;
    }

    private Button bigButton(String s, int bg, int fg) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(fg);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(bg, 16));
        b.setPadding(dp(10), 0, dp(10), 0);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setClickable(true);
        b.setFocusable(true);
        return b;
    }

    private Button smallButton(String s, boolean active) {
        Button b = bigButton(s, active ? ACCENT : CARD2, active ? BG : TEXT);
        b.setTextSize(11);
        return b;
    }

    private TextView tv(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private View space(int w) { return new View(this); }

    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }

    private LinearLayout.LayoutParams wrap(int w) { return new LinearLayout.LayoutParams(w, -2); }

    private LinearLayout.LayoutParams weightLp(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    private LinearLayout.LayoutParams lpMargin(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private android.graphics.drawable.GradientDrawable round(int color, float r) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp((int) r));
        return g;
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    private void openPicker(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);picker.launch(i); }

    private void initOrt(){
        executor.execute(() -> {
            try {
                ortEnv = OrtEnvironment.getEnvironment();
                File model = new File(getFilesDir(), "RealESRGAN_x4plus.onnx");
                if (!isValidModel(model)) { ui(() -> { status.setText("AI-model wordt eenmalig gedownload..."); modelBadge.setText("●  AI-MODEL DOWNLOADEN"); }); downloadModel(model); }
                OrtSession.SessionOptions opts = new OrtSession.SessionOptions();
                opts.setIntraOpNumThreads(Math.max(2, Runtime.getRuntime().availableProcessors()/2));
                ortSession = ortEnv.createSession(model.getAbsolutePath(), opts);
                ui(() -> { modelBadge.setText("●  AI-ENGINE ACTIEF  •  OFFLINE"); modelBadge.setTextColor(GREEN); status.setText(selected.isEmpty()?"Kies foto's om te beginnen":"Klaar voor AI PERFECT"); });
            } catch(Exception e) { ui(() -> { modelBadge.setText("●  AI-ENGINE FOUT"); modelBadge.setTextColor(Color.rgb(230,90,90)); status.setText("AI-model laden mislukt: " + e.getMessage()); }); }
        });
    }

    private boolean isValidModel(File f) throws Exception { return f.exists() && f.length()>=MODEL_MIN_SIZE && MODEL_SHA256.equalsIgnoreCase(sha256(f)); }
    private void downloadModel(File out) throws Exception {
        File tmp=new File(getFilesDir(),"RealESRGAN_x4plus.onnx.part"); if(tmp.exists())tmp.delete();
        HttpURLConnection c=(HttpURLConnection)new URL(MODEL_URL).openConnection();c.setConnectTimeout(30000);c.setReadTimeout(180000);c.setInstanceFollowRedirects(true);c.setRequestProperty("User-Agent","AI-Fotograaf-PRO/11.0");c.connect();
        if(c.getResponseCode()!=200)throw new Exception("HTTP "+c.getResponseCode()); long total=c.getContentLengthLong();
        try(InputStream in=new BufferedInputStream(c.getInputStream());OutputStream os=new BufferedOutputStream(new FileOutputStream(tmp))){byte[] buf=new byte[1024*1024];long done=0;int n;while((n=in.read(buf))!=-1){os.write(buf,0,n);done+=n;final int p=total>0?(int)Math.min(100,done*100/total):0;ui(()->{status.setText("AI-model downloaden... "+p+"%");progress.setProgress(p);});}}finally{c.disconnect();}
        if(!isValidModel(tmp)) {tmp.delete();throw new Exception("Modelcontrole mislukt");} if(out.exists())out.delete();if(!tmp.renameTo(out))throw new Exception("Model opslaan mislukt");
    }
    private String sha256(File f)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[]b=new byte[1024*1024];int n;while((n=in.read(b))!=-1)md.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte b:md.digest())s.append(String.format(Locale.US,"%02x",b));return s.toString();}

    private void showPreview(Uri uri){ executor.execute(()->{try{Bitmap b=decodeScaled(uri,640);ui(()->beforeView.setImageBitmap(b));}catch(Exception ignored){}}); }

    private void processAll(){
        if(processing)return;
        if(selected.isEmpty()){
            status.setText("Kies eerst minimaal één foto");
            Toast.makeText(this,"Kies eerst een foto",Toast.LENGTH_SHORT).show();
            return;
        }
        if(ortSession==null){
            status.setText("AI-engine wordt nog geladen. Probeer zo opnieuw.");
            Toast.makeText(this,"AI-engine wordt nog geladen",Toast.LENGTH_SHORT).show();
            return;
        }
        processing=true;
        aiButton.setEnabled(false);
        selectButton.setEnabled(false);
        saveButton.setEnabled(false);
        resultsList.removeAllViews();
        progress.setIndeterminate(false);
        progress.setProgress(0);
        status.setText("AI PERFECT gestart • foto 1 van "+selected.size()+" wordt verwerkt...");
        resultTitle.setText("RESULTATEN  •  BEZIG");
        executor.execute(()->{
            int done=0;
            for(Uri uri:selected){
                try{
                    final int current=done+1;
                    ui(()->status.setText("AI PERFECT • foto "+current+" / "+selected.size()+" • AI rekent..."));
                    Bitmap src=decodeScaled(uri,384);
                    Bitmap ai=runAiTiled(src);
                    ai=finishEnhancement(ai);
                    saveToGallery(ai);
                    lastSource=src;lastResult=ai;
                    int d=++done;
                    final Bitmap showSrc=src; final Bitmap showAi=ai;
                    ui(()->{
                        beforeView.setImageBitmap(showSrc);
                        afterView.setImageBitmap(showAi);
                        progress.setProgress(d*100/selected.size());
                        status.setText("AI verwerkt: "+d+" / "+selected.size());
                        resultTitle.setText("RESULTATEN  •  "+d+" KLAAR");
                    });
                    final int number=d; ui(()->addResultRow(number));
                }catch(Exception e){
                    final String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
                    ui(()->{status.setText("Verwerking mislukt: "+msg);Toast.makeText(this,"AI-fout: "+msg,Toast.LENGTH_LONG).show();});
                }
            }
            final int completed=done;
            ui(()->{
                processing=false;
                aiButton.setEnabled(true);
                selectButton.setEnabled(true);
                saveButton.setEnabled(completed>0);
                status.setText(completed>0?"Klaar • resultaten opgeslagen in Foto's / AI Fotograaf PRO":"Geen foto kon worden verwerkt");
                resultTitle.setText("RESULTATEN  •  "+completed+" KLAAR");
            });
        });
    }

    private void addResultRow(int n){TextView r=tv("✓  Foto "+n+"  •  AI PERFECT  •  opgeslagen",12,GREEN,false);resultsList.addView(r,lp(-1,30));}

    private Bitmap decodeScaled(Uri uri,int max)throws Exception{
        BitmapFactory.Options o=new BitmapFactory.Options();
        o.inJustDecodeBounds=true;
        try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,o);}
        int w=o.outWidth,h=o.outHeight;
        float sc=Math.min(1f,max/(float)Math.max(w,h));
        int nw=Math.max(1,Math.round(w*sc)),nh=Math.max(1,Math.round(h*sc));
        BitmapFactory.Options p=new BitmapFactory.Options();
        p.inPreferredConfig=Bitmap.Config.ARGB_8888;
        Bitmap b;
        try(InputStream in=getContentResolver().openInputStream(uri)){
            b=BitmapFactory.decodeStream(in,null,p);
        }
        if(b==null)throw new Exception("Afbeelding kon niet worden gelezen");
        Bitmap scaled=Bitmap.createScaledBitmap(b,nw,nh,true);
        if(scaled!=b)b.recycle();
        try(InputStream exifIn=getContentResolver().openInputStream(uri)){
            ExifInterface exif=new ExifInterface(exifIn);
            int orientation=exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);
            Matrix matrix=new Matrix();
            if(orientation==ExifInterface.ORIENTATION_ROTATE_90) matrix.postRotate(90);
            else if(orientation==ExifInterface.ORIENTATION_ROTATE_180) matrix.postRotate(180);
            else if(orientation==ExifInterface.ORIENTATION_ROTATE_270) matrix.postRotate(270);
            else if(orientation==ExifInterface.ORIENTATION_FLIP_HORIZONTAL) matrix.setScale(-1,1);
            else if(orientation==ExifInterface.ORIENTATION_FLIP_VERTICAL) matrix.setScale(1,-1);
            if(!matrix.isIdentity()){
                Bitmap fixed=Bitmap.createBitmap(scaled,0,0,scaled.getWidth(),scaled.getHeight(),matrix,true);
                if(fixed!=scaled)scaled.recycle();
                scaled=fixed;
            }
        }catch(Exception ignored){}
        return scaled;
    }

    private Bitmap runAiTiled(Bitmap src)throws Exception{
        final int scale=4,tile=192,overlap=16;int w=src.getWidth(),h=src.getHeight();Bitmap out=Bitmap.createBitmap(w*scale,h*scale,Bitmap.Config.ARGB_8888);int[] xs=positions(w,tile,overlap),ys=positions(h,tile,overlap);
        int totalTiles=xs.length*ys.length; int tileDone=0; for(int y0:ys)for(int x0:xs){int x1=Math.min(w,x0+tile),y1=Math.min(h,y0+tile);Bitmap part=Bitmap.createBitmap(src,x0,y0,x1-x0,y1-y0);Bitmap up=infer(part);int left=x0==0?0:overlap,right=x1==w?part.getWidth():part.getWidth()-overlap,top=y0==0?0:overlap,bottom=y1==h?part.getHeight():part.getHeight()-overlap;int cw=right-left,ch=bottom-top;Bitmap core=Bitmap.createBitmap(up,left*scale,top*scale,cw*scale,ch*scale);android.graphics.Canvas canvas=new android.graphics.Canvas(out);canvas.drawBitmap(core,x0*scale+left*scale,y0*scale+top*scale,null);part.recycle();up.recycle();core.recycle(); tileDone++; final int tp=tileDone*100/totalTiles; ui(()->status.setText("AI PERFECT • AI rekent... tegel "+tileDone+"/"+totalTiles));}
        return out;
    }
    private int[] positions(int size,int tile,int overlap){ArrayList<Integer>a=new ArrayList<>();int step=tile-overlap*2;for(int p=0;;p+=step){if(p+tile>=size){a.add(Math.max(0,size-tile));break;}a.add(p);}int[]r=new int[a.size()];for(int i=0;i<r.length;i++)r[i]=a.get(i);return r;}

    private Bitmap infer(Bitmap src)throws Exception{
        int w=src.getWidth(),h=src.getHeight();float[] input=new float[3*w*h];int[] px=new int[w*h];src.getPixels(px,0,w,0,0,w,h);int plane=w*h;for(int i=0;i<plane;i++){int p=px[i];input[i]=Color.red(p)/255f;input[plane+i]=Color.green(p)/255f;input[2*plane+i]=Color.blue(p)/255f;}
        OnnxTensor tensor=OnnxTensor.createTensor(ortEnv,FloatBuffer.wrap(input),new long[]{1,3,h,w});String name=ortSession.getInputNames().iterator().next();OrtSession.Result res=ortSession.run(Collections.singletonMap(name,tensor));Object v=res.get(0).getValue();float[][][][] out=(float[][][][])v;int oh=out[0][0].length,ow=out[0][0][0].length;Bitmap dst=Bitmap.createBitmap(ow,oh,Bitmap.Config.ARGB_8888);int[] op=new int[ow*oh];for(int y=0;y<oh;y++)for(int x=0;x<ow;x++){op[y*ow+x]=Color.rgb(clamp(out[0][0][y][x]*255),clamp(out[0][1][y][x]*255),clamp(out[0][2][y][x]*255));}dst.setPixels(op,0,ow,0,0,ow,oh);res.close();tensor.close();return dst;
    }
    private int clamp(float v){return (int)Math.max(0,Math.min(255,v));}
    private Bitmap finishEnhancement(Bitmap src){Bitmap b=src.copy(Bitmap.Config.ARGB_8888,true);int w=b.getWidth(),h=b.getHeight();int[]p=new int[w*h];b.getPixels(p,0,w,0,0,w,h);for(int i=0;i<p.length;i++){int r=Color.red(p[i]),g=Color.green(p[i]),bl=Color.blue(p[i]);float lum=(r+g+bl)/3f;float contrast=1.035f;float lift=lum<90?3:0;r=clamp((r-lum)*contrast+lum+lift);g=clamp((g-lum)*contrast+lum+lift);bl=clamp((bl-lum)*contrast+lum+lift);p[i]=Color.rgb(r,g,bl);}b.setPixels(p,0,w,0,0,w,h);return b;}

    private void saveToGallery(Bitmap b)throws Exception{ContentResolver cr=getContentResolver();String name="AI_"+System.currentTimeMillis()+".jpg";ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/AI Fotograaf PRO");Uri u=cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(u==null)throw new Exception("Opslaan mislukt");try(OutputStream out=cr.openOutputStream(u)){b.compress(Bitmap.CompressFormat.JPEG,96,out);}}
    private void openGalleryFolder(){Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,"image/*");i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);try{startActivity(i);}catch(Exception e){Toast.makeText(this,"Foto's openen lukt niet",Toast.LENGTH_SHORT).show();}}
    private void ui(Runnable r){runOnUiThread(r);}
    @Override protected void onDestroy(){
        executor.shutdownNow();
        if(ortSession!=null){
            try{ortSession.close();}catch(Exception ignored){}
            ortSession=null;
        }
        super.onDestroy();
    }
}
