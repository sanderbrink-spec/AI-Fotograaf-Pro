# AI Fotograaf PRO V6 CLEAN

Android-project voor de GitHub Actions workflow `build-v6-clean.yml`.

De app bevat:
- zwart/gouden Loes Photo Enhancer-interface
- geanimeerd camera-logo
- foto kiezen
- origineel/bewerkt vergelijking
- automatische fotoverbetering
- handmatige belichting, contrast, kleur en scherpte
- lokaal verwerken zonder internet
- foto opslaan in de galerij

De workflow verwacht exact deze bestanden:
`settings.gradle`, `build.gradle`, `app/build.gradle` en
`app/src/main/java/nl/aifotograaf/pro/MainActivity.java`.
