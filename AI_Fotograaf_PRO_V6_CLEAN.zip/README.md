AI Fotograaf PRO V8 COMPLETE

Dit is de volledige professionele Loes-versie, niet de minimale compileerbasis.

Ontwerp:
- lange premium intro met de aangeleverde Loes-camera splash
- Photos by Loes / PURE MOMENTS branding
- zwart, goud, crème, bokeh/camera-esthetiek
- AI Fotograaf PRO / AI by Loes
- professionele afgeronde kaarten en knoppen

Functies:
- Selecteer meerdere foto's, maximaal 100
- Camera openen
- AI PERFECT
- Voor/Na vergelijking
- Resultatenscherm met thumbnails
- Presets: AI PERFECT, Natuurlijk, Vibrant, Portret
- Belichting, contrast, kleuren, scherpte en ruisonderdrukking
- Gezichtsoptimalisatie-instelling
- Lokale verwerking
- Originele resolutie behouden tijdens laden/verwerking
- Opslaan en delen
- Instellingen
- Verwerkingsscherm met voortgangsstappen
