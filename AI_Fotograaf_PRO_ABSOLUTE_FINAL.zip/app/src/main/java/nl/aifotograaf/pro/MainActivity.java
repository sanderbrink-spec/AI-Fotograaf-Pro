package nl.aifotograaf.pro;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.provider.MediaStore;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.ExifInterface;
import android.net.Uri;
import android.view.*;
import android.view.animation.*;
import android.view.WindowInsets;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int PICK=101, CAM=102;
    LinearLayout root, content, bottom; ScrollView scroll; ImageView before, after;
    Bitmap original, working; float exposure=0, contrast=0, saturation=0, sharp=0, noise=0;
    TextView status; ArrayList<SeekBar> bars=new ArrayList<>();
    int gold=Color.rgb(217,169,87), white=Color.rgb(247,242,232), panel=Color.rgb(23,21,21);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(0);
        showIntro();
    }
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(c);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(8),dp(4),dp(8),dp(4));return t;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;}

    void showIntro(){
      FrameLayout f=new FrameLayout(this); f.setBackgroundColor(Color.BLACK);
      ImageView hero=new ImageView(this); hero.setImageResource(nl.aifotograaf.pro.R.drawable.loes_splash); hero.setScaleType(ImageView.ScaleType.CENTER_CROP); f.addView(hero,new FrameLayout.LayoutParams(-1,-1));
      View flash=new View(this); flash.setBackgroundColor(Color.WHITE); flash.setAlpha(0); f.addView(flash,new FrameLayout.LayoutParams(-1,-1));
      TextView skip=tv("AI FOTOGRAAF PRO  •  AI by Loes",14,white); skip.setGravity(Gravity.CENTER); FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(-1,dp(45),Gravity.BOTTOM);sp.setMargins(dp(25),0,dp(25),dp(35));f.addView(skip,sp);
      setContentView(f);
      hero.setAlpha(0f); hero.animate().alpha(1f).setDuration(700).start();
      new Handler().postDelayed(()->{flash.setAlpha(.9f);flash.animate().alpha(0).setDuration(420).start();},1200);
      new Handler().postDelayed(this::showHome,3400);
    }

    void showHome(){
      root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(8,8,8));setContentView(root);
      root.setFitsSystemWindows(false);
      root.setOnApplyWindowInsetsListener((v,insets)->{
        int nav=0;
        if(Build.VERSION.SDK_INT>=30) nav=insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
        else nav=insets.getSystemWindowInsetBottom();
        if(bottom!=null) bottom.setPadding(dp(8),dp(7),dp(8),dp(7)+nav);
        return insets;
      });
      LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(dp(12),dp(8),dp(12),dp(8));
      ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.ic_loes_icon); logo.setContentDescription("Loes AI Fotograaf");logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);head.addView(logo,new LinearLayout.LayoutParams(dp(70),dp(55)));
      TextView title=tv("Foto verbeteren",20,white);title.setGravity(Gravity.CENTER);head.addView(title,new LinearLayout.LayoutParams(0,dp(55),1));
      TextView more=tv("⋮",30,white);more.setGravity(Gravity.CENTER);head.addView(more,new LinearLayout.LayoutParams(dp(45),dp(55)));root.addView(head);
      scroll=new ScrollView(this);scroll.setFillViewport(true);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(12),dp(4),dp(12),dp(30));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
      buildEditor(); buildBottom();
    }

    void buildEditor(){
      TextView hint=tv("Maak een nieuw project of kies foto's",14,Color.LTGRAY);hint.setPadding(dp(4),dp(8),dp(4),dp(8));content.addView(hint);
      LinearLayout actions=row();
      Button newP=button("＋ Nieuw project",gold,Color.BLACK);newP.setOnClickListener(v->newProject());actions.addView(newP,new LinearLayout.LayoutParams(0,dp(48),1));
      Button pick=button("▣ Foto's kiezen",panel,white);pick.setOnClickListener(v->pickImages());actions.addView(pick,new LinearLayout.LayoutParams(0,dp(48),1));content.addView(actions);
      LinearLayout compare=row();before=new ImageView(this);after=new ImageView(this);styleImage(before);styleImage(after); compare.addView(cardImage(before,"Origineel"),new LinearLayout.LayoutParams(0,dp(250),1));compare.addView(cardImage(after,"Bewerkt"),new LinearLayout.LayoutParams(0,dp(250),1));content.addView(compare);
      LinearLayout presets=row();String[] p={"✦ AI PERFECT","☘ Natuurlijk","☀ Vibrant","◉ Portret"};for(int i=0;i<p.length;i++){Button x=button(p[i],i==0?gold:panel,i==0?Color.BLACK:white);final int n=i;x.setOnClickListener(v->preset(n));presets.addView(x,new LinearLayout.LayoutParams(0,dp(58),1));}content.addView(presets);
      addSlider("☼ Belichting",-100,100,0,0);addSlider("◐ Contrast",-100,100,0,1);addSlider("◉ Kleuren",-100,100,0,2);addSlider("△ Scherpte",0,100,25,3);addSlider("▦ Ruisonderdrukking",0,100,20,4);
      LinearLayout tools=row();String[] ts={"✂ Bijsnijden","↻ Draaien","◉ Filters","⌫ Object verwijderen","▦ Collage"};for(String s:ts){Button x=button(s,panel,white);x.setOnClickListener(v->toolAction(s));tools.addView(x,new LinearLayout.LayoutParams(0,dp(54),1));}content.addView(tools);
      status=tv("Kies een foto om te beginnen.",13,Color.LTGRAY);status.setPadding(dp(6),dp(10),dp(6),dp(10));content.addView(status);
      LinearLayout save=row();Button sv=button("↓ Opslaan",gold,Color.BLACK);sv.setOnClickListener(v->save());Button sh=button("↗ Delen",panel,white);sh.setOnClickListener(v->share());save.addView(sv,new LinearLayout.LayoutParams(0,dp(58),1));save.addView(sh,new LinearLayout.LayoutParams(0,dp(58),1));content.addView(save);
      TextView bottomSpace=tv("",1,Color.TRANSPARENT);content.addView(bottomSpace,new LinearLayout.LayoutParams(1,dp(25)));
    }
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER);return l;}
    Button button(String s,int c,int tc){Button b=new Button(this);b.setText(s);b.setTextColor(tc);b.setTextSize(12);b.setAllCaps(false);b.setBackground(bg(c,22));return b;}
    LinearLayout cardImage(ImageView im,String label){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(2),dp(2),dp(2),dp(2));l.setBackground(bg(panel,22));TextView t=tv(label,12,label.equals("Bewerkt")?gold:white);t.setGravity(Gravity.CENTER);l.addView(t,new LinearLayout.LayoutParams(-1,dp(30)));l.addView(im,new LinearLayout.LayoutParams(-1,0,1));return l;}
    void styleImage(ImageView i){i.setScaleType(ImageView.ScaleType.FIT_CENTER);i.setBackgroundColor(Color.BLACK);}

    void addSlider(String name,int min,int max,int val,int which){
      LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(12),dp(7),dp(12),dp(5));c.setBackground(bg(panel,22));TextView lab=tv(name,14,white);c.addView(lab);SeekBar s=new SeekBar(this);s.setMax(max-min);s.setProgress(val-min);s.setPadding(dp(2),0,dp(2),0);bars.add(s);c.addView(s,new LinearLayout.LayoutParams(-1,dp(38)));s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){float v=p+min; if(which==0)exposure=v; if(which==1)contrast=v;if(which==2)saturation=v;if(which==3)sharp=v;if(which==4)noise=v; applyPreview();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(82));cp.setMargins(0,dp(5),0,0);content.addView(c,cp);
    }

    void buildBottom(){
      bottom=row(); bottom.setBackgroundColor(Color.rgb(12,12,12)); bottom.setElevation(dp(10));
      String[] n={"⌂ Home","＋ Nieuw","▣ Resultaten","⚙ Instellingen"};
      for(int i=0;i<n.length;i++){
        Button b=button(n[i],i==0?gold:panel,i==0?Color.BLACK:white);
        b.setMinHeight(dp(52)); b.setPadding(dp(2),0,dp(2),0);
        final int x=i;
        b.setOnClickListener(v->{
          if(x==0) scroll.smoothScrollTo(0,0);
          else if(x==1) newProject();
          else if(x==2) scrollToResults();
          else Toast.makeText(this,"Instellingen zijn nog niet nodig voor de basisworkflow.",Toast.LENGTH_SHORT).show();
        });
        bottom.addView(b,new LinearLayout.LayoutParams(0,dp(58),1));
      }
      root.addView(bottom,new LinearLayout.LayoutParams(-1,dp(72)));
      root.requestApplyInsets();
    }
    void newProject(){original=null;working=null;before.setImageDrawable(null);after.setImageDrawable(null);int[] defaults={100,100,100,25,20}; for(int i=0;i<bars.size();i++) bars.get(i).setProgress(defaults[i]); exposure=contrast=saturation=0; sharp=25; noise=20;status.setText("Nieuw project gestart. Kies foto's.");scroll.smoothScrollTo(0,0);}
    void pickImages(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK&&c==RESULT_OK&&d!=null){Uri u=d.getData();if(u==null&&d.getClipData()!=null)u=d.getClipData().getItemAt(0).getUri();if(u!=null)loadImage(u);}}
    void loadImage(Uri u){try{InputStream in=getContentResolver().openInputStream(u);BitmapFactory.Options o=new BitmapFactory.Options();o.inPreferredConfig=Bitmap.Config.ARGB_8888;Bitmap b=BitmapFactory.decodeStream(in,null,o);in.close();if(b==null)throw new Exception();b=orient(u,b);original=scale(b,2400);working=original.copy(Bitmap.Config.ARGB_8888,true);before.setImageBitmap(original);after.setImageBitmap(working);status.setText("Foto geladen. AI PERFECT staat klaar.");applyPreview();}catch(Exception e){Toast.makeText(this,"Foto kon niet worden geladen.",Toast.LENGTH_SHORT).show();}}
    Bitmap orient(Uri u,Bitmap b)throws Exception{InputStream in=getContentResolver().openInputStream(u);ExifInterface ex=new ExifInterface(in);int o=ex.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);in.close();Matrix m=new Matrix();if(o==ExifInterface.ORIENTATION_ROTATE_90)m.postRotate(90);else if(o==ExifInterface.ORIENTATION_ROTATE_180)m.postRotate(180);else if(o==ExifInterface.ORIENTATION_ROTATE_270)m.postRotate(270);else return b;return Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,true);}
    Bitmap scale(Bitmap b,int max){float q=Math.min(1f,max/(float)Math.max(b.getWidth(),b.getHeight()));if(q>=1)return b;return Bitmap.createScaledBitmap(b,Math.round(b.getWidth()*q),Math.round(b.getHeight()*q),true);}
    void applyPreview(){
      if(original==null||after==null)return;
      float br=1f+exposure/100f*.55f;
      float co=1f+contrast/100f*.55f;
      float sat=1f+saturation/100f*.40f;
      float lift=exposure>0 ? exposure*.18f : 0;
      ColorMatrix cm=new ColorMatrix(); cm.setSaturation(sat);
      cm.postConcat(new ColorMatrix(new float[]{co,0,0,0,128*(1-co)+lift,0,co,0,0,128*(1-co)+lift,0,0,co,0,128*(1-co)+lift,0,0,0,1,0}));
      cm.postConcat(new ColorMatrix(new float[]{br,0,0,0,0,0,br,0,0,0,0,0,br,0,0,0,0,0,1,0}));
      after.setColorFilter(new ColorMatrixColorFilter(cm)); after.setImageBitmap(original);
      status.setText("AI PERFECT • live preview");
    }
    void preset(int n){if(original==null){Toast.makeText(this,"Kies eerst een foto.",Toast.LENGTH_SHORT).show();return;}if(n==0){exposure=8;contrast=10;saturation=7;sharp=25;noise=20;}if(n==1){exposure=4;contrast=5;saturation=2;sharp=15;noise=15;}if(n==2){exposure=5;contrast=14;saturation=18;sharp=30;noise=10;}if(n==3){exposure=7;contrast=8;saturation=4;sharp=35;noise=25;}syncBars();applyPreview();}
    void syncBars(){int[] vals={(int)exposure+100,(int)contrast+100,(int)saturation+100,(int)sharp,(int)noise};for(int i=0;i<bars.size();i++){int v=vals[i];if(i<3)v=Math.max(0,Math.min(200,v));else v=Math.max(0,Math.min(100,v));bars.get(i).setProgress(v);}}
    void toolAction(String s){
      if(original==null){Toast.makeText(this,"Kies eerst een foto.",Toast.LENGTH_SHORT).show();return;}
      if(s.contains("Draaien")){original=rotate(original,90); working=original.copy(Bitmap.Config.ARGB_8888,true); before.setImageBitmap(original); applyPreview();}
      else if(s.contains("Filters")){preset(2); status.setText("Vibrant filter toegepast.");}
      else if(s.contains("Bijsnijden")){int w=original.getWidth(),h=original.getHeight();int side=Math.min(w,h);int x=(w-side)/2,y=(h-side)/2;original=Bitmap.createBitmap(original,x,y,side,side);working=original.copy(Bitmap.Config.ARGB_8888,true);before.setImageBitmap(original);applyPreview();status.setText("Centrale uitsnede toegepast.");}
      else if(s.contains("Object verwijderen")){Toast.makeText(this,"Selecteer een object in een volgende bewerkingsstap; de originele foto blijft behouden.",Toast.LENGTH_LONG).show();}
      else if(s.contains("Collage")){Toast.makeText(this,"Collage is beschikbaar zodra meerdere foto's aan het project zijn toegevoegd.",Toast.LENGTH_LONG).show();}
    }
    Bitmap rotate(Bitmap b,int d){Matrix m=new Matrix();m.postRotate(d);return Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,true);}
    void scrollToResults(){scroll.smoothScrollTo(0,content.getHeight());}
    Bitmap rendered(){
      if(original==null)return null;
      int w=original.getWidth(), h=original.getHeight();
      Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
      int[] src=new int[w*h], dst=new int[w*h]; original.getPixels(src,0,w,0,0,w,h);
      float exposureGain=(float)Math.pow(2.0,exposure/100.0*.55);
      float contrastGain=1f+contrast/100f*.45f;
      float satGain=1f+saturation/100f*.30f;
      float noiseMix=Math.max(0f,Math.min(0.55f,noise/100f*.45f));
      for(int y=0;y<h;y++) for(int x=0;x<w;x++){
        int i=y*w+x, c=src[i]; float r=(c>>16)&255, g=(c>>8)&255, b=c&255;
        r*=exposureGain; g*=exposureGain; b*=exposureGain;
        // Shadow recovery: lift darker areas more than highlights.
        float lum=(r+g+b)/765f; float lift=(1f-lum)*(exposure>0?exposure/100f*.22f:0f);
        r+=255f*lift; g+=255f*lift; b+=255f*lift;
        r=(r-128f)*contrastGain+128f; g=(g-128f)*contrastGain+128f; b=(b-128f)*contrastGain+128f;
        float gray=(r+g+b)/3f; r=gray+(r-gray)*satGain; g=gray+(g-gray)*satGain; b=gray+(b-gray)*satGain;
        // Gentle neutralisation of strong tungsten cast without removing the atmosphere.
        if(noise>0){float avg=(r+g+b)/3f; r=r+(avg-r)*noiseMix*.10f; g=g+(avg-g)*noiseMix*.04f; b=b+(avg-b)*noiseMix*.02f;}
        dst[i]=Color.argb(255,clamp(r),clamp(g),clamp(b));
      }
      out.setPixels(dst,0,w,0,0,w,h);
      if(sharp>0){
        int[] base=dst.clone(); float amount=Math.min(.65f,sharp/100f*.65f);
        for(int y=1;y<h-1;y++) for(int x=1;x<w-1;x++){
          int i=y*w+x, c=base[i]; int up=base[i-w],dn=base[i+w],lf=base[i-1],rt=base[i+1];
          int rr=clamp(((c>>16)&255)+(int)(amount*(((c>>16)&255)-(((up>>16)&255)+(dn>>16&255)+(lf>>16&255)+(rt>>16&255))/4f)));
          int gg=clamp(((c>>8)&255)+(int)(amount*(((c>>8)&255)-(((up>>8)&255)+(dn>>8&255)+(lf>>8&255)+(rt>>8&255))/4f)));
          int bb=clamp((c&255)+(int)(amount*((c&255)-((up&255)+(dn&255)+(lf&255)+(rt&255))/4f)));
          dst[i]=Color.rgb(rr,gg,bb);
        }
        out.setPixels(dst,0,w,0,0,w,h);
      }
      return out;
    }
    int clamp(float v){return (int)Math.max(0,Math.min(255,v));}
    void save(){if(original==null){Toast.makeText(this,"Kies eerst een foto.",Toast.LENGTH_SHORT).show();return;}new Thread(()->{Bitmap b=rendered();ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,"Loes_AI_Foto_"+System.currentTimeMillis()+".jpg");v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/AI Fotograaf PRO");Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);try{OutputStream o=getContentResolver().openOutputStream(u);b.compress(Bitmap.CompressFormat.JPEG,96,o);o.close();runOnUiThread(()->Toast.makeText(this,"Foto opgeslagen in AI Fotograaf PRO.",Toast.LENGTH_SHORT).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Opslaan mislukt.",Toast.LENGTH_SHORT).show());}}).start();}
    void share(){if(original==null){Toast.makeText(this,"Kies eerst een foto.",Toast.LENGTH_SHORT).show();return;}Toast.makeText(this,"Sla de bewerkte foto eerst op om te delen.",Toast.LENGTH_SHORT).show();}
}
