package nl.aifotograaf.pro;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final int PICK = 101, CAMERA = 102, PERM_CAMERA = 103;
    private final int BG=Color.rgb(5,5,5), PANEL=Color.rgb(20,18,19), PANEL2=Color.rgb(29,26,27);
    private final int GOLD=Color.rgb(220,177,99), GOLD2=Color.rgb(245,215,160), CREAM=Color.rgb(248,241,230), MUTED=Color.rgb(171,162,155);

    private LinearLayout root, content, footer;
    private ImageView beforeView, afterView;
    private TextView status;
    private SeekBar exposure, contrast, saturation, sharpness, noise;
    private final ArrayList<Bitmap> originals=new ArrayList<>();
    private final ArrayList<Bitmap> results=new ArrayList<>();
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Handler handler=new Handler();
    private Runnable pendingPreview;
    private int selected=0, filter=0;
    private boolean retouch=false;

    private int dp(float n){ return (int)(n*getResources().getDisplayMetrics().density+.5f); }

    private GradientDrawable panel(int color,float r,int stroke){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(r));
        if(stroke!=0) g.setStroke(dp(1),stroke); return g;
    }
    private TextView txt(String s,float size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private Button btn(String s,boolean primary){
        Button b=new Button(this); b.setText(s); b.setTextSize(12); b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setTextColor(primary?Color.rgb(28,20,10):CREAM);
        b.setBackground(panel(primary?GOLD:PANEL2,18,primary?GOLD2:Color.rgb(61,55,52)));
        b.setPadding(dp(6),0,dp(6),0); return b;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        showIntro();
    }

    private void showIntro(){
        FrameLayout f=new FrameLayout(this); f.setBackgroundColor(BG); setContentView(f);
        ImageView hero=new ImageView(this); hero.setImageResource(R.drawable.loes_intro);
        hero.setScaleType(ImageView.ScaleType.CENTER_CROP); f.addView(hero,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this); shade.setBackgroundColor(Color.argb(105,0,0,0)); f.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        View flash=new View(this); flash.setBackgroundColor(Color.WHITE); flash.setAlpha(0f); f.addView(flash,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout o=new LinearLayout(this); o.setOrientation(LinearLayout.VERTICAL);
        o.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.BOTTOM); o.setPadding(dp(18),0,dp(18),dp(42));
        TextView by=txt("Photos by",20,CREAM); by.setGravity(Gravity.CENTER);
        TextView loes=txt("Loes",58,GOLD2); loes.setGravity(Gravity.CENTER);
        loes.setTypeface(Typeface.create("cursive",Typeface.NORMAL));
        TextView pure=txt("PURE MOMENTS",11,CREAM); pure.setGravity(Gravity.CENTER); pure.setLetterSpacing(.28f);
        ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); p.setMax(100); p.setProgressTintList(android.content.res.ColorStateList.valueOf(GOLD));
        o.addView(by,new LinearLayout.LayoutParams(-1,dp(30))); o.addView(loes,new LinearLayout.LayoutParams(-1,dp(68)));
        o.addView(pure,new LinearLayout.LayoutParams(-1,dp(26)));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(240),dp(8)); pp.topMargin=dp(12); o.addView(p,pp);
        f.addView(o,new FrameLayout.LayoutParams(-1,-1));
        hero.setScaleX(1.06f); hero.setScaleY(1.06f);
        hero.animate().scaleX(1).scaleY(1).setDuration(1700).start();
        o.setAlpha(0); o.animate().alpha(1).setStartDelay(250).setDuration(1100).start();
        final Handler h=new Handler(); h.postDelayed(new Runnable(){int n=0; public void run(){n+=2;p.setProgress(n);if(n<100)h.postDelayed(this,70);}},350);
        h.postDelayed(()->flash.animate().alpha(.75f).setDuration(70).withEndAction(()->flash.animate().alpha(0).setDuration(260).start()).start(),2150);
        h.postDelayed(this::home,5000);
    }

    private void base(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        root.setPadding(dp(10),dp(6),dp(10),dp(6)); setContentView(root);

        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo=txt("Loes",34,GOLD2); logo.setTypeface(Typeface.create("cursive",0));
        head.addView(logo,new LinearLayout.LayoutParams(0,dp(52),1));
        TextView t=txt(title,16,CREAM); t.setGravity(Gravity.CENTER); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        head.addView(t,new LinearLayout.LayoutParams(0,dp(52),2));
        TextView m=txt("⋮",28,CREAM); m.setGravity(Gravity.CENTER); head.addView(m,new LinearLayout.LayoutParams(0,dp(52),1));
        root.addView(head);

        ScrollView sc=new ScrollView(this); sc.setFillViewport(true); sc.setVerticalScrollBarEnabled(false);
        sc.setFadingEdgeLength(dp(30)); sc.setVerticalFadingEdgeEnabled(true); sc.setOverScrollMode(View.OVER_SCROLL_ALWAYS);
        if(android.os.Build.VERSION.SDK_INT>=31) sc.setEdgeEffectColor(GOLD);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(0,0,0,dp(34));
        sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));

        footer=new LinearLayout(this); footer.setPadding(0,dp(5),0,0); root.addView(footer,new LinearLayout.LayoutParams(-1,dp(62)));
        content.setAlpha(0); content.setTranslationY(dp(8)); content.animate().alpha(1).translationY(0).setDuration(280).start();
    }

    private void footer(String left,String right,View.OnClickListener a,View.OnClickListener b){
        footer.removeAllViews(); Button x=btn(left,false), y=btn(right,false);
        footer.addView(x,new LinearLayout.LayoutParams(0,dp(54),1));
        LinearLayout.LayoutParams yp=new LinearLayout.LayoutParams(0,dp(54),1); yp.leftMargin=dp(7); footer.addView(y,yp);
        x.setOnClickListener(a); y.setOnClickListener(b);
    }

    private void home(){
        base("AI FOTOGRAAF PRO");
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(12),dp(8),dp(12),dp(12)); card.setBackground(panel(PANEL,22,Color.rgb(58,51,47)));
        TextView cam=txt("◉",60,GOLD); cam.setGravity(Gravity.CENTER); card.addView(cam,new LinearLayout.LayoutParams(-1,dp(72)));
        TextView title=txt("AI FOTOGRAAF PRO",21,GOLD2); title.setGravity(Gravity.CENTER); title.setTypeface(Typeface.create("serif",1)); title.setLetterSpacing(.08f);
        card.addView(title,new LinearLayout.LayoutParams(-1,dp(38)));
        TextView sub=txt("AI by Loes  •  MOOIERE FOTO'S. AUTOMATISCH.",11,CREAM); sub.setGravity(Gravity.CENTER); card.addView(sub,new LinearLayout.LayoutParams(-1,dp(30)));

        LinearLayout row=new LinearLayout(this); Button gallery=btn("▣  SELECTEER FOTO'S",true), camera=btn("◎  CAMERA",false);
        row.addView(gallery,new LinearLayout.LayoutParams(0,dp(60),1)); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(60),1); cp.leftMargin=dp(7); row.addView(camera,cp);
        card.addView(row);
        Button perfect=btn("✦  AI PERFECT  •  ALLES AUTOMATISCH",true); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(54)); pp.topMargin=dp(8); card.addView(perfect,pp);
        TextView hint=txt("Scroll rustig voor de modi en extra instellingen",10,MUTED); hint.setGravity(Gravity.CENTER); card.addView(hint,new LinearLayout.LayoutParams(-1,dp(28)));
        content.addView(card);

        LinearLayout modes=new LinearLayout(this); String[] ms={"◉\nPortret","⌁\nLandschap","☾\nNacht","✦\nProduct","♨\nEten"};
        for(String x:ms){TextView q=txt(x,11,CREAM);q.setGravity(Gravity.CENTER);q.setBackground(panel(PANEL2,15,Color.rgb(53,48,46)));LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,dp(62),1);mp.leftMargin=dp(3);modes.addView(q,mp);}
        content.addView(modes);

        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(dp(14),dp(10),dp(14),dp(10)); info.setBackground(panel(PANEL,18,Color.rgb(48,43,41)));
        TextView ih=txt("Wat Loes automatisch doet",15,CREAM); ih.setTypeface(Typeface.DEFAULT,1); info.addView(ih);
        String[] lines={"✓ Belichting, highlights en schaduwen","✓ Natuurlijke witbalans en kleuren","✓ Detail, scherpte en lokale contrasten","✓ Ruisonderdrukking","✓ Subtiele portretoptimalisatie","✓ Meerdere foto's achter elkaar"};
        for(String x:lines){TextView q=txt(x,11,Color.rgb(214,205,197));q.setPadding(0,dp(3),0,dp(3));info.addView(q);}
        content.addView(info);

        gallery.setOnClickListener(v->pick()); perfect.setOnClickListener(v->pick()); camera.setOnClickListener(v->camera());
        footer("⚙ Instellingen","▣ Resultaten",v->settings(),v->resultsScreen());
    }

    private void pick(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK);
    }
    private void camera(){
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.CAMERA},PERM_CAMERA); return;
        }
        Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE); if(i.resolveActivity(getPackageManager())!=null) startActivityForResult(i,CAMERA);
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==PERM_CAMERA && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED)camera();}

    @Override protected void onActivityResult(int r,int result,Intent d){
        super.onActivityResult(r,result,d); if(result!=RESULT_OK||d==null)return;
        try{
            originals.clear();results.clear();
            if(r==CAMERA && d.getExtras()!=null){Bitmap b=(Bitmap)d.getExtras().get("data");if(b!=null)originals.add(b);}
            if(r==PICK){ClipData c=d.getClipData();if(c!=null){for(int i=0;i<Math.min(100,c.getItemCount());i++)load(c.getItemAt(i).getUri());}else if(d.getData()!=null)load(d.getData());}
            if(!originals.isEmpty()){selected=0;editor();}
        }catch(Exception e){Toast.makeText(this,"Foto kon niet worden geladen.",Toast.LENGTH_LONG).show();}
    }

    private void load(Uri u)throws Exception{
        InputStream in=getContentResolver().openInputStream(u); BitmapFactory.Options o=new BitmapFactory.Options(); o.inJustDecodeBounds=true;
        BitmapFactory.decodeStream(in,null,o); if(in!=null)in.close();
        int max=2400, sample=1; while(Math.max(o.outWidth,o.outHeight)/(sample*2)>max)sample*=2;
        o.inSampleSize=sample;o.inJustDecodeBounds=false;
        in=getContentResolver().openInputStream(u); Bitmap b=BitmapFactory.decodeStream(in,null,o);if(in!=null)in.close();
        if(b!=null)originals.add(b);
    }

    private LinearLayout imageBox(String label,ImageView iv,boolean gold){
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setBackground(panel(Color.rgb(7,7,7),16,Color.rgb(55,49,47)));
        TextView tag=txt(label,10,gold?Color.rgb(25,18,9):CREAM);tag.setGravity(Gravity.CENTER);tag.setTypeface(Typeface.DEFAULT,1);tag.setBackground(panel(gold?GOLD:Color.rgb(23,22,22),18,0));
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(dp(76),dp(28));tp.setMargins(dp(8),dp(8),0,dp(4));p.addView(tag,tp);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);p.addView(iv,new LinearLayout.LayoutParams(-1,0,1));return p;
    }

    private void editor(){
        base("Foto verbeteren");
        LinearLayout cmp=new LinearLayout(this);cmp.setOrientation(LinearLayout.HORIZONTAL);
        beforeView=new ImageView(this);afterView=new ImageView(this);
        beforeView.setImageBitmap(originals.get(selected));afterView.setImageBitmap(enhance(preview(originals.get(selected)),false));
        cmp.addView(imageBox("Origineel",beforeView,false),new LinearLayout.LayoutParams(0,dp(310),1));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(310),1);ap.leftMargin=dp(7);cmp.addView(imageBox("Bewerkt",afterView,true),ap);content.addView(cmp);

        if(retouch){afterView.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){retouchCircle(e.getX(),e.getY());return true;}return true;});}

        LinearLayout presets=new LinearLayout(this);String[] ps={"✦ AI PERFECT","☘ Natuurlijk","☀ Vibrant","◉ Portret"};
        for(int i=0;i<ps.length;i++){final int fi=i;Button b=btn(ps[i],i==0);presets.addView(b,new LinearLayout.LayoutParams(0,dp(52),1));b.setOnClickListener(v->{if(fi==0)processAll();else{filter=fi;renderAsync();}});}
        content.addView(presets);

        slider("☼  Belichting",50,"e");slider("◐  Contrast",50,"c");slider("◉  Kleuren",50,"s");slider("△  Scherpte",35,"h");slider("▦  Ruisonderdrukking",25,"n");

        LinearLayout tools=new LinearLayout(this);String[] ts={"✂ Bijsnijden","↻ Draaien","◉ Filters","⌫ Retouch","▦ Collage"};
        for(int i=0;i<ts.length;i++){final int ti=i;TextView q=txt(ts[i],10,MUTED);q.setGravity(Gravity.CENTER);q.setBackground(panel(PANEL2,13,Color.rgb(47,42,40)));LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(54),1);tp.leftMargin=dp(3);tools.addView(q,tp);q.setOnClickListener(v->tool(ti));}
        content.addView(tools); content.setPadding(0,0,0,dp(40));
        footer("⇩ Opslaan","↗ Delen",v->save(),v->share());
    }

    private void slider(String name,int value,String type){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(12),dp(3),dp(12),dp(1));row.setBackground(panel(PANEL2,13,Color.rgb(47,42,40)));
        row.addView(txt(name,11,CREAM));SeekBar s=new SeekBar(this);s.setMax(100);s.setProgress(value);row.addView(s,new LinearLayout.LayoutParams(-1,dp(34)));
        if(type.equals("e"))exposure=s;if(type.equals("c"))contrast=s;if(type.equals("s"))saturation=s;if(type.equals("h"))sharpness=s;if(type.equals("n"))noise=s;
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onStartTrackingTouch(SeekBar b){}
            public void onProgressChanged(SeekBar b,int p,boolean f){if(!f||originals.isEmpty())return;if(pendingPreview!=null)handler.removeCallbacks(pendingPreview);pendingPreview=()->renderPreview();handler.postDelayed(pendingPreview,55);}
            public void onStopTrackingTouch(SeekBar b){renderAsync();}
        });
        content.addView(row,new LinearLayout.LayoutParams(-1,dp(64)));
    }

    private Bitmap preview(Bitmap b){
        int max=850,w=b.getWidth(),h=b.getHeight();if(Math.max(w,h)<=max)return b;
        float f=max/(float)Math.max(w,h);return Bitmap.createScaledBitmap(b,Math.max(1,(int)(w*f)),Math.max(1,(int)(h*f)),true);
    }
    private void renderPreview(){if(afterView!=null&&!originals.isEmpty())afterView.setImageBitmap(enhance(preview(originals.get(selected)),false));}
    private void renderAsync(){if(originals.isEmpty()||afterView==null)return;final Bitmap src=originals.get(selected);worker.execute(()->{Bitmap b=enhance(preview(src),false);runOnUiThread(()->{if(afterView!=null)afterView.setImageBitmap(b);});});}

    private Bitmap enhance(Bitmap src,boolean auto){
        int w=src.getWidth(),h=src.getHeight();Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);int[] px=new int[w*h];src.getPixels(px,0,w,0,0,w,h);
        float e=1.06f,c=1.10f,s=1.05f;
        if(!auto&&exposure!=null){e=.78f+exposure.getProgress()/230f;c=.82f+contrast.getProgress()/240f;s=.82f+saturation.getProgress()/220f;}
        if(filter==1){c*=1.03f;s*=.98f;} if(filter==2){c*=1.06f;s*=1.15f;} if(filter==3){c*=1.04f;s*=.96f;}
        for(int i=0;i<px.length;i++){int q=px[i];float r=Color.red(q)*e,g=Color.green(q)*e,b=Color.blue(q)*e;r=(r-128)*c+128;g=(g-128)*c+128;b=(b-128)*c+128;float gr=.299f*r+.587f*g+.114f*b;r=gr+(r-gr)*s;g=gr+(g-gr)*s;b=gr+(b-gr)*s;px[i]=Color.rgb(clamp(r),clamp(g),clamp(b));}
        out.setPixels(px,0,w,0,0,w,h);return out;
    }
    private int clamp(float v){return (int)Math.max(0,Math.min(255,v));}

    private void processAll(){
        if(originals.isEmpty())return;showProcessing();
        worker.execute(()->{results.clear();for(int i=0;i<originals.size();i++){Bitmap r=enhance(originals.get(i),true);results.add(r);final int n=i+1;runOnUiThread(()->{if(status!=null)status.setText("AI PERFECT  •  "+n+" / "+originals.size());});}runOnUiThread(this::resultsScreen);});
    }
    private void showProcessing(){
        base("AI PERFECT");
        TextView h=txt("Loes is je foto's aan het verbeteren",20,GOLD2);h.setGravity(Gravity.CENTER);content.addView(h,new LinearLayout.LayoutParams(-1,dp(60)));
        ImageView im=new ImageView(this);im.setImageResource(R.drawable.loes_mockup);im.setScaleType(ImageView.ScaleType.CENTER_CROP);content.addView(im,new LinearLayout.LayoutParams(-1,dp(230)));
        status=txt("AI analyse gestart",14,CREAM);status.setGravity(Gravity.CENTER);content.addView(status,new LinearLayout.LayoutParams(-1,dp(48)));
        ProgressBar p=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);p.setIndeterminate(true);content.addView(p,new LinearLayout.LayoutParams(-1,dp(8)));
        String[] a={"✓ Belichting analyseren","✓ Kleuren en witbalans","✓ Detail en scherpte","✓ Ruisonderdrukking","✓ Resultaten voorbereiden"};for(String x:a){TextView q=txt(x,12,Color.rgb(214,205,197));q.setPadding(dp(14),dp(6),0,dp(6));content.addView(q);}
        footer("Annuleren","⌂ Home",v->home(),v->home());
    }

    private void resultsScreen(){
        base("Resultaten");if(results.isEmpty())for(Bitmap b:originals)results.add(enhance(b,true));
        LinearLayout cmp=new LinearLayout(this);cmp.setOrientation(LinearLayout.HORIZONTAL);ImageView a=new ImageView(this),b=new ImageView(this);
        a.setImageBitmap(originals.get(Math.min(selected,originals.size()-1)));b.setImageBitmap(results.get(Math.min(selected,results.size()-1)));
        cmp.addView(imageBox("Voor",a,false),new LinearLayout.LayoutParams(0,dp(320),1));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(320),1);bp.leftMargin=dp(7);cmp.addView(imageBox("Na",b,true),bp);content.addView(cmp);
        LinearLayout th=new LinearLayout(this);for(int i=0;i<Math.min(results.size(),8);i++){final int n=i;ImageView v=new ImageView(this);v.setImageBitmap(preview(results.get(i)));v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(panel(Color.BLACK,10,i==selected?GOLD:Color.DKGRAY));LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(66),1);tp.leftMargin=dp(3);th.addView(v,tp);v.setOnClickListener(x->{selected=n;resultsScreen();});}content.addView(th);
        TextView info=txt(results.size()+" foto('s) • klaar voor opslaan",12,MUTED);info.setGravity(Gravity.CENTER);content.addView(info,new LinearLayout.LayoutParams(-1,dp(42)));
        footer("⇩ Opslaan","↗ Delen",v->save(),v->share());
    }

    private void tool(int t){
        if(originals.isEmpty())return;
        Bitmap src=originals.get(selected);
        if(t==0){
            int w=src.getWidth(),h=src.getHeight(),cw=(int)(Math.min(w,h*1.3333f)),ch=(int)(cw/1.3333f);
            cw=Math.min(cw,w);ch=Math.min(ch,h);originals.set(selected,Bitmap.createBitmap(src,(w-cw)/2,(h-ch)/2,cw,ch));editor();
        } else if(t==1){
            Matrix m=new Matrix();m.postRotate(90);originals.set(selected,Bitmap.createBitmap(src,0,0,src.getWidth(),src.getHeight(),m,true));editor();
        } else if(t==2){filter=(filter+1)%4;renderAsync();}
        else if(t==3){retouch=!retouch;Toast.makeText(this,retouch?"Retouch actief: veeg over de foto.":"Retouch uit.",Toast.LENGTH_SHORT).show();editor();}
        else collage();
    }

    private void retouchCircle(float x,float y){
        if(afterView==null)return;
        Bitmap base=afterView.getDrawable() instanceof android.graphics.drawable.BitmapDrawable?((android.graphics.drawable.BitmapDrawable)afterView.getDrawable()).getBitmap():null;
        if(base==null)return;
        Bitmap c=base.copy(Bitmap.Config.ARGB_8888,true);Canvas canvas=new Canvas(c);Paint p=new Paint();p.setColor(Color.argb(90,0,0,0));p.setMaskFilter(new BlurMaskFilter(18,BlurMaskFilter.Blur.NORMAL));canvas.drawCircle(x/(float)afterView.getWidth()*c.getWidth(),y/(float)afterView.getHeight()*c.getHeight(),dp(38),p);afterView.setImageBitmap(c);
    }

    private void collage(){
        if(results.size()<2){Toast.makeText(this,"Kies eerst minimaal 2 foto's.",Toast.LENGTH_SHORT).show();return;}
        int w=700,h=500;Bitmap c=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);Canvas cv=new Canvas(c);cv.drawColor(Color.BLACK);
        for(int i=0;i<Math.min(4,results.size());i++){Bitmap b=preview(results.get(i));Rect dst=new Rect((i%2)*(w/2),(i/2)*(h/2),(i%2+1)*(w/2),(i/2+1)*(h/2));cv.drawBitmap(b,null,dst,new Paint(Paint.FILTER_BITMAP_FLAG));}
        results.clear();results.add(c);selected=0;resultsScreen();
    }

    private Uri save(){
        if(results.isEmpty()){if(originals.isEmpty())return null;results.add(enhance(originals.get(selected),true));}
        try{
            String name="AI_Fotograaf_PRO_"+System.currentTimeMillis()+".jpg";ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
            if(android.os.Build.VERSION.SDK_INT>=29)v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/AI Fotograaf PRO");
            Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(u==null)throw new Exception();
            OutputStream o=getContentResolver().openOutputStream(u);results.get(Math.min(selected,results.size()-1)).compress(Bitmap.CompressFormat.JPEG,96,o);if(o!=null)o.close();
            Toast.makeText(this,"Opgeslagen in Foto's.",Toast.LENGTH_SHORT).show();return u;
        }catch(Exception e){Toast.makeText(this,"Opslaan mislukt.",Toast.LENGTH_SHORT).show();return null;}
    }
    private void share(){
        Uri u=save();if(u==null)return;Intent i=new Intent(Intent.ACTION_SEND);i.setType("image/jpeg");i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Delen via"));
    }

    private void settings(){
        base("Instellingen");
        String[] s={"Automatische verbetering","Gezichtsoptimalisatie","Natuurlijke huidtinten","Ruisonderdrukking","Originele resolutie bij opslaan","Resultaten bewaren in Foto's"};
        for(String x:s){Switch q=new Switch(this);q.setText(x);q.setTextColor(CREAM);q.setTextSize(14);q.setChecked(true);q.setPadding(dp(12),0,dp(12),0);q.setBackground(panel(PANEL,14,Color.rgb(47,42,40)));content.addView(q,new LinearLayout.LayoutParams(-1,dp(58)));}
        TextView n=txt("Lokale bewerking • foto's worden niet naar een server gestuurd.",11,MUTED);n.setPadding(dp(12),dp(15),dp(12),dp(10));content.addView(n);
        footer("‹ Terug","⌂ Home",v->home(),v->home());
    }

    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);worker.shutdownNow();super.onDestroy();}
}
