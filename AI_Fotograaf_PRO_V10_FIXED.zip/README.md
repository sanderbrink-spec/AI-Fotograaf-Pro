AI Fotograaf PRO V8 COMPLETE

Dit is de volledige professionele Loes-versie, niet de minimale compileerbasis.

Ontwerp:
- lange premium intro met de aangeleverde Loes-camera splash
- Photos by Loes / PURE MOMENTS branding
- zwart, goud, crème, bokeh/camera-esthetiek
- AI Fotograaf PRO / AI by Loes
- professionele afgeronde kaarten en knoppen

Functies:
- Selecteer meerdere foto's, maximaal 100
- Camera openen
- AI PERFECT
- Voor/Na vergelijking
- Resultatenscherm met thumbnails
- Presets: AI PERFECT, Natuurlijk, Vibrant, Portret
- Belichting, contrast, kleuren, scherpte en ruisonderdrukking
- Gezichtsoptimalisatie-instelling
- Lokale verwerking
- Originele resolutie behouden tijdens laden/verwerking
- Opslaan en delen
- Instellingen
- Verwerkingsscherm met voortgangsstappen


V9 POLISHED fixes:
- Fixed bottom action bar outside the scroll area.
- Added vertical fading edges and gold Android overscroll effect.
- Added smooth screen entrance animation.
- Added EXIF orientation correction so camera photos are not shown sideways.
- Extended intro to 5 seconds with a camera-flash pulse.
- Intro uses the agreed Loes / Photos by Loes / PURE MOMENTS artwork.


V10 FAST / POLISHED:
- Slider preview is rendered at reduced resolution off the UI thread.
- Full-resolution render runs only after releasing a slider.
- Presets now actually change the preview.
- Rotate and crop tools now work.
- Fixed bottom action bar remains reachable.
- Larger image comparison area fills more of the screen.
- ScrollView keeps fading edges, overscroll and smooth screen entrance.

V10 FIXED: Java lambda compile error resolved by making the preset flag final.
