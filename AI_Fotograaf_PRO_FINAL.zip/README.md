AI Fotograaf PRO 10.0 FINAL

Doel: stabiele complete app-build, niet een technische demo.

Belangrijk:
- Premium Loes intro met langere animatie en camera-flits.
- Vaste onderste actiebalk buiten de ScrollView. Daardoor altijd bereikbaar.
- ScrollView met fading edges en Android overscroll-effect.
- Foto's worden bij import begrensd voor stabiel geheugenverbruik.
- Schuifjes gebruiken snelle previews en renderen buiten de UI-thread.
- AI PERFECT batchverwerking.
- Voor/Na.
- Portret/Natuurlijk/Vibrant filters.
- Belichting, contrast, kleuren, scherpte, ruis.
- Bijsnijden en draaien.
- Retouch-modus.
- Collage vanaf minimaal 2 resultaten.
- Camera met runtime-permissie.
- Opslaan en delen.
- Instellingen.
- Geen ExifInterface of andere extra runtime dependency.
