# AI Fotograaf PRO 3.0

Final PRO build voor Android.

## Kern
- Loes-intro met bestaande flitsanimatie.
- Herkenbaar goud/zwart camera-logo met elegante L.
- Foto's worden automatisch volgens EXIF-orientatie rechtgezet.
- AI PERFECT-preview draait op een kleinere kopie zodat schuifjes direct reageren.
- Volledige resolutie wordt pas bij opslaan verwerkt.
- Verbeterde automatische tooncurve, schaduwherstel, subtiele witbalanscorrectie, kleur, ruisonderdrukking en verscherping.
- Vaste onderste navigatie boven de Android-systeemnavigatie.
- Nieuw project wist de actieve bewerking.
- Bijsnijden, draaien en presets zijn lokaal beschikbaar.

## Build
GitHub Actions bouwt de debug-APK met Java 17 en Gradle 8.9.
