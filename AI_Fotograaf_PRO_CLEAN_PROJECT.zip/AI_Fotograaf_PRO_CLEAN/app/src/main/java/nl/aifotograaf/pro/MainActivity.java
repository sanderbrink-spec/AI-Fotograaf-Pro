package nl.aifotograaf.pro;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;

public class MainActivity extends Activity {
    private static final int PICK_IMAGES = 1001;
    private TextView status;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(48,48,48,48);
        root.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("AI FOTOGRAAF PRO");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1,-2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Lokale fotobewerking");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2);
        sp.topMargin=16;
        root.addView(subtitle,sp);

        Button choose = new Button(this);
        choose.setText("FOTO'S KIEZEN");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,-2);
        bp.topMargin=48;
        root.addView(choose,bp);

        status = new TextView(this);
        status.setText("Kies maximaal 100 foto's.");
        status.setTextColor(Color.WHITE);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1,-2);
        tp.topMargin=24;
        root.addView(status,tp);

        choose.setOnClickListener(v -> pickImages());
        setContentView(root);
    }

    private void pickImages() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent,PICK_IMAGES);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=PICK_IMAGES || resultCode!=RESULT_OK || data==null) return;
        int count=0;
        if(data.getClipData()!=null) count=Math.min(data.getClipData().getItemCount(),100);
        else if(data.getData()!=null) count=1;
        status.setText(count+" foto"+(count==1?"":"'s")+" geselecteerd.");
    }
}
