Loes Photo Enhancer v2
- Nieuwe zwart/goud layout met geanimeerd camera-logo.
- Voor/na vergelijking.
- Lokale fotobewerking in de browser.
- Automatische belichting, contrast, kleur en scherpte.
- Handmatige sliders.
- Opslaan en delen.
- Voorbeeldfoto inbegrepen.
- Geen internetverbinding nodig voor de fotobewerking.
